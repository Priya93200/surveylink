from core.schemas import ExtractionResult
from agents.base import OpenAIAgent

SYSTEM = """
You are the Survey Logic Extraction Agent.

Extract only routing and scripting instructions explicitly supported by the supplied questionnaire text.
Use the same row schema as the question agent.

Important ROUTING rules:
- ROUTING must contain the destination question number the respondent should see after selecting that option, when the source specifies a destination.
- Use the exact original question ID, including suffixes such as 16a or 16b. Format targets as Q<number>, e.g. Q12 or Q16b.
- For explicit skips/jumps, route to the named destination, not the next sequential question.
- For termination options, set Logic='TERMINATE' and ROUTING='TERMINATE'.
- For conditional branches, write a concise condition and all destinations in ROUTING, e.g. 'Q11 IF condition; OTHERWISE Q12'.
- Do not use the option text or full question wording as ROUTING.
- Do not invent explicit skip/branch destinations that are not in the document. If the document does not explicitly define a route, leave ROUTING blank; a later code step fills ordinary sequential routes using the extracted question order.
- Preserve option codes exactly.
- Normalize logic labels to concise labels such as TERMINATE, ANCHOR, EXCLUSIVE, SKIP_TO, DISPLAY_IF, PIPE_IN, RANDOMIZE, OPEN_TEXT_IF, AGE_FLAG.
- Prefer attaching logic to the relevant option row. For question-level logic, create a Row_Type='Logic' row with the relevant Q_No or attach it to the question row if this does not lose option information.
- If unclear, flag it for review in review_notes.
Return only the requested structured schema.
"""

class LogicAgent(OpenAIAgent):
    def run(self, document_segment: str, instructions: str) -> ExtractionResult:
        content = f"""USER INSTRUCTIONS:
{instructions}

DOCUMENT SEGMENT:
{document_segment}
"""
        return self.structured_call(SYSTEM, content, ExtractionResult)
