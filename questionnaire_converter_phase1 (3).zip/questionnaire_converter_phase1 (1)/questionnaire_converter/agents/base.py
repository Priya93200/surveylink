from openai import OpenAI
from pydantic import BaseModel

class OpenAIAgent:
    def __init__(self, api_key: str, model: str):
        self.client = OpenAI(api_key=api_key)
        self.model = model

    def structured_call(self, system_prompt: str, user_content: str, schema: type[BaseModel]):
        # Chat Completions structured parsing; supported by current OpenAI Python SDK.
        response = self.client.beta.chat.completions.parse(
            model=self.model,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_content},
            ],
            response_format=schema,
        )
        parsed = response.choices[0].message.parsed
        if parsed is None:
            refusal = getattr(response.choices[0].message, "refusal", None)
            raise RuntimeError(f"Model did not return structured data. {refusal or ''}".strip())
        return parsed
