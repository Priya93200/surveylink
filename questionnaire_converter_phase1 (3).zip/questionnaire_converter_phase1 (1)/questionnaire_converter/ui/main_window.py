from pathlib import Path
import re
import os
import inspect
from dotenv import load_dotenv
from PySide6.QtCore import Qt, QThread, Signal, QTimer
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QFileDialog, QTextEdit, QTableWidget, QTableWidgetItem,
    QMessageBox, QProgressBar, QHeaderView, QFrame, QScrollArea, QDialog,
    QSizePolicy
)
from core.document_parser import parse_docx
from core.orchestrator import DEFAULT_INSTRUCTIONS, run_extraction
from core.excel_writer import write_template, HEADERS

load_dotenv()

STYLE = """
* { font-family: 'Segoe UI', 'Inter', 'Helvetica Neue', Arial, sans-serif; font-size: 13px; color: #1f2937; }
QMainWindow, QScrollArea, QWidget#page, QDialog { background: #f4f6fb; }
QScrollArea { border: none; }

QLabel#title { font-size: 26px; font-weight: 700; color: #111827; }
QLabel#subtitle { color: #6b7280; font-size: 13px; }

QFrame#card { background: #ffffff; border: 1px solid #e5e7eb; border-radius: 14px; }
QLabel#cardTitle { font-size: 15px; font-weight: 600; color: #111827; }
QLabel#cardHint { color: #6b7280; font-size: 12px; }
QLabel#badge {
    background: #eef2ff; color: #4f46e5; border-radius: 12px;
    min-width: 24px; max-width: 24px; min-height: 24px; max-height: 24px;
    font-weight: 700; qproperty-alignment: AlignCenter;
}
QLabel#fieldLabel { color: #374151; font-weight: 600; }
QLabel#chip { background: #f3f4f6; color: #374151; border-radius: 10px; padding: 3px 10px; font-size: 12px; }
QLabel#chipWarn { background: #fff7ed; color: #c2410c; border-radius: 10px; padding: 3px 10px; font-size: 12px; font-weight: 600; }
QLabel#stage { color: #4b5563; }
QLabel#error { color: #b91c1c; background: #fef2f2; border: 1px solid #fecaca; border-radius: 8px; padding: 8px 10px; }
QLabel#success { color: #047857; background: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 8px; padding: 8px 10px; }

QLineEdit {
    background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px;
    padding: 8px 10px; selection-background-color: #c7d2fe;
}
QLineEdit:focus { border: 1px solid #6366f1; background: #ffffff; }

QTextEdit {
    background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 10px;
    padding: 8px; selection-background-color: #c7d2fe;
}
QTextEdit:focus { border: 1px solid #6366f1; background: #ffffff; }

QPushButton {
    background: #ffffff; border: 1px solid #d1d5db; border-radius: 8px;
    padding: 8px 16px; font-weight: 600; color: #374151;
}
QPushButton:hover { background: #f3f4f6; }
QPushButton:disabled { background: #f3f4f6; color: #9ca3af; border-color: #e5e7eb; }
QPushButton#primary { background: #4f46e5; border: 1px solid #4f46e5; color: #ffffff; padding: 10px 26px; font-size: 14px; }
QPushButton#primary:hover { background: #4338ca; }
QPushButton#primary:disabled { background: #c7d2fe; border-color: #c7d2fe; color: #ffffff; }
QPushButton#success { background: #059669; border: 1px solid #059669; color: #ffffff; padding: 10px 26px; font-size: 14px; }
QPushButton#success:hover { background: #047857; }
QPushButton#success:disabled { background: #a7f3d0; border-color: #a7f3d0; color: #ffffff; }
QPushButton#secondary { padding: 10px 26px; font-size: 14px; border: 1px solid #6366f1; color: #4f46e5; }
QPushButton#secondary:hover { background: #eef2ff; }
QPushButton#secondary:disabled { border-color: #e5e7eb; color: #9ca3af; background: #f3f4f6; }
QPushButton#ghost { background: transparent; border: none; color: #6b7280; padding: 8px 12px; }
QPushButton#ghost:hover { color: #111827; background: #f3f4f6; }

QProgressBar { background: #e5e7eb; border: none; border-radius: 5px; min-height: 10px; max-height: 10px; text-align: center; color: transparent; }
QProgressBar::chunk { background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #6366f1, stop:1 #8b5cf6); border-radius: 5px; }

QTableWidget { background: #ffffff; alternate-background-color: #f9fafb; border: 1px solid #e5e7eb; border-radius: 10px; gridline-color: #f0f1f4; selection-background-color: #e0e7ff; selection-color: #111827; }
QHeaderView::section { background: #f3f4f6; border: none; border-bottom: 1px solid #e5e7eb; padding: 8px; font-weight: 600; color: #374151; }

QScrollBar:vertical { background: transparent; width: 10px; margin: 2px; }
QScrollBar::handle:vertical { background: #cbd5e1; border-radius: 4px; min-height: 30px; }
QScrollBar::handle:vertical:hover { background: #94a3b8; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal { background: transparent; height: 10px; margin: 2px; }
QScrollBar::handle:horizontal { background: #cbd5e1; border-radius: 4px; min-width: 30px; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }
"""


class ExtractionWorker(QThread):
    progress = Signal(int, int, str)
    completed = Signal(object, object)
    failed = Signal(str)

    def __init__(self, api_key, model, docx_path, instructions, template_path):
        super().__init__()
        self.api_key = api_key
        self.model = model
        self.docx_path = docx_path
        self.instructions = instructions
        self.template_path = template_path

    def run(self):
        try:
            self.progress.emit(0, 1, "Reading the Word document…")
            text = parse_docx(self.docx_path)
            if not text.strip():
                raise ValueError("No readable text or tables were found in the DOCX.")
            # A small template header/example is supplied to help match the schema, not to copy facts.
            example = "Columns: " + ", ".join(HEADERS)
            # Newer orchestrator versions report progress; older ones do not accept the argument.
            kwargs = {}
            if "progress_callback" in inspect.signature(run_extraction).parameters:
                kwargs["progress_callback"] = lambda d, t, m: self.progress.emit(d, t, m)
            else:
                self.progress.emit(1, 4, "Extracting questions, options and routing (this may take a few minutes)…")
            rows, notes = run_extraction(
                self.api_key, self.model, text, self.instructions, example, **kwargs
            )
            self.completed.emit(rows, notes)
        except Exception as e:
            self.failed.emit(f"{type(e).__name__}: {e}")


def make_card():
    card = QFrame()
    card.setObjectName("card")
    layout = QVBoxLayout(card)
    layout.setContentsMargins(24, 20, 24, 22)
    layout.setSpacing(12)
    return card, layout


def card_header(number, title, hint=""):
    row = QHBoxLayout()
    row.setSpacing(10)
    badge = QLabel(str(number))
    badge.setObjectName("badge")
    badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
    text = QVBoxLayout()
    text.setSpacing(1)
    t = QLabel(title)
    t.setObjectName("cardTitle")
    text.addWidget(t)
    if hint:
        h = QLabel(hint)
        h.setObjectName("cardHint")
        text.addWidget(h)
    row.addWidget(badge, 0, Qt.AlignmentFlag.AlignTop)
    row.addLayout(text, 1)
    return row


class ReviewDialog(QDialog):
    """Editable table of the extracted rows. Changes are only applied when the user saves."""

    def __init__(self, rows, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Review extracted rows")
        self.resize(1300, 780)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(12)

        title = QLabel("Review Excel")
        title.setObjectName("title")
        hint = QLabel("Double-click any cell to edit. Click “Save changes” to use your edits in the download.")
        hint.setObjectName("subtitle")
        layout.addWidget(title)
        layout.addWidget(hint)

        self.table = QTableWidget(0, len(HEADERS))
        self.table.setHorizontalHeaderLabels(HEADERS)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.setWordWrap(True)
        self.table.setShowGrid(True)
        layout.addWidget(self.table, 1)
        self._populate(rows)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel = QPushButton("Cancel")
        cancel.clicked.connect(self.reject)
        save = QPushButton("Save changes")
        save.setObjectName("primary")
        save.clicked.connect(self.accept)
        buttons.addWidget(cancel)
        buttons.addWidget(save)
        layout.addLayout(buttons)

    def _populate(self, rows):
        self.table.setRowCount(len(rows))
        for r, data in enumerate(rows):
            for c, header in enumerate(HEADERS):
                value = data.get(header)
                self.table.setItem(r, c, QTableWidgetItem("" if value is None else str(value)))
        self.table.resizeColumnsToContents()
        self.table.resizeRowsToContents()
        self.table.setColumnWidth(2, 380)
        self.table.setColumnWidth(5, 260)
        self.table.resizeRowsToContents()

    def get_rows(self):
        """Read the table as plain dictionaries (blank cells -> None), exactly as shown."""
        result = []
        for r in range(self.table.rowCount()):
            data = {}
            for c, header in enumerate(HEADERS):
                item = self.table.item(r, c)
                value = item.text().strip() if item else ""
                data[header] = value if value != "" else None
            result.append(data)
        return result


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Questionnaire to Excel — AI Agent Studio")
        self.resize(1100, 900)
        self.setMinimumSize(900, 680)
        self.setStyleSheet(STYLE)

        # API settings are loaded from the .env file and are intentionally not shown in the UI.
        self._api_key = os.getenv("OPENAI_API_KEY", "").strip()
        self._model = os.getenv("OPENAI_MODEL", "gpt-4.1-mini").strip()

        self.rows = []          # reviewed / extracted rows as plain dicts
        self.notes = []
        self.docx_path = ""
        self.template_path = ""
        self.worker = None

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.setCentralWidget(scroll)
        page = QWidget()
        page.setObjectName("page")
        scroll.setWidget(page)
        outer = QVBoxLayout(page)
        outer.setContentsMargins(40, 32, 40, 32)
        outer.setSpacing(20)

        # ---- Header
        title = QLabel("Questionnaire → Excel")
        title.setObjectName("title")
        subtitle = QLabel("Multi-agent extraction  •  Human review  •  Template-preserving export")
        subtitle.setObjectName("subtitle")
        outer.addWidget(title)
        outer.addWidget(subtitle)

        # ---- Card 1: input files
        files_card, files_layout = make_card()
        files_layout.addLayout(card_header(1, "Input files", "Choose the questionnaire and the Excel template to fill."))
        self.docx_line = self._file_row(files_layout, "Questionnaire (DOCX)", "Select a .docx questionnaire…", self.choose_docx)
        self.template_line = self._file_row(files_layout, "Excel template (XLSX)", "Select an .xlsx template…", self.choose_template)
        outer.addWidget(files_card)

        # ---- Card 2: context instructions + extract + progress
        ctx_card, ctx_layout = make_card()
        ctx_layout.addLayout(card_header(2, "Context instructions", "Edit these rules to suit your questionnaire."))
        self.instructions = QTextEdit()
        self.instructions.setPlainText(DEFAULT_INSTRUCTIONS)
        self.instructions.setMinimumHeight(200)
        ctx_layout.addWidget(self.instructions)

        action_row = QHBoxLayout()
        self.extract_btn = QPushButton("Extract questionnaire")
        self.extract_btn.setObjectName("primary")
        self.extract_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.extract_btn.clicked.connect(self.extract)
        self.clear_btn = QPushButton("Clear")
        self.clear_btn.setObjectName("ghost")
        self.clear_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.clear_btn.clicked.connect(self.clear_review)
        action_row.addWidget(self.extract_btn)
        action_row.addWidget(self.clear_btn)
        action_row.addStretch(1)
        ctx_layout.addLayout(action_row)

        # Progress area (hidden until extraction starts)
        self.progress_box = QWidget()
        pb = QVBoxLayout(self.progress_box)
        pb.setContentsMargins(0, 4, 0, 0)
        pb.setSpacing(6)
        self.stage_label = QLabel("Starting…")
        self.stage_label.setObjectName("stage")
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(False)
        pb.addWidget(self.stage_label)
        pb.addWidget(self.progress_bar)
        self.progress_box.setVisible(False)
        ctx_layout.addWidget(self.progress_box)

        self.error_label = QLabel()
        self.error_label.setObjectName("error")
        self.error_label.setWordWrap(True)
        self.error_label.setVisible(False)
        ctx_layout.addWidget(self.error_label)
        outer.addWidget(ctx_card)

        # ---- Card 3: validation / review notes + actions (hidden until extraction completes)
        self.result_card, result_layout = make_card()
        result_layout.addLayout(card_header(3, "Validation / review notes", "Check these before downloading."))

        chips = QHBoxLayout()
        chips.setSpacing(8)
        self.rows_chip = QLabel()
        self.rows_chip.setObjectName("chip")
        self.notes_chip = QLabel()
        self.notes_chip.setObjectName("chipWarn")
        chips.addWidget(self.rows_chip)
        chips.addWidget(self.notes_chip)
        chips.addStretch(1)
        result_layout.addLayout(chips)

        self.notes_box = QTextEdit()
        self.notes_box.setReadOnly(True)
        self.notes_box.setMinimumHeight(150)
        self.notes_box.setMaximumHeight(260)
        result_layout.addWidget(self.notes_box)

        result_buttons = QHBoxLayout()
        self.review_btn = QPushButton("Review Excel")
        self.review_btn.setObjectName("secondary")
        self.review_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.review_btn.clicked.connect(self.review_excel)
        self.download_btn = QPushButton("Download Excel")
        self.download_btn.setObjectName("success")
        self.download_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.download_btn.clicked.connect(self.export_excel)
        result_buttons.addWidget(self.review_btn)
        result_buttons.addWidget(self.download_btn)
        result_buttons.addStretch(1)
        result_layout.addLayout(result_buttons)

        self.success_label = QLabel()
        self.success_label.setObjectName("success")
        self.success_label.setWordWrap(True)
        self.success_label.setVisible(False)
        result_layout.addWidget(self.success_label)

        self.result_card.setVisible(False)
        outer.addWidget(self.result_card)
        outer.addStretch(1)

        self.status = QLabel("Ready. Choose a DOCX and an XLSX template to begin.")
        self.statusBar().addWidget(self.status)

    # ---------- helpers ----------
    def _file_row(self, parent_layout, label, placeholder, callback):
        lbl = QLabel(label)
        lbl.setObjectName("fieldLabel")
        parent_layout.addWidget(lbl)
        row = QHBoxLayout()
        row.setSpacing(10)
        line = QLineEdit()
        line.setReadOnly(True)
        line.setPlaceholderText(placeholder)
        button = QPushButton("Browse…")
        button.setCursor(Qt.CursorShape.PointingHandCursor)
        button.clicked.connect(callback)
        row.addWidget(line, 1)
        row.addWidget(button)
        parent_layout.addLayout(row)
        return line

    def choose_docx(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select questionnaire", "", "Word documents (*.docx)")
        if path:
            self.docx_path = path
            self.docx_line.setText(path)

    def choose_template(self):
        path, _ = QFileDialog.getOpenFileName(self, "Select Excel template", "", "Excel workbooks (*.xlsx)")
        if path:
            self.template_path = path
            self.template_line.setText(path)

    def _show_error(self, message):
        self.error_label.setText(message)
        self.error_label.setVisible(True)

    # ---------- extraction ----------
    def extract(self):
        self.error_label.setVisible(False)
        if not self.docx_path or not os.path.isfile(self.docx_path):
            QMessageBox.warning(self, "Missing questionnaire", "Please choose a valid DOCX questionnaire.")
            return
        if not self.template_path or not os.path.isfile(self.template_path):
            QMessageBox.warning(self, "Missing template", "Please choose a valid XLSX template.")
            return
        if not self._api_key:
            QMessageBox.warning(
                self, "API key not configured",
                "No OpenAI API key was found. Add OPENAI_API_KEY to the .env file next to main.py and restart the app.",
            )
            return
        if not self._model:
            QMessageBox.warning(self, "Model not configured", "Add OPENAI_MODEL to the .env file and restart the app.")
            return

        # Reset previous results and show the progress bar
        self.result_card.setVisible(False)
        self.success_label.setVisible(False)
        self.extract_btn.setEnabled(False)
        self.clear_btn.setEnabled(False)
        self.progress_bar.setValue(0)
        self.stage_label.setText("Starting…")
        self.progress_box.setVisible(True)
        self.status.setText("Extracting document and calling AI agents…")

        self.worker = ExtractionWorker(
            self._api_key, self._model, self.docx_path,
            self.instructions.toPlainText(), self.template_path,
        )
        self.worker.progress.connect(self.on_progress)
        self.worker.completed.connect(self.on_extraction_complete)
        self.worker.failed.connect(self.on_extraction_failed)
        self.worker.start()

    def on_progress(self, done, total, message):
        percent = int(done * 100 / total) if total else 0
        # Keep the bar visibly moving: never show 0% while work is running, never 100% before completion.
        self.progress_bar.setValue(max(3, min(percent, 98)))
        self.stage_label.setText(message)

    def on_extraction_complete(self, rows, notes):
        self.rows = []
        for record in rows:
            data = record.model_dump()
            self.rows.append({h: (None if data.get(h) in (None, "") else str(data.get(h))) for h in HEADERS})
        self.notes = list(notes)

        self.progress_bar.setValue(100)
        self.stage_label.setText("Extraction complete")
        QTimer.singleShot(500, lambda: self.progress_box.setVisible(False))

        self.rows_chip.setText(f"{len(self.rows)} rows extracted")
        self.notes_chip.setText(f"{len(self.notes)} note(s) to check")
        self.notes_chip.setVisible(bool(self.notes))
        if self.notes:
            self.notes_box.setPlainText("\n".join(f"•  {n}" for n in self.notes))
        else:
            self.notes_box.setPlainText(
                "No automatic validation warnings. Please still review all routing and termination logic."
            )
        self.result_card.setVisible(True)
        self.review_btn.setEnabled(bool(self.rows))
        self.download_btn.setEnabled(bool(self.rows))
        self.extract_btn.setEnabled(True)
        self.clear_btn.setEnabled(True)
        self.status.setText(f"Extraction complete: {len(self.rows)} rows • {len(self.notes)} review note(s). Review before download.")

    def on_extraction_failed(self, message):
        self.progress_box.setVisible(False)
        self.extract_btn.setEnabled(True)
        self.clear_btn.setEnabled(True)
        self.status.setText("Extraction failed.")
        self._show_error(message)
        QMessageBox.critical(self, "Extraction failed", message)

    # ---------- review / export ----------
    def review_excel(self):
        if not self.rows:
            return
        dialog = ReviewDialog(self.rows, self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            self.rows = dialog.get_rows()
            self.rows_chip.setText(f"{len(self.rows)} rows (reviewed)")
            self.status.setText("Review changes saved. Click “Download Excel” to export.")

    def _review_warnings(self, rows):
        warnings = []
        for index, row in enumerate(rows, start=1):
            if not row.get("Row_Type"):
                warnings.append(f"Row {index}: Row_Type is blank")
            if not row.get("Q_No"):
                warnings.append(f"Row {index}: Q_No is blank")
        return warnings

    def export_excel(self):
        rows = self.rows
        if not rows:
            QMessageBox.warning(self, "Nothing to export", "There are no rows to export.")
            return

        # Warnings inform the user but do not block export after their review decision.
        warnings = self._review_warnings(rows)
        if warnings:
            preview = "\n".join(warnings[:12])
            if len(warnings) > 12:
                preview += f"\n… and {len(warnings) - 12} more warning(s)"
            answer = QMessageBox.question(
                self,
                "Review warnings — continue export?",
                "Some rows have blank fields. You can go back and edit them with “Review Excel”, "
                "or continue and export as-is.\n\n" + preview + "\n\nExport anyway?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes,
            )
            if answer != QMessageBox.StandardButton.Yes:
                return

        # Suggest the output filename from the questionnaire DOCX name.
        questionnaire_name = Path(self.docx_path).stem if self.docx_path else "questionnaire"
        safe_name = re.sub(r'[<>:"/\\|?*]', "_", questionnaire_name).strip().rstrip(".") or "questionnaire"
        default_filename = f"{safe_name}_routing.xlsx"
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Excel", default_filename, "Excel workbooks (*.xlsx)"
        )
        if not path:
            return
        if not path.lower().endswith(".xlsx"):
            path += ".xlsx"
        try:
            write_template(self.template_path, path, rows)
            self.status.setText(f"Excel exported: {path}")
            self.success_label.setText(f"✓ Excel saved: {path}")
            self.success_label.setVisible(True)
        except Exception as e:
            QMessageBox.critical(self, "Export failed", f"{e}\n\nLoaded writer module: {inspect.getfile(write_template)}")

    def clear_review(self):
        self.rows = []
        self.notes = []
        self.notes_box.clear()
        self.result_card.setVisible(False)
        self.success_label.setVisible(False)
        self.error_label.setVisible(False)
        self.progress_box.setVisible(False)
        self.status.setText("Cleared.")