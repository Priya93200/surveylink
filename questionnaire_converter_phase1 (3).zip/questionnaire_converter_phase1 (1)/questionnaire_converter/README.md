# Questionnaire-to-Excel AI (Phase 1)

A Python-run Windows desktop MVP using PySide6, OpenAI API, python-docx, Pydantic, and openpyxl.

## Features
- Select a DOCX questionnaire and an existing XLSX template.
- Edit extraction instructions and provide an OpenAI API key/model.
- Parse DOCX paragraphs and tables while retaining paragraph/table order and basic font-color metadata.
- Run separate extraction stages for questions/options and survey logic.
- Review and edit extracted rows in a table before export.
- Export into the selected Excel template while preserving its sheet, header row, and formatting.
- Flag uncertain or invalid routing for human review.

## Setup (Windows)
1. Install Python 3.11 or 3.12 (recommended for package compatibility).
2. Extract this folder.
3. Open Command Prompt in this folder and run:
   ```bat
   py -m venv .venv
   .venv\\Scripts\\activate
   pip install -r requirements.txt
   ```
4. Optional: copy `.env.example` to `.env` and add your API key. You can also paste the key into the app each time.
5. Run:
   ```bat
   python main.py
   ```

## Workflow
1. Choose the DOCX file.
2. Choose the XLSX template (for your first test, select `testlink4.xlsx`).
3. Review/edit the context instructions.
4. Enter API key and model, then click **Extract questionnaire**.
5. Review and correct the rows in the table.
6. Click **Export reviewed Excel** and choose an output path.

## Excel schema
The exporter maps records to these columns in this order:
`Row_Type, Q_No, Q_Text, Q_Type, Option_No, Option_Text, Option_choosing, Logic, ROUTING`

The template's first worksheet and first row are used by default. Existing data rows are cleared before the reviewed rows are written. The template file itself is not overwritten unless you deliberately choose the same output path.

## Notes / limitations of Phase 1
- DOCX only. PDF/OCR is not included.
- This is an assisted extraction workflow, not a guarantee of perfect survey logic. Always review routing and termination before using the output in a live survey.
- Blue font is supplied to the AI as metadata, but the app does not blindly discard all blue text. The context instructions decide whether text is excluded; routing, anchor, terminate, exclusive, and display instructions should be retained when relevant.
- Large questionnaires may use multiple API calls and incur API charges.
- Keep your API key private. Avoid distributing a `.env` file or embedding the key in source code.
- The template is preserved structurally, but the exporter currently writes data to the first worksheet only.
