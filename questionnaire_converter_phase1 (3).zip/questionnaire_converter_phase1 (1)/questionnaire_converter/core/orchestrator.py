import re
from core.schemas import ExtractionResult, SurveyRow
from core.export_format import build_label_map, normalize_routing_labels
from agents.question_agent import QuestionAgent
from agents.logic_agent import LogicAgent

DEFAULT_INSTRUCTIONS = """Extract the questionnaire into the uploaded Excel template.
- Text starting with a serial number such as 1., 2., 3. represents a question.
- Text inside option tables represents response options. Preserve original option codes.
- Ignore blue text below the question only when it is explanatory or explicitly marked for exclusion.
- Preserve relevant scripting instructions defining answer type, randomization, anchors, display rules, routing, piping, exclusive options, and termination.
- Do not invent missing questions, options, or routing rules.
- If information is ambiguous, flag it for manual review.
- ROUTING OUTPUT: for every answer option, populate ROUTING with the question number that should be displayed next. Use the next question in document order for ordinary sequential flow. If the document explicitly says to skip, jump, terminate, or conditionally branch, use that destination/condition instead. Use END for the final question when no later question exists.
"""

def _chunk_document(text: str, max_chars: int = 18000):
    """Split by paragraph boundaries while keeping each API request bounded."""
    chunks, current = [], []
    current_len = 0
    for line in text.splitlines():
        if current and current_len + len(line) + 1 > max_chars:
            chunks.append("\n".join(current))
            current, current_len = [], 0
        current.append(line)
        current_len += len(line) + 1
    if current:
        chunks.append("\n".join(current))
    return chunks or [text]


def _merge_rows(question_rows, logic_rows):
    """Attach logic rows to the matching question/option row where possible."""
    rows = [r.model_copy(deep=True) for r in question_rows]
    notes = []
    for item in logic_rows:
        matched = False
        for row in rows:
            same_q = str(row.Q_No or "").strip().casefold() == str(item.Q_No or "").strip().casefold()
            same_opt = (
                str(row.Option_No or "").strip().casefold() == str(item.Option_No or "").strip().casefold()
                if item.Option_No is not None else True
            )
            same_text = (
                str(row.Option_Text or "").strip().casefold() == str(item.Option_Text or "").strip().casefold()
                if item.Option_Text else True
            )
            if same_q and same_opt and same_text and (item.Logic or item.ROUTING):
                if item.Logic:
                    existing = [x.strip() for x in (row.Logic or "").split(";") if x.strip()]
                    for label in [x.strip() for x in item.Logic.split(";") if x.strip()]:
                        if label.casefold() not in {x.casefold() for x in existing}:
                            existing.append(label)
                    row.Logic = "; ".join(existing) or None
                # Logic-agent route is considered an explicit route and must win.
                if item.ROUTING:
                    row.ROUTING = item.ROUTING
                matched = True
                break
        if not matched and (item.Logic or item.ROUTING):
            rows.append(item)
    return rows


def _qid(value):
    """Normalize IDs for comparisons while preserving suffixes such as 16a/16b."""
    if value is None:
        return ""
    text = str(value).strip()
    if not text:
        return ""
    return re.sub(r"^\s*Q\s*", "", text, flags=re.IGNORECASE).strip()


def _route_target_exists(route, question_ids):
    if not route:
        return True
    value = str(route).strip()
    if value.upper() in {"END", "TERMINATE", "Q0"}:
        return True
    # Routes may contain a condition, e.g. 'Q11 IF ...; OTHERWISE Q12'.
    targets = re.findall(r"\bQ\s*([A-Za-z]?\d+[A-Za-z]?)\b", value, flags=re.IGNORECASE)
    if not targets:
        # A bare numeric destination is also accepted.
        bare = re.match(r"^\s*([A-Za-z]?\d+[A-Za-z]?)\s*$", value)
        return bool(bare and _qid(bare.group(1)) in question_ids)
    return all(_qid(target) in question_ids for target in targets)


def apply_default_routing(rows):
    """
    Fill ROUTING generically from the order of questions extracted from the current DOCX.
    Explicit routing from the logic agent is preserved. Termination logic always routes
    to TERMINATE. No questionnaire IDs or options are hard-coded.
    """
    # Build ordered question IDs from actual question rows, deduplicating repeated IDs.
    ordered_ids = []
    seen = set()
    for row in rows:
        qid = _qid(row.Q_No)
        row_type = str(row.Row_Type or "").strip().casefold()
        if qid and row_type == "question" and row.Q_Text and qid.casefold() not in seen:
            ordered_ids.append(qid)
            seen.add(qid.casefold())

    # If the agent did not mark every question row consistently, use first occurrence
    # of any row carrying both an ID and question text as a fallback.
    if not ordered_ids:
        for row in rows:
            qid = _qid(row.Q_No)
            if qid and row.Q_Text and qid.casefold() not in seen:
                ordered_ids.append(qid)
                seen.add(qid.casefold())

    # Use the question number exactly as written in the document ('2' stays '2', 'Q2' stays 'Q2').
    labels = build_label_map(rows)
    next_by_q = {
        qid.casefold(): (labels.get(ordered_ids[index + 1].casefold(), ordered_ids[index + 1]) if index + 1 < len(ordered_ids) else "END")
        for index, qid in enumerate(ordered_ids)
    }

    current_qid = ""
    for row in rows:
        qid = _qid(row.Q_No)
        if qid:
            current_qid = qid
        if not current_qid:
            continue

        logic = str(row.Logic or "").upper()
        existing_route = str(row.ROUTING or "").strip()

        # Termination instructions are not a normal sequential route.
        if any(token in logic for token in ("TERMINATE", "TERMINATION", "END_SURVEY", "END SURVEY")):
            row.ROUTING = "TERMINATE"
            continue

        # Preserve any route explicitly extracted from the questionnaire.
        if existing_route:
            continue

        default_route = next_by_q.get(current_qid.casefold())
        if default_route:
            row.ROUTING = default_route

    return rows


def run_extraction(api_key: str, model: str, document_text: str, instructions: str, template_example: str = "", progress_callback=None):
    """progress_callback(done_steps, total_steps, message) is optional and used by the UI progress bar."""
    def _progress(done, total, message):
        if progress_callback:
            progress_callback(done, total, message)

    question_agent = QuestionAgent(api_key, model)
    logic_agent = LogicAgent(api_key, model)
    q_rows, l_rows, notes = [], [], []
    chunks = _chunk_document(document_text)
    total_steps = len(chunks) * 2 + 1
    done = 0
    for idx, chunk in enumerate(chunks, start=1):
        _progress(done, total_steps, f"Extracting questions and options ({idx} of {len(chunks)})…")
        q_result = question_agent.run(chunk, instructions, template_example if idx == 1 else "")
        done += 1
        _progress(done, total_steps, f"Analysing routing and skip logic ({idx} of {len(chunks)})…")
        l_result = logic_agent.run(chunk, instructions)
        done += 1
        q_rows.extend(q_result.rows)
        l_rows.extend(l_result.rows)
        notes.extend([f"Chunk {idx}: {n}" for n in q_result.review_notes])
        notes.extend([f"Chunk {idx} logic: {n}" for n in l_result.review_notes])

    _progress(done, total_steps, "Merging rows and validating routing…")
    merged = _merge_rows(q_rows, l_rows)
    merged = apply_default_routing(merged)
    merged = normalize_routing_labels(merged)
    notes.extend(validate_rows(merged))
    _progress(total_steps, total_steps, "Done")
    return merged, notes


def validate_rows(rows):
    notes = []
    qids = {
        _qid(r.Q_No).casefold()
        for r in rows
        if r.Q_No not in (None, "") and str(r.Row_Type or "").strip().casefold() == "question"
    }
    if not qids:
        qids = {_qid(r.Q_No).casefold() for r in rows if r.Q_No not in (None, "")}

    for i, row in enumerate(rows, start=1):
        if str(row.Row_Type or "").strip().casefold() == "question" and not row.Q_Text:
            notes.append(f"Row {i}: Question row has no Q_Text.")
        if row.Option_No is not None and not row.Option_Text:
            notes.append(f"Row {i}: Option {row.Option_No} has no Option_Text.")
        logic = (row.Logic or "").upper()
        routing = (row.ROUTING or "").strip()
        if routing and not _route_target_exists(routing, qids):
            notes.append(f"Row {i} / Q{row.Q_No}: routing target '{routing}' was not found among extracted question IDs. Review this route.")
        if "TERMINATE" in logic and routing != "TERMINATE":
            notes.append(f"Row {i} / Q{row.Q_No}: termination logic should route to TERMINATE; review required.")
    return notes


def rows_to_dicts(rows):
    return [r.model_dump() for r in rows]