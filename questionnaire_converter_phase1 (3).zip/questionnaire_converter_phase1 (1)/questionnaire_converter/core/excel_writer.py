from copy import copy
from core.export_format import prepare_export_rows
from openpyxl import load_workbook
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
import re

HEADERS = [
    "Row_Type", "Q_No", "Q_Text", "Q_Type", "Option_No",
    "Option_Text", "Option_choosing", "Logic", "ROUTING"
]

def _normalise(value):
    return re.sub(r"\\s+", "", str(value or "")).casefold()

def _clean(value):
    """Remove control characters (common in Word text) that Excel cannot store."""
    if isinstance(value, str):
        value = ILLEGAL_CHARACTERS_RE.sub("", value)
        # Vertical tab / form feed style separators from Word -> normal space handled by removal above
    return value

def write_template(template_path: str, output_path: str, rows):
    """
    Write reviewed rows into the first worksheet of the supplied Excel template.
    Important: this function NEVER renames or creates worksheets. It preserves
    the worksheet title already present in the template.
    """
    wb = load_workbook(template_path)
    if not wb.worksheets:
        raise ValueError("The selected Excel template has no worksheets.")

    # Keep the template's existing worksheet title unchanged.
    ws = wb.worksheets[0]

    best_row, best_score, header_lookup = None, 0, {}
    scan_end = min(max(ws.max_row, 1), 60)
    for r in range(1, scan_end + 1):
        lookup = {}
        for c in range(1, ws.max_column + 1):
            value = ws.cell(r, c).value
            if value is not None:
                lookup[_normalise(value)] = c
        score = sum(_normalise(header) in lookup for header in HEADERS)
        if score > best_score:
            best_row, best_score, header_lookup = r, score, lookup

    if best_row is None or best_score < 2:
        raise ValueError(
            "Could not find the expected column headers in the first worksheet. "
            "Check that the selected template is the correct routing-sheet XLSX."
        )

    missing = [h for h in HEADERS if _normalise(h) not in header_lookup]
    if missing:
        raise ValueError("Template is missing required columns: " + ", ".join(missing))

    col = {h: header_lookup[_normalise(h)] for h in HEADERS}
    first_data_row = best_row + 1
    old_max_row = ws.max_row
    style_row = first_data_row if old_max_row >= first_data_row else best_row

    # Clear previous data values only; preserve template styles and worksheet name.
    for r in range(first_data_row, old_max_row + 1):
        for c in range(1, ws.max_column + 1):
            ws.cell(r, c).value = None

    # Q_No only on question rows; ROUTING uses the document's own question numbering.
    rows = prepare_export_rows(rows)

    for idx, item in enumerate(rows, start=first_data_row):
        data = item

        for header in HEADERS:
            value = data.get(header)
            if hasattr(value, "value"):
                value = value.value
            ws.cell(idx, col[header]).value = _clean(value)

        if idx != style_row:
            for c in range(1, ws.max_column + 1):
                source = ws.cell(style_row, c)
                target = ws.cell(idx, c)
                if source.has_style:
                    target._style = copy(source._style)
                if source.number_format:
                    target.number_format = source.number_format

    # Remove bold from every data cell (template header row is untouched).
    last_row = max(old_max_row, first_data_row + len(rows) - 1)
    for r in range(first_data_row, last_row + 1):
        for c in range(1, ws.max_column + 1):
            cell = ws.cell(r, c)
            if cell.font is not None and cell.font.bold:
                font = copy(cell.font)
                font.bold = False
                cell.font = font

    # No ws.title assignment and no create_sheet call anywhere in this writer.
    wb.save(output_path)