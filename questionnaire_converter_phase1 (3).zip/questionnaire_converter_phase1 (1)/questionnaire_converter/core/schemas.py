from typing import Optional, Literal
from pydantic import BaseModel, Field, ConfigDict

class SurveyRow(BaseModel):
    model_config = ConfigDict(extra="forbid")
    Row_Type: str = Field(description="Usually Question or blank for continuation option rows.")
    Q_No: Optional[str] = Field(default=None, description="Original question number, including suffixes such as 16a or 16b. Use Q0 for a termination message if needed.")
    Q_Text: Optional[str] = None
    Q_Type: Optional[str] = Field(default=None, description="Use SINGLE, MULTIPLE, GRID, OPEN, or null when unclear.")
    Option_No: Optional[str] = None
    Option_Text: Optional[str] = None
    Option_choosing: Optional[str] = Field(default=None, description="Usually Yes for selectable options; null for non-option rows.")
    Logic: Optional[str] = Field(default=None, description="Normalized logic such as TERMINATE, ANCHOR, EXCLUSIVE, DISPLAY_IF, PIPE_IN, RANDOMIZE, OPEN_TEXT_IF.")
    ROUTING: Optional[str] = Field(default=None, description="Next question number, Q0, END, or a concise explicit routing destination. Do not invent a destination.")

class ExtractionResult(BaseModel):
    rows: list[SurveyRow]
    review_notes: list[str] = Field(default_factory=list)
