from docx import Document
from docx.oxml.text.paragraph import CT_P
from docx.oxml.table import CT_Tbl
from docx.text.paragraph import Paragraph
from docx.table import Table

def _run_color(run):
    try:
        rgb = run.font.color.rgb
        if rgb:
            return str(rgb)
    except Exception:
        pass
    return None

def _paragraph_text(paragraph):
    pieces = []
    for run in paragraph.runs:
        text = run.text
        if not text:
            continue
        color = _run_color(run)
        if color:
            pieces.append(f"{text} [FONT_COLOR=#{color}]")
        else:
            pieces.append(text)
    return "".join(pieces).strip()

def parse_docx(path: str) -> str:
    """Extract body paragraphs and tables in document order, retaining simple font-color hints."""
    doc = Document(path)
    output = []
    body = doc.element.body
    para_index = 0
    table_index = 0
    for child in body.iterchildren():
        if isinstance(child, CT_P):
            para = Paragraph(child, doc)
            text = _paragraph_text(para)
            if text:
                para_index += 1
                output.append(f"[PARAGRAPH {para_index}] {text}")
        elif isinstance(child, CT_Tbl):
            table = Table(child, doc)
            table_index += 1
            output.append(f"[TABLE {table_index}]")
            for row_idx, row in enumerate(table.rows, start=1):
                cells = []
                for cell in row.cells:
                    value = " ".join(p.text.strip() for p in cell.paragraphs if p.text.strip())
                    cells.append(value.replace("\n", " "))
                # Preserve columns, including blank cells, because blank cells may indicate layout.
                output.append(" | ".join(cells))
            output.append(f"[/TABLE {table_index}]")
    return "\n".join(output)
