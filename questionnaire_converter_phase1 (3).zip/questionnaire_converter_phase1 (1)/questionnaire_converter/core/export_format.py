"""Export-time formatting helpers (pure functions, no Excel / AI dependencies)."""
import re

_ID_PREFIX = re.compile(r"^\s*Q\s*", re.IGNORECASE)
_Q_TOKEN = re.compile(r"\bQ\s*([A-Za-z]?\d+[A-Za-z]?)\b", re.IGNORECASE)
_BARE = re.compile(r"^\s*([A-Za-z]?\d+[A-Za-z]?)\s*$")
_SPECIAL = {"END", "TERMINATE", "Q0", "0"}


def _get(row, key):
    if isinstance(row, dict):
        return row.get(key)
    return getattr(row, key, None)


def _set(row, key, value):
    if isinstance(row, dict):
        row[key] = value
    else:
        setattr(row, key, value)


def _text(value):
    return "" if value is None else str(value).strip()


def _norm_id(value):
    return _ID_PREFIX.sub("", _text(value)).strip().casefold()


def is_question_row(row):
    row_type = _text(_get(row, "Row_Type")).casefold()
    return row_type == "question" or (row_type in ("", "question") and bool(_text(_get(row, "Q_Text"))))


def build_label_map(rows):
    """Map normalised question id -> question number exactly as written in the questionnaire.

    '2' stays '2'; 'Q2' stays 'Q2'; '16a' stays '16a'.
    """
    labels = {}
    for row in rows:
        if is_question_row(row) and _text(_get(row, "Q_No")):
            labels.setdefault(_norm_id(_get(row, "Q_No")), _text(_get(row, "Q_No")))
    if not labels:  # fallback: any row that carries a question number
        for row in rows:
            if _text(_get(row, "Q_No")):
                labels.setdefault(_norm_id(_get(row, "Q_No")), _text(_get(row, "Q_No")))
    return labels


def convert_route(route, labels):
    """Rewrite destination question numbers in a ROUTING value to the document's own numbering."""
    text = _text(route)
    if not text or text.upper() in _SPECIAL:
        return route
    bare = _BARE.match(text)
    if bare:
        key = _norm_id(text)
        if key in labels:
            return labels[key]
        return route

    def repl(match):
        key = match.group(1).casefold()
        if key in labels and key != "0":
            return labels[key]
        return match.group(0)

    return _Q_TOKEN.sub(repl, text)


def normalize_routing_labels(rows):
    """Make every ROUTING destination use the exact question-number format of the source document."""
    labels = build_label_map(rows)
    for row in rows:
        route = _get(row, "ROUTING")
        if _text(route):
            _set(row, "ROUTING", convert_route(route, labels))
    return rows


def blank_option_question_numbers(rows):
    """Keep Q_No only on question rows; option / continuation rows get a blank Q_No."""
    for row in rows:
        row_type = _text(_get(row, "Row_Type")).casefold()
        if row_type in ("", "option") and not _text(_get(row, "Q_Text")):
            _set(row, "Q_No", None)
    return rows


def prepare_export_rows(rows):
    """Plain-dict copy of the rows, formatted for the final Excel."""
    prepared = []
    for item in rows:
        if hasattr(item, "model_dump"):
            data = item.model_dump()
        else:
            data = dict(item)
        prepared.append(data)
    normalize_routing_labels(prepared)      # needs Q_No on question rows
    blank_option_question_numbers(prepared)  # then drop Q_No from option rows
    return prepared