"""
playwright_runner.py
=====================
Drives a real browser (via Playwright) through the survey described by
survey_model.load_survey(), testing every single option of every
question and logging PASS / FAIL for each one.

HOW A SURVEY PLATFORM'S HTML VARIES
------------------------------------
Every survey tool (Decipher, Confirmit, Qualtrics, custom builds, etc.)
renders its options and "Next" button slightly differently. This runner
tries several generic, resilient strategies before giving up, but if
your survey uses something unusual, tweak the two functions:

    select_option(page, option_text)
    click_next(page)

and the keyword lists in TERMINATION_KEYWORDS / NEXT_BUTTON_TEXTS near
the top of this file. Everything else (graph traversal, pass/fail
logic, reporting) will keep working unchanged.
"""

import os
import re
import time
import datetime
import threading
import traceback
from dataclasses import dataclass, field
from difflib import SequenceMatcher

from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

# ----------------------------------------------------------------------
# CONFIG -- tweak these to match the real survey's markup if needed
# ----------------------------------------------------------------------

NEXT_BUTTON_TEXTS = [
    "Next", "Continue", "Submit", "NEXT", "Continue »", "Next »", ">>",
    "Proceed", "OK", "Confirm",
]

TERMINATION_KEYWORDS = [
    "thank you for your interest", "does not qualify", "not eligible",
    "screened out", "quota is full", "quota full", "disqualified",
    "survey has ended", "you do not qualify", "does not match our",
    "terminate", "sorry, you", "no longer available", "closed",
    "isn’t the right fit", "isn't the right fit", "we look forward to inviting you",
    "Thank you for your time. However, you have not qualified to take part in the detailed survey. We hope to collaborate for any other future surveys.",
]

# Some questionnaire rows don't represent a literal clickable option -- their
# Option_Text is instead a KEYWORD flag meaning "this row is an open-text
# 'specify' control" (e.g. a "Other States & Territories (specify)" radio
# paired with a free-text box). The literal string never appears on the live
# page, so it must never be searched for as if it were real option text --
# it must be recognised and routed to select_specify_option() instead.
SPECIFY_KEYWORDS = {"enter text"}
DEFAULT_SPECIFY_TEXT = "Automated test entry"

# Some rows have NOTHING to select at all -- a plain informational/message
# screen (e.g. "We are almost done with the survey. Please click Next to
# continue.") that only has a Next button, no options, checkboxes, or radios.
# The sheet still needs a placeholder Option_No/Option_Text row so ROUTING
# has somewhere to attach, so the author flags it with this keyword instead
# of real option text. Recognised the same way SPECIFY_KEYWORDS is: never
# searched for as literal text, just tells the runner to click Next directly.
NO_OPTION_KEYWORDS = {"no option"}

# "<label>(enter text)" rows, e.g. "Others(enter text)".
# Unlike the bare "enter text" keyword above (where the row has NO label of its
# own, so the runner just finds the free-text box), here the row carries a real
# label -- "Others" -- that must be found on the live page first. The suffix
# "(enter text)" is only a flag meaning "after selecting this option, also type
# into its text box"; it is never searched for as literal page text.
LABELED_SPECIFY_RE = re.compile(r"^(?P<label>.+?)\s*\(\s*enter\s+text\s*\)\s*$", re.IGNORECASE)

# Labels that MUST be the LAST option of their question are now declared in the
# sheet itself (Logic = "ANCHOR AT THE END" on that option's row) and checked by
# _test_option_order(). The old hard-coded "anything starting with 'other' must
# be last" rule is therefore switched off (empty tuple). Put prefixes back here
# only if you want that automatic rule again for options WITHOUT the Logic word.
MUST_BE_LAST_LABEL_PREFIXES = ()

DEFAULT_TIMEOUT_MS = 8000
NAV_TIMEOUT_MS = 30000      # separate, longer timeout just for page.goto (survey hosts can be slow)
NAV_RETRY_ATTEMPTS = 3
INTER_TEST_DELAY_MS = 1200  # brief pause between tests so we don't look like a bot flooding the host
PAGE_SETTLE_MS = 900        # brief wait after navigation/clicks for SPA re-render

# Some questions (brand-logo grids, image-heavy matrix tables like the
# CooperVision/Alcon "which statement do you associate with this brand"
# screens) simply take longer to finish rendering than a plain
# text-only question -- especially once several parallel browser windows
# are competing for the same CPU/network. The default _poll_until_settled()
# window (900ms initial + up to 3000ms polling, ~3.9s total) can time out
# on these before the page is actually done, wrongly recording "unrecognized
# page" even though the correct page loads a moment later (visible in the
# failure screenshot, which is taken slightly after the FAIL is decided).
# Give the routing-check poll noticeably more headroom.
ROUTING_SETTLE_MAX_WAIT_MS = 15000

# Browser window sizing for non-headless runs (unchecking "Run headless"
# in the GUI to watch the browser). Has no visible effect when
# headless=True -- there's no window to size in that case.
# Full size (maximized) rather than a fixed compact box.
BROWSER_START_MAXIMIZED = True

# Folder (relative to the current working directory, unless run_tests() is
# given an explicit screenshots_dir) where evidence screenshots of FAILED
# tests are saved -- e.g. an option flagged TERMINATION in the sheet that
# instead let the survey continue to the next question. Each run gets its
# own timestamped subfolder so re-runs never overwrite a previous run's
# evidence.
SCREENSHOTS_ROOT_DIR = "failure_screenshots"


def _browser_launch_args(worker_id=0):
    """
    Chromium launch args controlling the visible test window when running
    non-headless. Currently set to open full size (maximized) rather than a
    small fixed box.
    """
    if BROWSER_START_MAXIMIZED:
        return ["--start-maximized"]
    return []


def goto_with_retry(page, url, log, attempts=NAV_RETRY_ATTEMPTS):
    """
    Navigate to the survey URL, retrying with backoff on timeout. Survey hosts
    (Confirmit, Decipher, etc.) can be slow to respond or briefly rate-limit
    rapid repeated requests from the same IP -- a single 8s timeout isn't
    always enough. Returns True on success, False if all attempts failed.
    """
    for i in range(attempts):
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=NAV_TIMEOUT_MS)
            return True
        except PWTimeout:
            if i < attempts - 1:
                backoff_ms = 2000 * (i + 1)
                log(f"    (navigation timeout, retrying in {backoff_ms}ms... attempt {i + 2}/{attempts})")
                page.wait_for_timeout(backoff_ms)
            else:
                log(f"    (navigation timeout after {attempts} attempts)")
    return False


def is_specify_option(option_text):
    """
    True if this row's Option_Text is the "Enter text" keyword flag rather
    than real, literal option text -- i.e. it marks an open-text "other,
    please specify" control (see SPECIFY_KEYWORDS above). This is a keyword
    check only, never a literal option to click/match on the page.
    """
    return (option_text or "").strip().lower() in SPECIFY_KEYWORDS


def is_no_option_row(option_text):
    """
    True if this row's Option_Text is the "no option" keyword flag -- a
    message/interstitial screen with nothing to select, just a Next button
    (see NO_OPTION_KEYWORDS above). This is a keyword check only, never a
    literal option to click/match on the page.
    """
    return (option_text or "").strip().lower() in NO_OPTION_KEYWORDS


class OptionOrderError(Exception):
    """
    Raised when an option that must be the LAST one on the page (see
    MUST_BE_LAST_LABEL_PREFIXES -- e.g. "Others") is present but is NOT last.
    This is a survey-layout defect, not a missing option, so it is raised
    instead of returning False (which would be reported as "option not found").
    """


def parse_labeled_specify(option_text):
    """
    If option_text looks like "<label>(enter text)" (e.g. "Others(enter text)"
    or "Others (enter text)"), return the bare label ("Others"). Returns None
    for anything else -- including the bare "enter text" keyword, which
    is_specify_option() handles separately.
    """
    m = LABELED_SPECIFY_RE.match(_normalize_ws(option_text or ""))
    return m.group("label").strip() if m else None


def is_specify_row(option_text):
    """
    True for EITHER kind of "enter text" row: the bare "enter text" keyword, or
    "<label>(enter text)". Neither appears literally on the live page (the
    page shows e.g. "Others (please specify)"), so both are excluded from the
    page-recognition checks that look for every option's literal text.
    """
    return is_specify_option(option_text) or parse_labeled_specify(option_text) is not None


# Runs inside the page. Lists every VISIBLE checkbox/radio (native or ARIA) in
# DOM order with its label text, finds the one whose label starts with `label`,
# and tags it (data-pw-opt-ctrl / data-pw-opt-row) so Python can grab the exact
# element that was position-checked. Visibility is judged on the option's
# label/row, not the <input> itself, because styled survey checkboxes often
# hide the real <input>.
_OPTION_ORDER_JS = r"""
(label) => {
  const norm = s => (s || '').replace(/[\u00a0\u2003]/g, ' ').replace(/\s+/g, ' ').trim().toLowerCase();
  document.querySelectorAll('[data-pw-opt-row],[data-pw-opt-ctrl]').forEach(e => {
    e.removeAttribute('data-pw-opt-row');
    e.removeAttribute('data-pw-opt-ctrl');
  });
  const shown = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    for (let n = el; n && n.nodeType === 1; n = n.parentElement) {
      const cs = getComputedStyle(n);
      if (cs.display === 'none' || cs.visibility === 'hidden') return false;
    }
    return true;
  };
  const items = [];
  document.querySelectorAll(
    'input[type="checkbox"], input[type="radio"], [role="checkbox"], [role="radio"]'
  ).forEach(c => {
    if (c.parentElement && c.parentElement.closest('[role="checkbox"], [role="radio"]')) return;
    let lab = c.closest('label');
    if (!lab && c.id) lab = document.querySelector('label[for="' + CSS.escape(c.id) + '"]');
    const row = lab || c.parentElement;
    if (!(shown(row) || shown(c))) return;
    let text = lab ? lab.innerText : '';
    if (!norm(text)) text = c.getAttribute('aria-label') || (c.parentElement ? c.parentElement.innerText : '');
    items.push({ctrl: c, row: row, text: norm(text)});
  });
  let want = norm(label);
  if (want.endsWith('s')) want = want.slice(0, -1);   // "others" also matches "other (please specify)"
  const idx = items.findIndex(it => it.text.startsWith(want));
  if (idx >= 0) {
    items[idx].row.setAttribute('data-pw-opt-row', '1');
    items[idx].ctrl.setAttribute('data-pw-opt-ctrl', '1');
  }
  return {found: idx >= 0, index: idx, total: items.length, labels: items.map(it => it.text.slice(0, 60))};
}
"""


def _fill_specify_near(page, row, fill_text):
    """
    Type into the free-text box that belongs to the option `row` (the option's
    own row first, then its parent container -- taking the LAST text box there,
    which is the right one when the option is last). Returns True if filled.
    """
    text_input = 'input[type="text"], input:not([type]), textarea'
    for scope in (row, row.locator("xpath=..")):
        try:
            loc = scope.locator(text_input)
            if loc.count() == 0:
                continue
            target = loc.last
            if not target.is_visible():
                continue
            target.scroll_into_view_if_needed(timeout=DEFAULT_TIMEOUT_MS)
            target.click(timeout=DEFAULT_TIMEOUT_MS)
            target.fill(fill_text, timeout=DEFAULT_TIMEOUT_MS)
            return True
        except Exception:
            continue
    return False


def select_labeled_specify_option(page, label, fill_text=DEFAULT_SPECIFY_TEXT, log=None):
    """
    Handle a "<label>(enter text)" row such as "Others(enter text)":

      1. Find the option whose page label starts with `label`.
      2. If `label` is in MUST_BE_LAST_LABEL_PREFIXES (e.g. "Others"), verify
         it is the LAST option of the question on the page. If it is not,
         raise OptionOrderError -- nothing is clicked or typed.
      3. Otherwise select it, then type fill_text into its text box.

    fill_text=None means "select the option but leave its text box EMPTY" (used
    by the MANDATORY check to test the blank-text case). Returns True if
    selected (+ filled), False if the option couldn't be found or its text box
    couldn't be filled (reported by the caller as a normal "option not found").
    Raises OptionOrderError when it isn't last.
    """
    info = page.evaluate(_OPTION_ORDER_JS, label)
    if not info["found"]:
        if log:
            log(f"    (no visible option starting with {label!r} found among "
                f"{info['total']} checkbox/radio control(s) on the page)")
        return False

    must_be_last = _normalize_ws(label).lower().startswith(MUST_BE_LAST_LABEL_PREFIXES)
    idx, total = info["index"], info["total"]
    if log:
        log(f"    {label!r} is option {idx + 1} of {total} on the page"
            f"{' (must be last)' if must_be_last else ''}")
    if must_be_last and idx != total - 1:
        after = info["labels"][idx + 1:]
        msg = (f"'{label}' option is not the last option on the page -- it is #{idx + 1} of "
               f"{total}, followed by: {after}. '{label}' must always be the last option.")
        if log:
            log(f"    !! {msg}")
        raise OptionOrderError(msg)

    ctrl = page.locator('[data-pw-opt-ctrl="1"]').first
    row = page.locator('[data-pw-opt-row="1"]').first
    row.scroll_into_view_if_needed(timeout=DEFAULT_TIMEOUT_MS)
    already_checked = False
    try:
        already_checked = ctrl.is_checked()   # never click an already-ticked box (that would UNtick it)
    except Exception:
        pass
    if not already_checked:
        try:
            if ctrl.is_visible():
                ctrl.check(timeout=DEFAULT_TIMEOUT_MS)
            else:
                row.click(timeout=DEFAULT_TIMEOUT_MS)
        except Exception:
            row.click(timeout=DEFAULT_TIMEOUT_MS)
    page.wait_for_timeout(300)  # the text box often only appears/enables once the option is selected

    if fill_text is None:
        return True  # select only -- text box deliberately left empty
    if _fill_specify_near(page, row, fill_text):
        return True
    return select_specify_option(page, fill_text)  # generic last-resort search for the text box


def select_specify_option(page, fill_text=DEFAULT_SPECIFY_TEXT):
    """
    Handle an "Other / please specify" style row flagged with the "Enter
    text" keyword in Excel. There is no literal "Enter text" label on the
    live page -- the real, human-facing label varies per survey (e.g.
    "Other States & Territories (specify)") and is often rendered as the
    placeholder text of an inline text input rather than a separate radio
    label. Try several resilient strategies to find that free-text control,
    interact with it (which auto-selects its paired radio/checkbox on most
    survey platforms), and fill in placeholder text.

    Returns True if a text field was found, focused, and filled.
    """
    strategies = [
        # 1) an input/textarea whose placeholder hints "specify" or "other"
        lambda: page.locator('input[type="text"][placeholder*="specify" i], '
                              'textarea[placeholder*="specify" i]'),
        lambda: page.locator('input[type="text"][placeholder*="other" i], '
                              'textarea[placeholder*="other" i]'),
        # 2) a text input/textarea nested inside a label mentioning
        #    "specify" or "other" (common when the label wraps both the
        #    radio and the open-text box together)
        lambda: page.locator('label:has-text("specify")').locator(
            'input[type="text"], textarea'),
        lambda: page.locator('label:has-text("other")').locator(
            'input[type="text"], textarea'),
        # 3) last resort -- the last visible free-text input on the page.
        #    "Specify" options are conventionally the last (or near-last)
        #    entry in an option list, right before "Prefer not to answer".
        lambda: page.locator('input[type="text"]:visible, textarea:visible'),
    ]
    for build_locator in strategies:
        try:
            loc = build_locator()
            if loc.count() > 0:
                target = loc.last  # "last" also covers strategy 3's intent; harmless for count==1 cases
                target.scroll_into_view_if_needed(timeout=DEFAULT_TIMEOUT_MS)
                target.click(timeout=DEFAULT_TIMEOUT_MS)  # often auto-selects the paired radio/checkbox
                target.fill(fill_text, timeout=DEFAULT_TIMEOUT_MS)
                return True
        except Exception:
            continue
    return False


def _first_visible(loc):
    """
    Return the first genuinely VISIBLE match from a locator, or None.

    Survey SPAs (this runner mainly targets Confirmit, Decipher, etc.) very
    often leave a previous, repeated, or upcoming question's markup sitting
    in the DOM -- hidden via CSS -- rather than removing it. A classic case
    is a checklist question (e.g. "who in your organization uses this
    device?") that repeats once per selected brand: the row labels
    ("Executive Leadership...", "IT Support team", ...) are IDENTICAL text
    across every brand's block, but only the CURRENT brand's block is
    actually visible.

    A plain `.first` on a text/label locator has no way to know that -- it
    happily grabs a HIDDEN duplicate purely because it appears earlier in
    DOM order, the click on it then fails or times out, and every fallback
    strategy hits that exact same hidden node. From the caller's point of
    view that's indistinguishable from "this option doesn't exist on the
    page" even though it's clearly visible on screen. Scanning for the
    first genuinely visible match fixes that.
    """
    try:
        count = loc.count()
    except Exception:
        return None
    for i in range(count):
        candidate = loc.nth(i)
        try:
            if _is_actually_active(candidate):
                return candidate
        except Exception:
            continue
    return None


def _is_actually_active(locator):
    """
    A stricter "is this really the live, interactive element" check than
    Playwright's own is_visible(). Some survey SPAs (Confirmit among them)
    leave a PREVIOUS question's answer controls sitting in the DOM rather
    than removing them, hidden only via opacity:0 and/or aria-hidden="true"
    on an ancestor -- neither of which Playwright's is_visible() checks (it
    only looks at display/visibility and a non-zero bounding box). A stale
    control hidden that way can still read as "visible" to is_visible(),
    get matched here, and -- worse -- if it's a radio/checkbox that was
    already checked back when its own question was answered, the
    already-checked short-circuit in _click_and_verify_checked() reports
    success without ever touching the CURRENT question's own control,
    silently leaving it unanswered.

    Uses the modern Element.checkVisibility() API (opacity + visibility +
    display + content-visibility all in one, well supported in the Chromium
    Playwright ships) plus an explicit aria-hidden ancestor check, which
    together catch every hiding technique is_visible() alone does not.
    Falls back to plain is_visible() if checkVisibility() isn't available.
    """
    try:
        return bool(locator.evaluate(
            """el => {
                if (el.closest('[aria-hidden="true"]')) return false;
                if (typeof el.checkVisibility === 'function') {
                    return el.checkVisibility({opacityProperty: true, visibilityProperty: true});
                }
                const r = el.getBoundingClientRect();
                if (r.width === 0 || r.height === 0) return false;
                for (let n = el; n && n.nodeType === 1; n = n.parentElement) {
                    const cs = getComputedStyle(n);
                    if (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0') return false;
                }
                return true;
            }"""
        ))
    except Exception:
        try:
            return locator.is_visible()
        except Exception:
            return False


def find_by_hidden_text_label(page, option_text, log=None):
    """
    Some survey platforms render a real, EXACT-text label for an option
    that exists only for screen readers -- a visually-hidden/"sr-only" span
    with zero width/height (position:absolute, clip:rect(0,0,0,0), etc.).
    The text genuinely IS in the DOM, character-for-character correct --
    it's just not "visible" by Playwright's definition (which requires a
    non-zero bounding box), so the plain text-matching strategies in
    select_option() find it and then reject it ("matched N element(s) but
    none were visible"). That's a strong, specific signal worth chasing
    BEFORE falling all the way back to AI vision -- an exact hidden-text
    match is strictly more reliable than any visual guess, when one is
    available at all.

    Finds any element containing the exact option_text (regardless of its
    own visibility), then walks up to the nearest ancestor that is a
    VISIBLE checkbox/radio control (or wraps exactly one) and returns that
    to click. Returns None if no such hidden label -> visible control path
    exists, so the caller falls through to AI vision as before.
    """
    try:
        matches = page.get_by_text(option_text, exact=True)
        total = matches.count()
    except Exception:
        return None
    for i in range(min(total, 10)):
        el = matches.nth(i)
        try:
            # 1) the hidden text IS the accessible label on a role=checkbox/
            #    radio ancestor (or is itself inside one)
            role_ancestor = el.locator("xpath=ancestor-or-self::*[@role='checkbox' or @role='radio'][1]")
            if role_ancestor.count() > 0 and role_ancestor.first.is_visible():
                if log:
                    log(f"    (found hidden text label {option_text!r} in the DOM -- "
                        f"using its visible checkbox/radio ancestor instead of guessing)")
                return role_ancestor.first
            # 2) the nearest label/div/td ancestor wraps a native visible
            #    checkbox/radio input
            wide = el.locator(
                "xpath=ancestor::*[self::label or self::div or self::td][1]"
                "//input[@type='checkbox' or @type='radio']"
            )
            if wide.count() > 0 and wide.first.is_visible():
                if log:
                    log(f"    (found hidden text label {option_text!r} in the DOM -- "
                        f"using its visible checkbox/radio ancestor instead of guessing)")
                return wide.first
        except Exception:
            continue
    return None


def _has_visual_content(locator):
    """
    True if this element (or any descendant) actually contains an <img>
    or a CSS background-image -- i.e. it's plausible this is the crop
    that holds the logo, not just the bare checkbox/radio square.

    Needed because Confirmit-style logo grids often put the checkbox and
    the logo image in SIBLING cells under a shared row, rather than one
    inside the other. Without this check, the ancestor-walk in
    _select_image_option stops as soon as it finds a wrapper that
    contains exactly one control -- which can be the checkbox's own
    tiny <td>, with the logo sitting in the cell next door and never
    making it into the screenshot at all.
    """
    try:
        if locator.locator("img").count() > 0:
            return True
    except Exception:
        pass
    try:
        return bool(locator.evaluate(
            """el => {
                function hasBg(node) {
                    if (!node || node.nodeType !== 1) return false;
                    const bg = getComputedStyle(node).backgroundImage;
                    if (bg && bg !== 'none') return true;
                    for (const child of node.children) {
                        if (hasBg(child)) return true;
                    }
                    return false;
                }
                return hasBg(el);
            }"""
        ))
    except Exception:
        return False


def _select_image_option(page, option_text, log=None):
    """
    Tried automatically by select_option() as the FIRST attempt for any
    option with no matchable text at all, but ONLY when the calling
    question's Q_Type is "Image" in the routing sheet (see select_option's
    q_type gate) -- before falling through to the on_manual_help_needed
    human prompt if this also can't find a confident match. This keeps
    manual intervention reserved for the genuinely ambiguous remainder
    instead of every single image-based option, since choosing every
    image option by hand across every parallel test window was too slow
    in practice.

    (Original docstring below, describing what it does when called.)

    Last-resort fallback for options that have NO text on the page at all
    to match against -- e.g. a checkbox next to a brand-logo image with no
    alt text and no label. Every strategy in select_option() below needs
    SOME text near the control; this is what runs when all of them have
    already failed.

    IMPORTANT: this anchors on the CHECKBOX/RADIO CONTROL, not on <img>
    tags. Confirmit (and several other survey platforms) render logo
    grids as a CSS background-image on a plain <div>/<label> rather than
    a real <img> element -- searching for "img:visible" finds zero
    matches on those pages and the fallback silently gives up before ever
    calling the AI. Anchoring on the control itself and screenshotting its
    wrapping "option cell" (whatever it visually contains -- <img>,
    background-image div, SVG, anything) works regardless of markup.

    Also matches Confirmit's click-to-rank widget
    (div.cf-ranking-answer, role="button", aria-pressed) for ranking
    questions with unlabeled logo cards -- structurally the same "no
    visible text, only a buried image" problem as the checkbox logo
    grids, just with a button instead of a checkbox/radio as the control.
    See the is_checked()/aria-pressed handling and the final
    check()-falls-through-to-click() below for how the two widget types
    are told apart and driven correctly.

    Gathers every candidate's screenshot FIRST, then makes ONE comparative
    AI call (ai_assistant.identify_brand_logo_among) asking "which of
    these numbered logos is option_text?", with one retry if it comes back
    with no match. This replaced an earlier version that asked N
    independent isolated yes/no questions, one per candidate -- in
    practice that was flaky: the exact same logo grid would correctly
    match on one run and report "no match" on the next, because a single
    borderline crop got its own low-confidence "no" with nothing to
    compare it against. A single side-by-side comparative call is
    meaningfully more consistent.

    Requires an OpenAI API key to already be configured (see
    ai_assistant.load_api_key()). If no key is set, or the import/API call
    fails for any reason, this quietly returns False so the caller fails
    the test the normal way instead of crashing the whole run over a
    missing/invalid key.
    """
    try:
        import ai_assistant
    except Exception as e:
        if log:
            log(f"    (image-option AI fallback unavailable: {e})")
        return False

    api_key = ai_assistant.load_api_key()
    if not api_key:
        if log:
            log("    (image-option AI fallback skipped: no OpenAI API key configured -- "
                "set one via the chat bubble's 'Set API key' dialog)")
        return False

    controls = page.locator(
        'input[type="checkbox"]:visible, input[type="radio"]:visible, '
        '[role="checkbox"]:visible, [role="radio"]:visible, '
        '.cf-ranking-answer[role="button"]:visible'
    )
    count = controls.count()
    if count == 0:
        if log:
            log(f"    (image-option AI fallback: no checkbox/radio/ranking controls found on page at all)")
        return False

    if log:
        log(f"    No text match for '{option_text}' -- trying AI image recognition "
            f"on up to {count} unlabeled control(s)...")

    # Pass 1: gather every candidate's control + screenshot without calling
    # the AI yet, so we can send them all to the model together in one
    # comparative request instead of one isolated call per candidate.
    candidates = []  # list of (control, png_bytes)
    skip_not_visible = 0
    skip_already_selected = 0
    skip_has_own_text = []  # collect the actual text seen, for diagnostics
    skip_exception = 0
    for i in range(count):
        control = controls.nth(i)
        try:
            if not control.is_visible():
                skip_not_visible += 1
                continue

            # "Already selected, leave it alone" -- but the exact signal
            # differs by widget type. Native/ARIA checkboxes and radios
            # expose is_checked() directly. Confirmit's click-to-rank
            # widget (div.cf-ranking-answer, role="button") has no
            # checked state at all -- it uses aria-pressed="true" once
            # you've tapped it to give it a rank. Calling is_checked() on
            # one of these raises, which used to get swallowed by the
            # broad `except Exception: continue` below and silently drop
            # every ranking button from consideration before it was ever
            # screenshotted -- checking the right attribute per widget
            # type avoids that.
            try:
                already_selected = control.is_checked()
            except Exception:
                aria_pressed = (control.get_attribute("aria-pressed") or "").strip().lower()
                already_selected = aria_pressed == "true"
            if already_selected:
                skip_already_selected += 1
                continue

            # Screenshot the smallest sensible wrapping "option cell" (the
            # nearest label/div/td ancestor) rather than the tiny checkbox
            # square itself, so whatever visual content it actually holds
            # gets captured. Walk up ancestor-by-ancestor and STOP at the
            # first one that wraps exactly this one control -- if the
            # nearest label/div/td actually wraps MULTIPLE checkboxes (a
            # shared row container holding several logos side by side
            # instead of one-cell-per-logo markup), screenshotting it would
            # show more than one brand in a single image. Prefer the
            # tightest ancestor that contains only this control; only fall
            # back to a wider one if nothing narrower exists at all.
            #
            # IMPORTANT: Playwright's xpath=ancestor::* locator, combined
            # with .nth(), returns ancestors in DOCUMENT order (outermost
            # first / closest-to-<html> first) -- NOT closest-to-control
            # first, despite XPath's "ancestor" axis conceptually being a
            # reverse axis. This is a well-known WebDriver/CDP quirk: the
            # ordered-node snapshot used under the hood normalizes results
            # to document order regardless of axis direction. So .nth(0)
            # is the FURTHEST ancestor, and .nth(count-1) is the CLOSEST
            # one to the control. Iterate from the end backward to actually
            # climb inner-to-outer as intended -- getting this backward
            # (as an earlier version of this code did) means the "narrowest
            # ancestor" logic instead finds the WIDEST one first: on a page
            # with only one control at all (e.g. a lone ranking-answer
            # button), "exactly one control" and "has visual content" can
            # both be true even at the outermost wrapper, so it would
            # accept practically the entire page as the crop on the very
            # first check and stop -- which is silently "correct" only by
            # coincidence on pages with several controls (where the
            # outermost level has more than one control and bails out
            # immediately into the >1 branch instead).
            target = control
            narrowest_single_control_ancestor = None
            ancestors = control.locator("xpath=ancestor::*[self::label or self::div or self::td or self::tr]")
            total_ancestors = ancestors.count()
            climb_order = range(total_ancestors - 1, max(total_ancestors - 9, -1), -1)
            for lvl in climb_order:
                cand_ancestor = ancestors.nth(lvl)
                try:
                    own_controls = cand_ancestor.locator(
                        'input[type="checkbox"], input[type="radio"], [role="checkbox"], [role="radio"], '
                        '.cf-ranking-answer[role="button"]'
                    ).count()
                except Exception:
                    continue
                if own_controls == 1:
                    # Remember the narrowest wrapper that's still "just this
                    # one option" -- fallback if nothing below has visual
                    # content, so we don't crash back out to `control` alone.
                    if narrowest_single_control_ancestor is None:
                        narrowest_single_control_ancestor = cand_ancestor
                    # Keep climbing past this level if it doesn't actually
                    # contain the logo yet -- checkbox and logo are often
                    # SIBLING cells under a shared row, so the checkbox's own
                    # immediate wrapper can satisfy "exactly one control"
                    # while still being visually empty.
                    if _has_visual_content(cand_ancestor):
                        target = cand_ancestor
                        break
                elif own_controls > 1:
                    # Climbed too far -- this level now spans multiple
                    # options. Stop; use whatever we've got so far.
                    break
            else:
                # Never found a single-control ancestor with visual content
                # within the level cap -- better to use the narrowest
                # single-control wrapper (may still be logo-less) than the
                # bare control, which is guaranteed to be logo-less.
                if narrowest_single_control_ancestor is not None:
                    target = narrowest_single_control_ancestor

            try:
                text_content = (target.inner_text(timeout=1000) or "").strip()
            except Exception:
                text_content = ""
            # Real, substantial visible text next to this control means
            # it's a normal TEXT option -- the strategies above already
            # tried and rejected it for this option_text, so don't waste
            # it in the AI call.
            if len(text_content) > 3:
                skip_has_own_text.append(text_content)
                continue

            # Scroll the cell into view BEFORE screenshotting it, and wait
            # for any <img> inside it to actually finish loading. Logo
            # grids are frequently lazy-loaded (image src only swapped in
            # once the cell scrolls into the viewport, via IntersectionObserver
            # or similar) -- screenshotting immediately, before that happens,
            # captures the cell mid-collapse: a thin, mostly-empty strip
            # instead of its real height with the logo rendered in it. That
            # produces a technically-valid but visually blank crop, which
            # the AI then (correctly, given what it was shown) can't match
            # to any brand -- this isn't a vision/recognition failure, it's
            # a race between our screenshot and the page's own image
            # loading. Waiting here for real image-complete state fixes it
            # at the source instead of trying to detect a bad crop after
            # the fact.
            try:
                target.scroll_into_view_if_needed(timeout=DEFAULT_TIMEOUT_MS)
            except Exception:
                pass
            try:
                imgs_in_target = target.locator("img")
                img_count = imgs_in_target.count()
            except Exception:
                img_count = 0
            if img_count > 0:
                try:
                    page.wait_for_function(
                        """(el) => {
                            const imgs = el.querySelectorAll('img');
                            if (imgs.length === 0) return true;
                            return Array.from(imgs).every(
                                img => img.complete && img.naturalWidth > 0
                            );
                        }""",
                        arg=target.element_handle(timeout=1000),
                        timeout=3000,
                    )
                except Exception:
                    # Didn't finish loading within the wait -- fall through
                    # and screenshot whatever's there anyway rather than
                    # abandoning this candidate; the size-vs-checkbox flag
                    # in the debug log will still surface a collapsed crop.
                    pass
            else:
                # No <img> tag at all -- may be a CSS background-image
                # instead (common on Confirmit). Those don't have a JS
                # "loaded" flag to poll, but they also don't lazy-collapse
                # the same way; a brief settle is still cheap insurance.
                page.wait_for_timeout(150)

            try:
                control_box = control.bounding_box()
            except Exception:
                control_box = None

            try:
                box = target.bounding_box()
            except Exception:
                box = None
            png_bytes = target.screenshot(timeout=DEFAULT_TIMEOUT_MS)
            candidates.append((control, png_bytes, box, control_box))
        except Exception as e:
            skip_exception += 1
            if log:
                log(f"      (candidate {i+1}: skipped due to exception -- {type(e).__name__}: {e})")
            continue

    if not candidates:
        if log:
            log(f"    AI vision fallback: found {count} control(s) but none became a "
                f"usable candidate -- not_visible={skip_not_visible}, "
                f"already_selected={skip_already_selected}, "
                f"had_own_text={len(skip_has_own_text)}, exceptions={skip_exception}")
            if skip_has_own_text:
                shown = skip_has_own_text[:5]
                more = f" (+{len(skip_has_own_text) - 5} more)" if len(skip_has_own_text) > 5 else ""
                log(f"      text seen on those controls: {shown!r}{more}")
        return False

    # DEBUG: save every candidate crop to disk exactly as it will be sent to
    # the AI, before making the API call. This is the fastest way to tell
    # apart "the AI is judging the images wrong" from "the AI is being sent
    # a bad/blank/miscropped image in the first place" -- open this folder
    # and look at what's actually in each numbered file.
    try:
        debug_dir = os.path.join(
            os.getcwd(), "ai_vision_debug",
            f"{datetime.datetime.now():%Y%m%d_%H%M%S}_{re.sub(r'[^A-Za-z0-9]+', '_', option_text)[:40]}",
        )
        os.makedirs(debug_dir, exist_ok=True)
        for i, (_control, png_bytes, box, control_box) in enumerate(candidates, start=1):
            with open(os.path.join(debug_dir, f"candidate_{i}.png"), "wb") as f:
                f.write(png_bytes)
            if log and box:
                w, h = round(box.get("width", 0)), round(box.get("height", 0))
                flag = ""
                if control_box:
                    cw = max(control_box.get("width", 0), 1)
                    ch = max(control_box.get("height", 0), 1)
                    # Relative check, not a fixed pixel cutoff -- resolution,
                    # zoom, and DPI vary by machine/screen, but a crop that's
                    # only marginally bigger than its OWN checkbox is still
                    # almost certainly just the checkbox with no logo in it,
                    # regardless of what those absolute pixel numbers are.
                    if (box.get("width", 0) < cw * 2) and (box.get("height", 0) < ch * 2):
                        flag = (f"  <-- barely bigger than its own checkbox "
                                f"({cw}x{ch}px) -- likely still just the checkbox")
                log(f"      candidate {i}: {w}x{h}px{flag}")
        if log:
            log(f"    (saved {len(candidates)} candidate crop(s) for inspection to: {debug_dir})")
    except Exception as e:
        if log:
            log(f"    (could not save debug crops: {e})")

    # Pass 2: one comparative call across all candidates. First attempt uses
    # the sharp, brand-logo-specific prompt (mode="brand") -- the reliable
    # framing for real brand/company names, which is most unlabeled-image
    # options in practice. Only if THAT finds nothing do we retry with the
    # broader mode="generic" prompt, which covers non-brand labels (colors,
    # icons/symbols for a reason or concept) that mode="brand" has no
    # correct answer for. Two DIFFERENT prompts, not the same one twice --
    # see identify_brand_logo_among()'s docstring for why retrying the
    # identical brand-specific wording doesn't help the non-brand case, and
    # why broadening that wording for everything made even the easy,
    # previously-reliable brand-logo case measurably less consistent.
    image_list = [png for _control, png, _box, _cbox in candidates]
    match_idx = None
    for attempt, mode in ((1, "brand"), (2, "generic")):
        try:
            match_idx = ai_assistant.identify_brand_logo_among(image_list, option_text, api_key, mode=mode)
        except Exception as e:
            if log:
                log(f"    (AI vision call failed on attempt {attempt} [{mode}]: {e})")
            match_idx = None
        if match_idx is not None:
            break
        if attempt == 1 and log:
            log(f"    AI vision found no brand-logo match for '{option_text}' among "
                f"{len(candidates)} candidate(s) -- retrying with a broader match (color/icon/symbol)...")

    if match_idx is None:
        if log:
            log(f"    AI vision fallback checked {len(candidates)} unlabeled candidate(s) "
                f"(brand-specific + broader attempt), no match found for '{option_text}'")
        return False

    control, _png, _box, _cbox = candidates[match_idx]
    if log:
        log(f"    AI matched '{option_text}' -> candidate #{match_idx}")
    try:
        control.scroll_into_view_if_needed(timeout=DEFAULT_TIMEOUT_MS)
        control.check(timeout=DEFAULT_TIMEOUT_MS)
    except Exception:
        # Also covers the click-to-rank widget (div.cf-ranking-answer,
        # role="button") -- it isn't a checkbox at all, so check() always
        # raises here, and a plain click is exactly the right action: it
        # taps the button once, which the widget itself turns into the
        # next available rank number (see find/_select_image_option's
        # docstring notes on cf-ranking-answer for the full shape of this).
        control.click(timeout=DEFAULT_TIMEOUT_MS)
    return True


# Runs inside the page for select_dropdown_option()'s native-<select> path.
# Finds the first VISIBLE <select> that has an option whose text matches
# `wanted` (normalized, exact first then startswith/contains), tags that
# <select> so Python can target it precisely, and returns the option's own
# exact label text (needed for Playwright's select_option(label=...), which
# requires an exact match).
_DROPDOWN_NATIVE_JS = r"""
(wanted) => {
  const norm = s => (s || '').replace(/[  ]/g, ' ').replace(/\s+/g, ' ').trim().toLowerCase();
  const shown = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    for (let n = el; n && n.nodeType === 1; n = n.parentElement) {
      const cs = getComputedStyle(n);
      if (cs.display === 'none' || cs.visibility === 'hidden') return false;
    }
    return true;
  };
  document.querySelectorAll('[data-pw-dd-select]').forEach(e => e.removeAttribute('data-pw-dd-select'));
  const want = norm(wanted);
  const selects = Array.from(document.querySelectorAll('select')).filter(shown);
  for (const sel of selects) {
    const opts = Array.from(sel.options);
    let m = opts.find(o => norm(o.text) === want || norm(o.value) === want);
    if (!m) m = opts.find(o => norm(o.text).startsWith(want) || want.startsWith(norm(o.text)));
    if (m && norm(m.text)) {
      sel.setAttribute('data-pw-dd-select', '1');
      return {found: true, label: m.text, selectCount: selects.length};
    }
  }
  return {found: false, selectCount: selects.length};
}
"""

# Runs inside the page for select_dropdown_option()'s custom-widget fallback,
# used when no native <select> matched (e.g. a styled div-based combobox).
# Step "trigger": finds a visible combobox/listbox-style trigger element that
# is NOT the Next/Back navigation button and tags it for Python to click.
# Step "option", called AFTER that click has opened the option list: finds a
# visible, clickable option/li/row whose text matches `wanted` among elements
# that were not part of the page before the trigger was clicked (so it can't
# accidentally match a same-named option row elsewhere on the page), and
# tags it for Python to click.
_DROPDOWN_CUSTOM_JS = r"""
([step, wanted]) => {
  const norm = s => (s || '').replace(/[  ]/g, ' ').replace(/\s+/g, ' ').trim().toLowerCase();
  const shown = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    for (let n = el; n && n.nodeType === 1; n = n.parentElement) {
      const cs = getComputedStyle(n);
      if (cs.display === 'none' || cs.visibility === 'hidden') return false;
    }
    return true;
  };
  if (step === 'trigger') {
    document.querySelectorAll('[data-pw-dd-trigger]').forEach(e => e.removeAttribute('data-pw-dd-trigger'));
    const isNav = el => /(next|back|continue|submit)/.test(norm(el.innerText || el.value || ''));
    const all = document.querySelectorAll('*');
    const candidates = Array.from(document.querySelectorAll(
      '[role="combobox"], [role="listbox"], [aria-haspopup="listbox"], [aria-haspopup="true"], ' +
      '.dropdown, .select, [class*="dropdown" i], [class*="Dropdown" i], [class*="combobox" i]'
    )).filter(el => shown(el) && !isNav(el));
    return {count: all.length, found: candidates.length > 0, elementCount: candidates.length,
            _tag: candidates.length > 0 ? (candidates[0].setAttribute('data-pw-dd-trigger', '1'), 1) : 0};
  }
  // step === 'option'
  const want = norm(wanted);
  const nodes = Array.from(document.querySelectorAll('body *')).filter(shown);
  document.querySelectorAll('[data-pw-dd-opt]').forEach(e => e.removeAttribute('data-pw-dd-opt'));
  let best = null;
  for (const el of nodes) {
    if (el.children.length > 0) continue;  // leaf text nodes only -- avoid matching a big wrapper
    const t = norm(el.innerText || el.textContent);
    if (t === want || (t && (t.startsWith(want) || want.startsWith(t)))) { best = el; if (t === want) break; }
  }
  if (best) { best.setAttribute('data-pw-dd-opt', '1'); return {found: true}; }
  return {found: false, total: nodes.length};
}
"""


def select_dropdown_option(page, option_text, log=None):
    """
    Select `option_text` on a question whose Logic column says DROPDOWN (see
    survey_model.parse_logic). Tries a real, native <select> first (the
    common case), then falls back to a generic click-to-open custom
    combobox/listbox widget if no native <select> matched.
    """
    wanted = _normalize_ws(option_text or "")

    info = page.evaluate(_DROPDOWN_NATIVE_JS, wanted)
    if info["found"]:
        try:
            page.locator('select[data-pw-dd-select="1"]').select_option(label=info["label"],
                                                                          timeout=DEFAULT_TIMEOUT_MS)
            if log:
                log(f"    dropdown: native <select>, chose {info['label']!r}")
            return True
        except Exception as e:
            if log:
                log(f"    dropdown: native <select> match found but selecting it failed ({e})")
    elif log:
        log(f"    dropdown: no native <select> among {info.get('selectCount', 0)} visible select(s) "
            f"has an option matching {wanted!r} -- trying a custom dropdown widget")

    # Custom widget fallback: click a combobox/listbox-style trigger, then
    # click the matching option that appears.
    trig = page.evaluate(_DROPDOWN_CUSTOM_JS, ["trigger", ""])
    if not trig["found"]:
        if log:
            log("    dropdown: no combobox/listbox trigger element found on the page either")
        return False
    try:
        trigger = page.locator('[data-pw-dd-trigger="1"]').first
        trigger.scroll_into_view_if_needed(timeout=DEFAULT_TIMEOUT_MS)
        trigger.click(timeout=DEFAULT_TIMEOUT_MS)
    except Exception as e:
        if log:
            log(f"    dropdown: could not click the dropdown trigger ({e})")
        return False
    page.wait_for_timeout(300)  # let the option list actually open/render

    opt_info = page.evaluate(_DROPDOWN_CUSTOM_JS, ["option", wanted])
    if not opt_info["found"]:
        if log:
            log(f"    dropdown: opened the trigger but no visible item matches {wanted!r}")
        return False
    try:
        item = page.locator('[data-pw-dd-opt="1"]').first
        item.scroll_into_view_if_needed(timeout=DEFAULT_TIMEOUT_MS)
        item.click(timeout=DEFAULT_TIMEOUT_MS)
        if log:
            log(f"    dropdown: custom widget, clicked matching item for {wanted!r}")
        return True
    except Exception as e:
        if log:
            log(f"    dropdown: found the matching item but clicking it failed ({e})")
        return False


def _click_and_verify_checked(page, locator, log=None, label=""):
    """
    Click a checkbox/radio-like control and verify it actually ended up
    checked -- some custom ARIA widgets (e.g. a Confirmit cf-single-answer
    div with role="radio" and its accessible name resolved via
    aria-labelledby, rather than a native <input>) accept a Locator.check()
    or .click() call without raising, and WITHOUT actually toggling their
    own state. That's the exact "click succeeded but nothing is selected"
    failure this whole precise-locator chain exists to catch -- without
    this verification, select_option() would report success, the caller
    clicks Next, and the resulting routing-mismatch gets misread as a
    logic/routing bug on a totally different question, instead of what it
    actually was: this option was never selected in the first place.

    Tries, in order, stopping as soon as verification passes:
      1. Locator.check() -- native checkbox/radio semantics, or
         Playwright's own ARIA-role handling for role=checkbox/role=radio.
      2. A plain Locator.click(), for widgets check() can't drive.
      3. A raw DOM el.click() via evaluate() -- bypasses Playwright's
         simulated mouse coordinates entirely, which helps when a
         decorative overlay or pseudo-element sits over the visible
         "clickable" area and absorbs the simulated pointer event.

    Returns True only once the element's own checked state (native
    .checked, or aria-checked="true") is verified true; False if none of
    the three attempts actually toggled it -- letting the caller fall
    through to the next, less-precise strategy instead of reporting a
    false success.
    """
    def is_checked():
        try:
            return bool(locator.evaluate(
                "el => el.checked === true || el.getAttribute('aria-checked') === 'true'"
            ))
        except Exception:
            return False

    if is_checked():
        return True  # already selected -- nothing to do (also avoids un-checking a radio)

    for attempt in ("check", "click", "js_click"):
        try:
            if attempt == "check":
                locator.check(timeout=DEFAULT_TIMEOUT_MS)
            elif attempt == "click":
                locator.click(timeout=DEFAULT_TIMEOUT_MS)
            else:
                locator.evaluate("el => el.click()")
        except Exception:
            pass
        page.wait_for_timeout(150)
        if is_checked():
            if log and attempt != "check":
                log(f"    (had to fall back to a {attempt} to actually select {label!r} -- "
                    f"the usual check() call didn't toggle it)")
            return True
    if log:
        log(f"    !! found the element for {label!r} but it never became checked/selected "
            f"after check(), click(), and a raw JS click")
    return False


def select_option(page, option_text, log=None, on_manual_help_needed=None, q_type=None, dropdown=False):
    """
    Try several strategies to select an answer option by its visible text.
    Returns True if something was clicked, False otherwise.

    If option_text is the "Enter text" keyword flag (see SPECIFY_KEYWORDS),
    this is not a literal option to search for -- it's routed to
    select_specify_option() instead, which finds and fills the real
    "other, please specify" text control on the page.

    If option_text is "<label>(enter text)" (e.g. "Others(enter text)"), it is
    routed to select_labeled_specify_option(): the labelled option is located,
    checked to be the LAST option on the page (raises OptionOrderError if not),
    then selected and its text box filled.

    dropdown (optional): True when the CURRENT QUESTION's Logic column says
    DROPDOWN (survey_model sets q["dropdown"]) -- routes straight to
    select_dropdown_option() (native <select> first, then a custom
    combobox/listbox widget) instead of the checkbox/radio strategies below.

    q_type (optional): the CURRENT QUESTION's Q_Type from the routing
    sheet (e.g. "SINGLE", "MULTIPLE", "Multi_Select", "Image"), passed
    through by every caller below that has the question dict on hand.
    The AI vision fallback (_select_image_option) is only ever attempted
    when this is "Image" (case-insensitive) -- it used to fire for ANY
    option that ran out of text-matching strategies, on any question
    type, which meant it could also fire on ordinary text questions
    where the real issue was a page-load timing hiccup or a locator
    mismatch, wasting an API call and occasionally guessing wrong instead
    of correctly reporting "option not found". Restricting it to
    Q_Type == "Image" (set explicitly in the routing sheet for genuine
    logo-grid questions, e.g. row 77 / A3a in the Bausch + Lomb sheet)
    makes it fire exactly where it's meant to and nowhere else. If
    q_type is not passed at all (None), the AI vision fallback is
    skipped -- callers should pass it whenever the question dict is
    available.

    on_manual_help_needed (optional): callable(option_text) -> bool. Called
    as the true last resort, ONLY when no text-based strategy AND the AI
    vision fallback (_select_image_option, tried first for a bare logo/
    image option with no matchable text, and only on Q_Type == "Image"
    questions) have both come up empty. The callable should show the
    person a prompt, BLOCK until they respond, and return True if they
    say they selected it manually (select_option then reports success and
    the caller's normal routing check decides PASS/FAIL exactly as for
    any other option), or False if they also couldn't find it (reported
    as a normal "option not found on page" failure, same message as
    before). If no callback is provided at all (e.g. an unattended
    headless run with nobody to ask), this returns False immediately once
    AI vision has also failed (or been skipped).
    """
    if dropdown and not is_specify_option(option_text) and parse_labeled_specify(option_text) is None:
        return select_dropdown_option(page, option_text, log=log)

    if is_specify_option(option_text):
        return select_specify_option(page)

    # "Others(enter text)" style row: find the labelled option, verify it's the
    # last one (raises OptionOrderError if not), then type into its text box.
    labeled_label = parse_labeled_specify(option_text)
    if labeled_label is not None:
        return select_labeled_specify_option(page, labeled_label, log=log)

    option_text = option_text.strip()

    # If this option's underlying control is an actual checkbox, go straight
    # for THAT specific element via find_checkbox_locator() before falling
    # back to fuzzy text matching below. This matters for short consent
    # labels like "I agree", where the exact same words often reappear
    # inside a much longer paragraph elsewhere on the page (e.g. "By
    # selecting 'I agree' below, I signify..."). The generic
    # `label has_text=option_text` search further down matches on substring
    # text and can grab that longer paragraph's label instead of the real
    # checkbox -- the click then "succeeds" (returns True) but never
    # actually toggles the checkbox, so a later click_next() proceeds with
    # the box still unchecked and the option_routing test wrongly reports a
    # routing failure. find_checkbox_locator() scopes to a label that
    # *wraps an actual input[type=checkbox]*, or an ARIA role=checkbox whose
    # accessible name matches, so it isn't fooled by a plain paragraph
    # containing the same phrase.
    try:
        precise = find_checkbox_locator(page, option_text, log=log)
        if precise is not None:
            precise.scroll_into_view_if_needed(timeout=DEFAULT_TIMEOUT_MS)
            if _click_and_verify_checked(page, precise, log=log, label=option_text):
                return True
    except Exception:
        pass  # fall through to the generic strategies below

    # Some survey platforms (e.g. Confirmit) render multi-select grid/matrix
    # cells as a custom div.cf-grid-multi-answer widget instead of a native
    # checkbox -- find_checkbox_locator() above will never match it since
    # there's no input[type=checkbox] or role=checkbox to find. Try it
    # before falling back to generic text-click, for the same reason the
    # precise checkbox locator is tried first: a plain text/label click can
    # "succeed" (no exception) without ever toggling the actual widget.
    try:
        grid_cell = find_cf_grid_control(page, option_text, log=log)
        if grid_cell is not None:
            grid_cell.scroll_into_view_if_needed(timeout=DEFAULT_TIMEOUT_MS)
            grid_cell.click(timeout=DEFAULT_TIMEOUT_MS)
            return True
    except Exception:
        pass  # fall through to the generic strategies below

    # A DIFFERENT Confirmit grid widget -- div.cf-grid-answer__scale-item,
    # role="checkbox" with a REAL aria-checked attribute, but whose own
    # label text is never rendered as visible text at all (only a logo
    # image); the statement text lives solely inside its aria-label. See
    # find_cf_scale_item_control()'s docstring for the full shape of this.
    # Every text-based strategy below is guaranteed to find nothing for
    # this widget, so try it here too, before falling through.
    try:
        scale_item = find_cf_scale_item_control(page, option_text, log=log)
        if scale_item is not None:
            scale_item.scroll_into_view_if_needed(timeout=DEFAULT_TIMEOUT_MS)
            if _click_and_verify_checked(page, scale_item, log=log, label=option_text):
                return True
    except Exception:
        pass  # fall through to the generic strategies below

    # YET ANOTHER Confirmit grid widget -- div.cf-accordion-grid-answer__scale-item
    # (a per-brand ACCORDION grid, e.g. a satisfaction scale repeated once per
    # brand behind a collapsible "Ajona" / "Colgate" / ... header). Unlike
    # cf-grid-answer__scale-item above, this one DOES render its own visible
    # text, but the SAME option text ("Absolutely satisfied", etc.) is
    # repeated once per brand section -- including brand sections that are
    # currently collapsed. A collapsed section's row is still a normal,
    # correctly-sized element in the DOM (only its ancestor clips it via
    # max-height/overflow, not display:none), so it can slip past ordinary
    # visibility checks and get clicked instead of the row that's actually
    # open on screen. find_cf_accordion_scale_item_control() and
    # _click_and_verify_checked_accordion() below are separate, additive
    # helpers written specifically to handle that -- deliberately NOT
    # reusing/altering find_cf_scale_item_control() or
    # _click_and_verify_checked(), so every other widget's behavior is
    # completely unchanged.
    try:
        accordion_item = find_cf_accordion_scale_item_control(page, option_text, log=log)
        if accordion_item is not None:
            accordion_item.scroll_into_view_if_needed(timeout=DEFAULT_TIMEOUT_MS)
            if _click_and_verify_checked_accordion(page, accordion_item, log=log, label=option_text):
                return True
    except Exception:
        pass  # fall through to the generic strategies below

    strategies = [
        # 1) an <label> wrapping the text (very common for radio/checkbox lists)
        lambda: page.locator("label", has_text=option_text),
        # 2) a clickable element whose accessible name matches
        lambda: page.get_by_text(option_text, exact=True),
        lambda: page.get_by_text(option_text, exact=False),
        # 3) a radio/checkbox input with a matching value or aria-label
        lambda: page.locator(
            f'input[type="radio"][value="{option_text}"], '
            f'input[type="checkbox"][value="{option_text}"]'
        ),
    ]
    for build_locator in strategies:
        try:
            loc = build_locator()
            total = loc.count()
            target = _first_visible(loc)
            if target is not None:
                target.scroll_into_view_if_needed(timeout=DEFAULT_TIMEOUT_MS)
                target.click(timeout=DEFAULT_TIMEOUT_MS)
                return True
            elif total > 0 and log:
                # Found the text, but every match was hidden -- almost
                # always a duplicate/repeated block elsewhere in the DOM
                # (a different brand/section of the same repeated
                # checklist question, an already-answered earlier
                # question the SPA never tore down, etc.), not a real
                # "option doesn't exist" situation.
                log(f"    (matched {total} element(s) for {option_text!r} but none were visible -- "
                    f"likely a hidden duplicate elsewhere on the page)")
        except Exception:
            continue

    # No VISIBLE text match -- before giving up, check whether the exact
    # text exists in the DOM as a screen-reader-only label (see
    # find_by_hidden_text_label's docstring). An exact hidden-text match
    # is a real, deterministic answer -- always worth checking regardless
    # of what happens next.
    try:
        hidden_label_target = find_by_hidden_text_label(page, option_text, log=log)
        if hidden_label_target is not None:
            hidden_label_target.scroll_into_view_if_needed(timeout=DEFAULT_TIMEOUT_MS)
            hidden_label_target.click(timeout=DEFAULT_TIMEOUT_MS)
            return True
    except Exception:
        pass  # fall through to AI vision, then the manual-help prompt below

    # Nothing with matching TEXT was found at all. This MIGHT be a bare
    # logo/image option (no alt text, no label) with nothing left to
    # text-match against -- but only try the AI vision fallback when the
    # routing sheet actually marked this question Q_Type == "Image". On
    # every other question type, a missing text match means something
    # else went wrong (timing, a locator mismatch, a genuinely absent
    # option) and guessing via image matching would be the wrong tool --
    # better to report "not found" honestly and let it fall through to
    # the manual-help prompt below.
    is_image_question = isinstance(q_type, str) and q_type.strip().upper() == "IMAGE"
    if is_image_question:
        if _select_image_option(page, option_text, log=log):
            return True
    elif log and q_type is not None:
        log(f"    (skipping AI image fallback for '{option_text}' -- "
            f"Q_Type is {q_type!r}, not Image)")

    # AI vision (or no API key/vision unavailable) also couldn't resolve
    # it -- ask a human to manually locate/select it instead, if anyone's
    # set up to be asked -- see on_manual_help_needed's docstring above.
    if on_manual_help_needed is not None:
        if log:
            log(f"    Could not automatically find '{option_text}' -- asking the person "
                f"running the test to select it manually...")
        try:
            user_says_selected = bool(on_manual_help_needed(option_text))
        except Exception as e:
            if log:
                log(f"    (manual-help prompt failed: {e})")
            user_says_selected = False
        if user_says_selected and log:
            log(f"    Person confirmed they manually selected '{option_text}' -- continuing.")
        elif log:
            log(f"    Person also could not find '{option_text}' on the page.")
        return user_says_selected

    return False


def detect_option_input_type(page, option_text):
    """
    Determine whether a given option's underlying form control is a checkbox
    or a radio button (native input or ARIA role). Returns "checkbox",
    "radio", or None if it can't be determined. This matters because a
    single-option SINGLE-select question (e.g. a language question with only
    one radio choice) behaves completely differently from a single-option
    agree/consent CHECKBOX (e.g. NDA "I agree") -- radios can't be
    meaningfully "unchecked" by clicking them again, browsers just ignore
    that, so we must not run the check-then-uncheck test against a radio.
    """
    option_text = option_text.strip()
    try:
        if page.locator("label", has_text=option_text).locator('input[type="checkbox"]').count() > 0:
            return "checkbox"
    except Exception:
        pass
    try:
        # Confirmit-style cf-grid-multi-answer div widget (no native input at
        # all -- see find_cf_grid_control()) behaves like a checkbox: it can
        # be toggled on and off freely, so check-then-uncheck is meaningful.
        if find_cf_grid_control(page, option_text) is not None:
            return "checkbox"
    except Exception:
        pass
    try:
        if page.locator("label", has_text=option_text).locator('input[type="radio"]').count() > 0:
            return "radio"
    except Exception:
        pass
    try:
        if page.get_by_role("checkbox", name=re.compile(re.escape(option_text), re.I)).count() > 0:
            return "checkbox"
    except Exception:
        pass
    try:
        if page.get_by_role("radio", name=re.compile(re.escape(option_text), re.I)).count() > 0:
            return "radio"
    except Exception:
        pass
    return None


def find_checkbox_locator(page, option_text, log=None):
    """
    Locate the actual checkbox/radio element for an option -- not just
    something clickable near its text, but the specific input/role element
    whose checked state we can read and verify. Scoped to the option's own
    label first; only falls back to a page-wide search if nothing scoped is
    found (e.g. markup where the label doesn't wrap the input).
    Only ever returns a VISIBLE match (see _first_visible) -- surveys often
    keep hidden duplicate/repeated blocks in the DOM, and a hidden
    checkbox/radio that happens to share the same label text is not a
    usable match.

    Matches BOTH checkboxes and radios (input[type="checkbox"|"radio"],
    role="checkbox"|"radio"). This matters for a plain SINGLE-select
    question rendered as radio buttons: without matching radios here too,
    every such option falls straight through to the generic fuzzy
    text-click strategies further down in select_option(), which have no
    way to verify the click actually toggled anything. That's usually
    harmless on a page where the option's label text is unique, but on a
    survey with several near-identical matrix pages in a row that repeat
    the same option labels (e.g. the same brand list on questions 7,
    7.1-7.4), a fuzzy click can land on a leftover/decoy element and
    report success while the real, currently-visible radio stays
    unchecked -- exactly the "click succeeded but nothing is selected"
    failure mode this function exists to prevent for checkboxes, now also
    covered for radios.
    """
    option_text = option_text.strip()
    both = 'input[type="checkbox"], input[type="radio"]'
    strategies = [
        # 1) a <label> that directly WRAPS the input (classic radio/checkbox list)
        lambda: page.locator("label", has_text=option_text).locator(both),
        # 2) MATRIX / GRID layout: the row's text and its checkbox sit in
        #    separate table cells of the same row rather than sharing a
        #    <label> (e.g. a "who uses this device?" grid with one row per
        #    team and a checkbox column per brand). Scope to the table row
        #    containing the text, then grab the checkbox inside that row.
        #    A plain click on the row's text cell in this layout finds an
        #    element and "succeeds" but never actually toggles anything --
        #    this strategy is what makes the click have a real effect.
        lambda: page.locator("tr", has_text=option_text).locator(both),
        # 3) same idea for ARIA grids that use role="row" instead of <tr>
        lambda: page.locator('[role="row"]', has_text=option_text).locator(both),
        # 4) role-based accessible name match (covers custom/non-native controls)
        lambda: page.get_by_role("checkbox", name=re.compile(re.escape(option_text), re.I)),
        lambda: page.get_by_role("radio", name=re.compile(re.escape(option_text), re.I)),
    ]
    for build_locator in strategies:
        try:
            loc = build_locator()
            total = loc.count()
            target = _first_visible(loc)
            if target is not None:
                if total > 1 and log:
                    log(f"    (row/label for {option_text!r} contains {total} checkboxes -- "
                        f"likely a multi-column matrix; using the first visible one, which may "
                        f"not always be the intended column)")
                return target
            elif total > 0 and log:
                log(f"    (matched {total} checkbox candidate(s) for {option_text!r} but none were visible)")
        except Exception:
            continue
    return None



def find_cf_grid_control(page, option_text, log=None):
    """
    Locate a Confirmit-style "cf-grid-multi-answer" cell control -- a custom
    <div class="cf-grid-multi-answer"> used in place of a native
    input[type=checkbox] for multi-select grid/matrix questions (e.g. "who
    in your organization uses this device?" with one column per brand).
    There is no <input> here at all; the div itself carries an extra
    "cf-grid-multi-answer--selected" class when checked, and click handling
    is bound directly to the div. Scoped to the row containing the option's
    label text first (same reasoning as find_checkbox_locator: avoid hidden
    duplicate rows elsewhere in the DOM), falling back to a page-wide search
    only if nothing scoped is found.
    """
    option_text = option_text.strip()
    strategies = [
        lambda: page.locator("tr", has_text=option_text).locator("div.cf-grid-multi-answer"),
        lambda: page.locator('[role="row"]', has_text=option_text).locator("div.cf-grid-multi-answer"),
        lambda: page.locator("div.cf-grid-multi-answer"),
    ]
    for build_locator in strategies:
        try:
            loc = build_locator()
            total = loc.count()
            target = _first_visible(loc)
            if target is not None:
                if total > 1 and log:
                    log(f"    (row/label for {option_text!r} contains {total} cf-grid-multi-answer cells -- "
                        f"likely a multi-column matrix; using the first visible one, which may "
                        f"not always be the intended column)")
                return target
            elif total > 0 and log:
                log(f"    (matched {total} cf-grid-multi-answer candidate(s) for {option_text!r} but none were visible)")
        except Exception:
            continue
    return None


def find_cf_scale_item_control(page, option_text, log=None):
    """
    Locate a Confirmit "cf-grid-answer__scale-item" cell -- yet another
    custom div-based grid/matrix widget, DISTINCT from cf-grid-multi-answer
    above (different class name, different markup, different state
    attribute). Seen on brand-association matrices where each ROW's
    "header" is rendered as a LOGO IMAGE rather than plain text (a
    <table><img></table> nested inside the cell's own <label>) -- e.g.:

        <div class="cf-grid-answer__scale-item" role="checkbox"
             aria-checked="true"
             aria-label="A brand that is well-known for toric and/or
                          multifocal lenses <table>...<img src="...
                          JandJ_ACUVUE.png" width='150'></table>">
          <label class="cf-grid-answer__scale-item-text">
            <table>...<img src="...JandJ_ACUVUE.png" width="150"></table>
          </label>
        </div>

    The row's real STATEMENT text ("A brand that is well-known for toric
    and/or multifocal lenses") is NEVER rendered as visible page text --
    it only exists inside the aria-label attribute, followed by a lump of
    raw, unrendered HTML source (apparently pasted in as a tooltip/logo
    reference and never cleaned up) that got appended straight onto the
    end of the same attribute. That's why every text-based strategy above
    (label has_text, get_by_text, etc.) finds nothing here: there is no
    visible text to match against, only this one buried attribute.

    This reads every candidate's raw aria-label directly via
    get_attribute() -- deliberately NOT via Playwright's
    get_by_role(name=...) accessible-name matching (which
    find_checkbox_locator() already tries as a generic fallback) -- so we
    control exactly how the comparison works: the statement text must be
    a case-insensitive, whitespace-normalized PREFIX of the aria-label.
    A prefix match survives the garbled trailing HTML while staying
    precise enough not to accidentally match some other statement whose
    aria-label happens to mention this one's words inside ITS OWN garbled
    tail.

    The div carries a real aria-checked attribute (unlike
    cf-grid-multi-answer's class-only state), so once located it can be
    driven with the normal check()/uncheck()/is_checked() API instead of
    class-string inspection.
    """
    option_text_norm = " ".join(option_text.strip().split()).lower()
    try:
        candidates = page.locator(
            'div.cf-grid-answer__scale-item[role="checkbox"], '
            'div.cf-grid-answer__scale-item[role="radio"]'
        )
        count = candidates.count()
    except Exception:
        return None

    matches = []
    for i in range(count):
        cand = candidates.nth(i)
        try:
            aria_label = cand.get_attribute("aria-label") or ""
        except Exception:
            continue
        label_norm = " ".join(aria_label.strip().split()).lower()
        if label_norm.startswith(option_text_norm):
            matches.append(cand)

    if not matches:
        return None

    visible_matches = []
    for cand in matches:
        try:
            if cand.is_visible():
                visible_matches.append(cand)
        except Exception:
            continue

    if not visible_matches:
        if log and matches:
            log(f"    (matched {len(matches)} cf-grid-answer__scale-item candidate(s) "
                f"for {option_text!r} but none were visible)")
        return None

    if len(visible_matches) > 1 and log:
        log(f"    (found {len(visible_matches)} visible cf-grid-answer__scale-item "
            f"candidate(s) for {option_text!r} -- using the first one, which may not "
            f"always be the intended row)")
    return visible_matches[0]


def _is_hit_testable(locator):
    """
    NEW, standalone helper -- deliberately separate from _is_actually_active()
    so nothing that already relies on _is_actually_active() changes behavior.

    Does a hit-test via document.elementFromPoint() at the element's own
    center: returns True only if the element (or something it contains, or
    something that contains it) is what's ACTUALLY painted at that pixel.

    This exists specifically for div.cf-accordion-grid-answer__scale-item:
    a row inside a COLLAPSED accordion brand-section (collapsed via an
    ancestor's max-height:0 / overflow:hidden, not display:none) keeps a
    normal non-zero bounding box and passes ordinary opacity/visibility/
    display checks, even though nothing is actually visible there. An
    elementFromPoint hit-test is what catches that: at the clipped row's own
    coordinates, the browser paints something else entirely (or nothing
    related to it), whereas a genuinely open/visible row's coordinates paint
    the row itself.

    Used ONLY by find_cf_accordion_scale_item_control() below -- not wired
    into _first_visible() or any other existing matcher, so every other
    widget's matching logic is completely unaffected.
    """
    try:
        return bool(locator.evaluate(
            """el => {
                const r = el.getBoundingClientRect();
                if (r.width === 0 || r.height === 0) return false;
                const cx = r.left + r.width / 2;
                const cy = r.top + r.height / 2;
                if (cx < 0 || cy < 0 || cx > (window.innerWidth || 0) || cy > (window.innerHeight || 0)) return false;
                const top = document.elementFromPoint(cx, cy);
                if (!top) return false;
                return top === el || el.contains(top) || top.contains(el);
            }"""
        ))
    except Exception:
        return False


def find_cf_accordion_scale_item_control(page, option_text, log=None):
    """
    Locate a Confirmit "cf-accordion-grid-answer__scale-item" cell -- a
    scale option (e.g. "Absolutely satisfied") inside a per-brand ACCORDION
    grid, e.g.:

        <div class="cf-list__item cf-accordion-grid-answer__scale-item"
             id="Q9_1_5" role="radio" aria-checked="true"
             aria-label="Ajona Absolutely satisfied ">
          <div class="cf-accordion-grid-answer__scale-item-text">
            Absolutely satisfied
          </div>
        </div>

    Unlike find_cf_scale_item_control()'s widget, this one DOES render its
    own visible text (in the .cf-accordion-grid-answer__scale-item-text
    child), so it's matched on that visible text (falling back to the
    aria-label, which is "<brand> <option text>", as a prefix/contains
    check) rather than aria-label alone.

    The same scale text is repeated once per brand's accordion section,
    including collapsed ones, so candidates are filtered with the
    hit-test in _is_hit_testable() -- NOT the existing _first_visible() /
    _is_actually_active() -- to make sure only the row that's actually
    painted on screen right now is picked.

    This is a brand-new, additive matcher: it does not change
    find_cf_scale_item_control(), find_cf_grid_control(), or
    find_checkbox_locator() in any way, so every other widget type this
    runner already handles keeps behaving exactly as before.
    """
    option_text_norm = " ".join(option_text.strip().split()).lower()
    try:
        candidates = page.locator(
            'div.cf-accordion-grid-answer__scale-item[role="radio"], '
            'div.cf-accordion-grid-answer__scale-item[role="checkbox"]'
        )
        count = candidates.count()
    except Exception:
        return None

    matches = []
    for i in range(count):
        cand = candidates.nth(i)
        own_text = ""
        try:
            own_text = " ".join((cand.inner_text() or "").strip().split()).lower()
        except Exception:
            pass
        if own_text == option_text_norm:
            matches.append(cand)
            continue
        try:
            aria_label = cand.get_attribute("aria-label") or ""
        except Exception:
            aria_label = ""
        label_norm = " ".join(aria_label.strip().split()).lower()
        if label_norm and option_text_norm in label_norm:
            matches.append(cand)

    if not matches:
        return None

    hit_testable = []
    for cand in matches:
        try:
            if _is_hit_testable(cand):
                hit_testable.append(cand)
        except Exception:
            continue

    if not hit_testable:
        if log and matches:
            log(f"    (matched {len(matches)} cf-accordion-grid-answer__scale-item candidate(s) "
                f"for {option_text!r} but none were actually painted on screen -- likely all "
                f"inside collapsed accordion sections)")
        return None

    if len(hit_testable) > 1 and log:
        log(f"    (found {len(hit_testable)} on-screen cf-accordion-grid-answer__scale-item "
            f"candidate(s) for {option_text!r} -- using the first one, which may not always "
            f"be the intended brand section)")
    return hit_testable[0]


def _click_and_verify_checked_accordion(page, locator, log=None, label=""):
    """
    Brand-new, additive twin of _click_and_verify_checked() -- used ONLY for
    div.cf-accordion-grid-answer__scale-item (via
    find_cf_accordion_scale_item_control() above). Deliberately NOT a change
    to _click_and_verify_checked() itself, so every other widget that
    already relies on that function keeps its exact existing behavior.

    Differs from _click_and_verify_checked() in two ways, both aimed at this
    one widget's observed real-world behavior:

      1. is_checked() ALSO accepts the "--selected" BEM class modifier
         (e.g. "cf-accordion-grid-answer__scale-item--selected") as
         evidence of selection, not just aria-checked/.checked.
      2. Polls for up to ~1.5s after each attempt (instead of a single
         150ms sleep) -- this widget's aria-checked/--selected update can
         lag noticeably behind the click under load (several parallel
         Playwright workers competing for CPU), and a short single sleep
         can check before the re-render has actually happened.
    """
    def is_checked():
        try:
            return bool(locator.evaluate(
                """el => el.checked === true
                    || el.getAttribute('aria-checked') === 'true'
                    || Array.from(el.classList || []).some(c => c.endsWith('--selected'))"""
            ))
        except Exception:
            return False

    if is_checked():
        return True

    VERIFY_POLL_MS = 1500
    VERIFY_POLL_STEP_MS = 100

    for attempt in ("check", "click", "js_click"):
        try:
            if attempt == "check":
                locator.check(timeout=DEFAULT_TIMEOUT_MS)
            elif attempt == "click":
                locator.click(timeout=DEFAULT_TIMEOUT_MS)
            else:
                locator.evaluate("el => el.click()")
        except Exception:
            pass
        waited = 0
        while waited <= VERIFY_POLL_MS:
            if is_checked():
                if log and attempt != "check":
                    log(f"    (had to fall back to a {attempt} to actually select {label!r} -- "
                        f"the usual check() call didn't toggle it)")
                return True
            page.wait_for_timeout(VERIFY_POLL_STEP_MS)
            waited += VERIFY_POLL_STEP_MS
    if log:
        log(f"    !! found the element for {label!r} but it never became checked/selected "
            f"after check(), click(), and a raw JS click")
    return False


def cf_grid_is_selected(div_locator):
    """
    True if a cf-grid-multi-answer div's class list carries the
    "cf-grid-multi-answer--selected" modifier -- this widget has no
    checked/aria-checked attribute at all, so class inspection is the only
    way to read its state.
    """
    try:
        class_attr = div_locator.get_attribute("class") or ""
    except Exception:
        return False
    return "cf-grid-multi-answer--selected" in class_attr.split()


def set_cf_grid_state(page, option_text, checked, log=None):
    """
    Reliably set a cf-grid-multi-answer cell to `checked` (True/False) and
    verify the class actually flipped, mirroring set_checkbox_state()'s
    contract but for this div-based widget instead of a native input.
    Returns True if the final state matches what was requested, False
    otherwise (including "couldn't find the control at all").
    """
    box = find_cf_grid_control(page, option_text, log=log)
    if box is None:
        return False
    try:
        currently = cf_grid_is_selected(box)
        if currently != checked:
            box.scroll_into_view_if_needed(timeout=DEFAULT_TIMEOUT_MS)
            box.click(timeout=DEFAULT_TIMEOUT_MS)
        actual = cf_grid_is_selected(box)
        if log:
            log(f"    cf-grid cell '{option_text}' set to checked={checked} -> actual checked={actual}")
        return actual == checked
    except Exception as e:
        if log:
            log(f"    !! cf-grid click failed for '{option_text}': {e}")
        return False


def set_checkbox_state(page, option_text, checked, log=None):
    """
    Reliably set a checkbox/agree-toggle to `checked` (True/False) and verify
    the state actually changed, instead of blindly clicking twice and hoping
    the second click undid the first. Playwright's check()/uncheck() read the
    real checked / aria-checked state and only click if a change is needed,
    which is what makes "click I agree, then click it again to uncheck"
    actually reliable. Returns True if the final state matches what was
    requested, False otherwise.
    """
    # Try the Confirmit-style cf-grid-multi-answer div widget first -- see
    # find_cf_grid_control()'s docstring. It has no checked/aria-checked
    # attribute at all, so it needs its own class-based state check rather
    # than box.is_checked() below, and set_cf_grid_state() already handles
    # that end-to-end (including the "click only if state needs to change"
    # logic that check()/uncheck() give native inputs for free).
    grid_box = find_cf_grid_control(page, option_text, log=log)
    if grid_box is not None:
        return set_cf_grid_state(page, option_text, checked, log=log)

    # The OTHER Confirmit grid widget -- div.cf-grid-answer__scale-item.
    # Unlike cf-grid-multi-answer, this one DOES have a real aria-checked
    # attribute, so once located it can use the same check()/uncheck()/
    # is_checked() path as a native checkbox below -- box.is_checked()
    # reads aria-checked directly. See find_cf_scale_item_control()'s
    # docstring for why it needs its own locator (its label text is never
    # rendered as visible text, only buried in aria-label).
    scale_item_box = find_cf_scale_item_control(page, option_text, log=log)
    if scale_item_box is not None:
        box = scale_item_box
    else:
        box = find_checkbox_locator(page, option_text, log=log)
    if box is None:
        if log:
            log(f"    !! could not locate a checkbox element for '{option_text}'")
        return False
    try:
        if checked:
            box.check(timeout=DEFAULT_TIMEOUT_MS)
        else:
            box.uncheck(timeout=DEFAULT_TIMEOUT_MS)
        actual = box.is_checked()
        if log:
            log(f"    checkbox '{option_text}' set to checked={checked} -> actual checked={actual}")
        return actual == checked
    except Exception as e:
        # Not a native checkbox / doesn't expose a readable checked state
        # (e.g. a custom div-based toggle with no role="checkbox"). Fall
        # back to a plain click and re-read whatever state we can, rather
        # than silently assuming it worked.
        if log:
            log(f"    (check()/uncheck() unsupported on this element: {e}; falling back to click)")
        try:
            box.click(timeout=DEFAULT_TIMEOUT_MS, force=True)
            try:
                actual = box.is_checked()
                if log:
                    log(f"    checkbox '{option_text}' after fallback click -> checked={actual}")
                return actual == checked
            except Exception:
                # can't read state at all -- we genuinely don't know if this worked
                if log:
                    log("    (could not read checked state after fallback click -- unverified)")
                return False
        except Exception as click_err:
            if log:
                log(f"    !! fallback click also failed: {click_err}")
            return False


def click_next(page):
    """
    Try to find and click the survey's Next/Continue/Submit button.

    Uses _first_visible() (the same strict, stale-element-aware visibility
    check used for options -- see find_checkbox_locator) rather than a
    plain `.first`. A battery of near-identical questions like 7, 7.1-7.4
    can each leave their OWN "Next" button sitting in the DOM after you've
    moved past them (hidden only via opacity:0/aria-hidden, not
    display:none -- see _is_actually_active()). A plain `.first.click()`
    can silently land on one of those stale, dead buttons instead of the
    current, live one: Playwright's own actionability check doesn't catch
    opacity-hidden elements either, so the click "succeeds" with no
    exception while the page never actually advances -- which then reads,
    downstream, as landing back on the SAME question that was just
    answered (a routing FAIL that looks like a misdetection but is
    actually a click that never reached the real button at all).
    """
    for label in NEXT_BUTTON_TEXTS:
        try:
            btn = _first_visible(page.get_by_role("button", name=re.compile(re.escape(label), re.I)))
            if btn is not None:
                btn.click(timeout=DEFAULT_TIMEOUT_MS)
                return True
        except Exception:
            pass
        try:
            link = _first_visible(page.get_by_role("link", name=re.compile(re.escape(label), re.I)))
            if link is not None:
                link.click(timeout=DEFAULT_TIMEOUT_MS)
                return True
        except Exception:
            pass
        try:
            generic = _first_visible(page.locator(f'text="{label}"'))
            if generic is not None:
                generic.click(timeout=DEFAULT_TIMEOUT_MS)
                return True
        except Exception:
            pass
    # last resort: any <input type=submit> / <button type=submit>
    try:
        sub = _first_visible(page.locator('input[type="submit"], button[type="submit"]'))
        if sub is not None:
            sub.click(timeout=DEFAULT_TIMEOUT_MS)
            return True
    except Exception:
        pass
    return False


def _normalize_ws(s):
    """
    Collapse NBSP (\\xa0), the em-space (\\u2003), and any run of whitespace
    down to a single plain space, and unify dash/quote look-alikes that a
    rich-text editor or copy-paste often swaps for their plain ASCII form
    (e.g. Excel has "6-12 months" but the live page renders "6\u201312
    months" with an en dash, or a curly apostrophe in "recommend most
    often to"). Excel-authored option/question text is often copy-pasted
    from a live page or a Word doc and can carry a non-breaking space *in
    the middle* of a phrase (e.g. "smartphones\\xa0etc.."), which .strip()
    alone doesn't remove (it only trims the ends), or one of these
    punctuation look-alikes anywhere in the phrase. If the live page
    renders that spot slightly differently, a naive substring check
    silently fails even though the text is otherwise identical -- this can
    misclassify which question is on screen and report a false FAIL on a
    routing test that actually landed correctly. Applying this on both
    sides of every comparison (page body and stored text) makes the match
    resilient to it.
    """
    if not s:
        return ""
    s = s.replace("\xa0", " ").replace("\u2003", " ")
    for dash in ("\u2010", "\u2011", "\u2012", "\u2013", "\u2014", "\u2212"):
        s = s.replace(dash, "-")
    for quote in ("\u2018", "\u2019", "\u201a", "\u2032"):
        s = s.replace(quote, "'")
    for quote in ('\u201c', '\u201d', '\u201e', '\u2033'):
        s = s.replace(quote, '"')
    return " ".join(s.split())

def page_text_lower(page):
    """
    Combined lower-cased text used for all page-recognition checks.

    Two blind spots this deliberately covers, both of which look identical
    from the outside (content is genuinely on-screen, page_text_lower still
    comes back without it):

    1. Options rendered as a native <select><option> dropdown. Browsers
       don't include a closed dropdown's option text in inner_text() the
       way they do for visible radio/checkbox labels -- so a many-option
       SINGLE question (e.g. a 12-item region list) rendered as a dropdown
       can genuinely be on-screen and still look "unrecognized". Pulling
       <option> text directly (open or not) fixes that.

    2. Content rendered inside an IFRAME. page.inner_text("body") only
       reads the page's TOP-LEVEL frame -- it never looks inside embedded
       iframes, same-origin or not. Some survey platforms (this shows up
       on certain Confirmit per-brand/grid question widgets) embed a
       question's content in its own iframe. When that happens, the
       question can be 100% correct and fully visible on screen while
       page.inner_text("body") alone still returns text that doesn't
       contain a single word of it -- every recognition check then fails
       even though the routing itself was perfectly correct. Walking
       page.frames and pulling each frame's body text (best-effort, a
       frame that errors is just skipped) closes that gap.
    """
    try:
        body_text = page.inner_text("body")
    except Exception:
        body_text = ""
    try:
        option_texts = page.eval_on_selector_all(
            "select option", "els => els.map(e => e.textContent || '')"
        )
    except Exception:
        option_texts = []
    frame_texts = []
    try:
        for frame in page.frames:
            if frame == page.main_frame:
                continue  # already covered by body_text above
            try:
                frame_texts.append(frame.inner_text("body"))
            except Exception:
                continue  # detached/cross-origin/not-yet-loaded frame -- skip, don't fail the whole check
    except Exception:
        pass
    return _normalize_ws(
        (body_text + "\n" + "\n".join(option_texts) + "\n" + "\n".join(frame_texts))
    ).lower()


# How many leading characters of a question's stored Q_Text are used to
# recognise it on the live page (see question_signature_present(),
# question_text_present_only(), and detect_current_question() below). Must
# be long enough to get PAST any shared preamble that several related
# questions repeat verbatim -- e.g. a battery of near-duplicate questions
# like "Which one brand of toothpaste do you recommend most often to
# patients for <condition>?" that only differs in its last few words. A
# probe of 60 characters cut that survey off INSIDE the shared preamble
# (the differentiating word didn't start until character 74), so every one
# of those questions looked byte-identical to the matcher and it could
# never tell them apart -- whichever the tie-break happened to prefer, was
# reported as the current page regardless of which one the browser was
# actually showing, or what option was actually clicked. 120 comfortably
# clears that case; raise it further only if a future survey repeats an
# even longer shared preamble.
QUESTION_PROBE_LEN = 120


def question_signature_present(page, q):
    """
    Check whether a SPECIFIC question's text + ALL of its options are visible
    on the current page. This is a targeted verification (does the page match
    THIS question) rather than a global guess across every known question --
    which matters a lot when several questions share identical Q_Text
    (e.g. repeated "Please select the language..." blocks per market) or are
    fully duplicated (same text AND same options). In those cases no amount
    of text-matching can uniquely classify the page, but verifying against
    the one question you *expect* to be on works fine.
    """
    body = page_text_lower(page)
    if not body:
        return False
    text = _normalize_ws(q["text"] or "").lower()
    probe = text[:QUESTION_PROBE_LEN]
    if not probe or probe not in body:
        return False
    if q["options"]:
        # Skip "Enter text" keyword-flag rows entirely -- they don't have
        # literal matching text on the live page (see is_specify_option()),
        # so they must not count toward either the numerator or denominator
        # of this check.
        real_options = [opt for opt in q["options"] if not is_specify_row(opt["option_text"])]
        if not real_options:
            return True
        hits = sum(
            1 for opt in real_options
            if opt["option_text"] and _normalize_ws(opt["option_text"]).lower() in body
        )
        return hits == len(real_options)
    return True


def question_text_present_only(page, q):
    """
    Looser cousin of question_signature_present() -- checks ONLY that this
    question's own Q_Text appears on the page, ignoring options entirely.

    Used as a second-chance fallback for image/grid-heavy questions (brand
    logo grids, per-brand statement matrices) where the exact option text
    can be legitimately present-but-unverifiable by a plain substring check
    -- e.g. rendered per-brand in a loop, inside a canvas/SVG widget, or
    simply slow enough to render that a handful of the option rows aren't
    up yet even though the question itself has unmistakably loaded. If the
    Q_Text you expect is on screen, that's normally sufficient evidence
    you're on the right question -- the caller only reaches for this after
    the stricter check has already failed, so it's a deliberate loosening,
    not the default.
    """
    body = page_text_lower(page)
    if not body:
        return False
    text = _normalize_ws(q["text"] or "").lower()
    probe = text[:QUESTION_PROBE_LEN]
    return bool(probe) and probe in body


def detect_current_question(page, questions):
    """
    Look at the page body text and figure out which known question (by
    Q_Text + options) is currently showing. Returns qid or None if no match
    (typically means the survey terminated / showed a thank-you page).

    This is a best-effort GLOBAL guess used only as a fallback for reporting
    (e.g. "what did we actually land on") when we don't have a specific
    expected qid to verify against via question_signature_present(). When
    multiple questions share identical text, ties are broken by preferring
    whichever candidate has the most of ITS OWN options fully present on the
    page, rather than silently defaulting to whichever qid happened to be
    inserted first.
    """
    body = page_text_lower(page)
    if not body:
        return None
    candidates = []
    for qid, q in questions.items():
        text = _normalize_ws(q["text"] or "").lower()
        if not text:
            continue
        probe = text[:QUESTION_PROBE_LEN]
        if probe and probe in body:
            # Same exclusion as question_signature_present(): "Enter text"
            # keyword-flag rows never appear literally on the page.
            real_options = [opt for opt in q["options"] if not is_specify_row(opt["option_text"])]
            total_opts = len(real_options)
            hits = sum(
                1 for opt in real_options
                if opt["option_text"] and _normalize_ws(opt["option_text"]).lower() in body
            )
            full_match = (total_opts > 0 and hits == total_opts)
            candidates.append((qid, full_match, hits))
    if not candidates:
        return None
    # Prefer a full option-set match, then the most option hits, as tiebreakers
    # over simple insertion order.
    candidates.sort(key=lambda c: (c[1], c[2]), reverse=True)
    return candidates[0][0]


def _page_snippet(page, length=220):
    """A short excerpt of what the page actually shows, for the notes field
    on ambiguous results -- so a FAIL log line shows the real page content
    instead of just a guessed qid, and you can tell at a glance whether a
    detection was correct or a false read."""
    try:
        text = page.inner_text("body")
        text = " ".join(text.split())
        return text[:length]
    except Exception:
        return "(could not read page text)"


def _capture_failure_screenshot(page, qid, opt, test_type, screenshots_dir, log):
    """
    Save a full-page screenshot of the CURRENT page state for a failed test
    -- e.g. an option marked TERMINATION in the sheet that instead let the
    survey move on to the next question (or the reverse: a normal-routing
    option that unexpectedly terminated). Filename encodes the question,
    option, and test type so a screenshot can be traced straight back to
    the exact failing row in the report without opening it first.

    Returns the saved path, or None if screenshots aren't enabled for this
    run or the capture itself failed. A screenshot failure is logged but
    never raises -- losing the evidence image should never take down the
    test run itself.
    """
    if not screenshots_dir:
        return None
    try:
        os.makedirs(screenshots_dir, exist_ok=True)
        safe_qid = re.sub(r'[^A-Za-z0-9_-]+', '_', str(qid))
        safe_opt_no = re.sub(r'[^A-Za-z0-9_-]+', '_', str(opt.get("option_no", "")))
        stamp = datetime.datetime.now().strftime("%H%M%S_%f")
        filename = f"{safe_qid}_opt{safe_opt_no}_{test_type}_{stamp}.png"
        path = os.path.join(screenshots_dir, filename)
        page.screenshot(path=path, full_page=True)
        log(f"    screenshot saved: {path}")
        return path
    except Exception as e:
        log(f"    !! could not capture failure screenshot: {e}")
        return None


def looks_terminated(page):
    body = page_text_lower(page)
    # .lower() each keyword too: TERMINATION_KEYWORDS has at least one entry
    # with mixed case (the literal Q4 disqualification text), and `body` is
    # already all-lowercase, so an un-lowered keyword can never match even
    # when the termination page is genuinely showing.
    return any(kw.lower() in body for kw in TERMINATION_KEYWORDS)


@dataclass
class TestResult:
    qid: str
    q_text: str
    option_no: object
    option_text: str
    test_type: str          # "option_routing" | "no_select_validation" | "check_then_uncheck_validation"
                            # | "multi_select_all" | "mandatory_validation" | "complete_mandatory_validation"
                            # | "option_order" (RANDOMIZATION / NON RANDOMIZATION / ALPHABETICAL)
                            # | "option_anchor" (ANCHOR AT THE END)
    expected: str
    actual: str
    passed: bool
    notes: str = ""
    screenshot_path: str = ""   # set only on FAILED tests, when screenshots are enabled for the run


@dataclass
class RunSummary:
    results: list = field(default_factory=list)
    screenshots_dir: str = ""   # folder this run's failure screenshots were saved to (if any)
    skipped_count: int = 0      # options excluded from this run via Option_Choosing != "yes"

    @property
    def total(self):
        return len(self.results)

    @property
    def passed(self):
        return sum(1 for r in self.results if r.passed)

    @property
    def failed(self):
        return self.total - self.passed


def _poll_until_settled(page, check_fn, max_wait_ms=3000, poll_ms=300):
    """
    Re-run check_fn() every poll_ms until it returns truthy, or max_wait_ms
    elapses -- instead of gambling on one fixed-length wait and checking
    exactly once. This exists because PAGE_SETTLE_MS (900ms) is tuned for a
    single window with the whole machine to itself; once several browser
    windows are running in parallel and competing for the same CPU/network,
    that same 900ms sometimes isn't enough for the next question to finish
    rendering, so a single check can catch the page mid-transition and
    wrongly report "unrecognized page". Polling instead of guessing a bigger
    fixed number means it settles correctly whether you're running 1 window
    or 5, without needing to hand-tune anything per worker count. Returns
    whatever check_fn() last returned (its final truthy/falsy result).
    """
    waited = 0
    result = check_fn()
    while not result and waited < max_wait_ms:
        page.wait_for_timeout(poll_ms)
        waited += poll_ms
        result = check_fn()
    return result


def _replay_path(page, questions, path, log, on_manual_help_needed=None):
    """
    Replay a baseline list of (qid, option) answers from a fresh page load.

    MULTI_SELECT awareness: the baseline path itself (built by a plain BFS
    over ROUTING edges in survey_model.build_baseline_paths) only ever
    records ONE representative (qid, option) step per question -- for a
    normal SINGLE/MULTIPLE question that's fine, since selecting that one
    option is all that's needed to proceed. But a MULTI_SELECT question
    (e.g. a brand-attribute matrix where every row needs an answer before
    the survey allows Next) genuinely requires ALL of its real options
    selected, not just the one the BFS happened to pick -- otherwise the
    real survey won't advance past it at all, and replaying the path to
    reach any LATER question fails right here with "could not replay
    path", even though nothing is actually wrong with that later question.
    """
    for qid, opt in path:
        q = questions.get(qid)
        if q is not None and q.get("type") == "MULTI_SELECT":
            real_options = [o for o in q["options"] if not is_specify_option(o["option_text"])]
            log(f"    replay: {qid} -> MULTI_SELECT, selecting all {len(real_options)} option(s)")
            failed = False
            for o in real_options:
                if is_no_option_row(o["option_text"]):
                    continue
                if not select_option(page, o["option_text"], log=log,
                                      on_manual_help_needed=on_manual_help_needed,
                                      q_type=q.get("type"), dropdown=q.get("dropdown", False)):
                    log(f"    !! could not locate option '{o['option_text']}' while replaying "
                        f"MULTI_SELECT path for {qid}")
                    failed = True
                    break
            if failed:
                return False
            page.wait_for_timeout(PAGE_SETTLE_MS)
        elif is_no_option_row(opt["option_text"]):
            log(f"    replay: {qid} -> no clickable option on this screen "
                f"('no option' keyword) -- clicking Next directly")
        else:
            log(f"    replay: {qid} -> selecting option {opt['option_no']} ({opt['option_text']!r})")
            if not select_option(page, opt["option_text"], log=log,
                                  on_manual_help_needed=on_manual_help_needed,
                                  q_type=(q.get("type") if q is not None else None),
                                  dropdown=(q.get("dropdown", False) if q is not None else False)):
                log(f"    !! could not locate option '{opt['option_text']}' while replaying path for {qid}")
                return False
            page.wait_for_timeout(PAGE_SETTLE_MS)
        if not click_next(page):
            log(f"    !! could not find Next/Continue button while replaying path for {qid}")
            return False
        page.wait_for_timeout(PAGE_SETTLE_MS)
    return True


# ----------------------------------------------------------------------
# Individual test bodies.
#
# Each of these takes a `browser` object (already launched) and opens its
# OWN fresh context/page, runs one self-contained test, and returns a
# TestResult (or None, for the check-then-uncheck test on a non-checkbox,
# which is a silent skip). Because every test opens its own context and
# replays the full path from a fresh page load, these have NO shared state
# with each other -- which is exactly what makes them safe to fan out
# across multiple threads/browsers. Each function is a straight extraction
# of what run_tests() used to do inline, just parameterised.
# ----------------------------------------------------------------------

def _test_option_routing(browser, survey_url, questions, qid, q, path, opt, log, screenshots_dir=None,
                          on_manual_help_needed=None):
    context = browser.new_context(no_viewport=True)
    page = context.new_page()
    page.set_default_timeout(DEFAULT_TIMEOUT_MS)
    test_label = f"[{qid}] option {opt['option_no']} ({opt['option_text']!r})"
    try:
        log(f"\n=== Testing {test_label} ===")
        if not goto_with_retry(page, survey_url, log):
            log("    RESULT: FAIL (could not load survey page)")
            return TestResult(
                qid, q["text"], opt["option_no"], opt["option_text"],
                "option_routing", "load survey page", "navigation timeout",
                False, "page.goto() timed out on every retry attempt.",
                _capture_failure_screenshot(page, qid, opt, "option_routing", screenshots_dir, log) or ""
            )
        page.wait_for_timeout(PAGE_SETTLE_MS)

        if not _replay_path(page, questions, path, log, on_manual_help_needed=on_manual_help_needed):
            log(f"    RESULT: FAIL (could not even reach {qid})")
            return TestResult(
                qid, q["text"], opt["option_no"], opt["option_text"],
                "option_routing", "reach question", "could not replay path",
                False, "Failed while navigating baseline path to this question.",
                _capture_failure_screenshot(page, qid, opt, "option_routing", screenshots_dir, log) or ""
            )

        ok = is_no_option_row(opt["option_text"])
        if ok:
            log("    (no clickable option on this screen -- 'no option' keyword; clicking Next directly)")
        else:
            ok = select_option(page, opt["option_text"], log=log,
                                on_manual_help_needed=on_manual_help_needed,
                                q_type=q.get("type"), dropdown=q.get("dropdown", False))
        if not ok:
            log("    RESULT: FAIL (option element not found)")
            return TestResult(
                qid, q["text"], opt["option_no"], opt["option_text"],
                "option_routing", "select option", "option not found on page",
                False, "select_option() could not locate this option's element.",
                _capture_failure_screenshot(page, qid, opt, "option_routing", screenshots_dir, log) or ""
            )

        page.wait_for_timeout(PAGE_SETTLE_MS)
        # click_next()'s return value was silently discarded here -- if
        # Next couldn't be found/clicked (e.g. a fresh AI-driven checkbox
        # click momentarily shifts the DOM, or the button is briefly
        # disabled right after checking a box), the page never actually
        # advances and every downstream check correctly-but-confusingly
        # reports "unrecognized page" -- because we're still sitting on
        # the SAME page, not because routing detection failed. Give it one
        # retry after a short extra wait (covers a transient disabled-Next
        # state), then log clearly so this failure mode is unmistakable in
        # the Live Log instead of masquerading as a routing/detection bug.
        next_clicked = click_next(page)
        if not next_clicked:
            page.wait_for_timeout(PAGE_SETTLE_MS)
            next_clicked = click_next(page)
        if not next_clicked:
            log("    !! Next/Continue button not found or not clickable after selecting "
                f"{opt['option_text']!r} -- page never advanced (this is why the next "
                "check will show 'unrecognized page': we're still on the SAME page).")
        page.wait_for_timeout(PAGE_SETTLE_MS)

        terminated = looks_terminated(page)
        loose_match = False

        if opt["termination"]:
            expected = "TERMINATE"
            if not terminated:
                # Give a slow-rendering termination page a further chance
                # before concluding it didn't terminate -- important under
                # parallel load where PAGE_SETTLE_MS alone may not be enough.
                terminated = _poll_until_settled(page, lambda: looks_terminated(page),
                                                  max_wait_ms=ROUTING_SETTLE_MAX_WAIT_MS)
            if terminated:
                actual, passed = "TERMINATE", True
            else:
                detected_qid = detect_current_question(page, questions)
                actual = "continued unexpectedly" if detected_qid is None else f"continued to {detected_qid}"
                passed = False
        else:
            expected_next = opt["routing"]
            expected = f"-> {expected_next}" if expected_next else "(no routing specified)"
            reached_expected = (
                expected_next in questions and
                question_signature_present(page, questions[expected_next])
            ) if expected_next else False
            if not terminated and not reached_expected and expected_next and expected_next in questions:
                # Same reasoning as above: a genuinely-correct route can still
                # look "unrecognized" for a moment if the next question is
                # still rendering. Poll before treating it as a real failure.
                reached_expected = _poll_until_settled(
                    page, lambda: question_signature_present(page, questions[expected_next]),
                    max_wait_ms=ROUTING_SETTLE_MAX_WAIT_MS
                )
                if not reached_expected:
                    # Strict check (Q_Text + EVERY option's text) still
                    # failed even after extended polling. For image/grid
                    # questions (brand-logo grids, per-brand statement
                    # matrices) that's often too fragile a bar -- the
                    # question itself can be unmistakably on-screen while
                    # an option's text is legitimately unverifiable by a
                    # substring check (per-brand loop rendering, a widget
                    # that doesn't expose its label as plain text, etc.).
                    # Falling back to "is the QUESTION's own text present"
                    # is a deliberately looser, second-chance check -- only
                    # reached after the strict one has already had its
                    # full chance to pass.
                    reached_expected = _poll_until_settled(
                        page, lambda: question_text_present_only(page, questions[expected_next]),
                        max_wait_ms=ROUTING_SETTLE_MAX_WAIT_MS
                    )
                    loose_match = reached_expected
                if reached_expected:
                    terminated = False  # re-check in case termination text appeared while polling
                else:
                    terminated = looks_terminated(page)
            if terminated:
                actual = "TERMINATED (unexpected)"
                passed = False
            elif reached_expected:
                actual = f"-> {expected_next}"
                passed = True
            else:
                detected_qid = detect_current_question(page, questions)
                if detected_qid is not None and detected_qid == expected_next:
                    # The strict "every option text present" signature check
                    # failed (e.g. one option's text differs slightly from
                    # what's on the live page -- extra spacing, a dynamic
                    # "(specify)" suffix, etc.) but the loose best-guess
                    # detector still confidently landed on exactly the
                    # question we expected. Don't fail on that technicality.
                    actual = f"-> {detected_qid}"
                    passed = True
                elif detected_qid is None:
                    actual = "unrecognized page (could not match any known question)"
                    passed = False
                else:
                    actual = f"-> {detected_qid}"
                    passed = False

        log(f"    Expected: {expected} | Actual: {actual} | RESULT: {'PASS' if passed else 'FAIL'}")
        notes = "" if passed else f"page showed: {_page_snippet(page)!r}"
        if not passed and not next_clicked:
            notes = ("Next/Continue button was not found or not clickable after selecting "
                     "this option -- the page never advanced, so this is NOT a routing/"
                     "recognition failure, it's a stuck-on-same-page failure. " + notes)
        if passed and loose_match:
            notes = ("Matched by question text only -- not every option's text was "
                     "independently verified on the page (common on image/grid brand "
                     "questions). Routing itself is confirmed correct.")
        screenshot_path = "" if passed else (
            _capture_failure_screenshot(page, qid, opt, "option_routing", screenshots_dir, log) or ""
        )
        return TestResult(
            qid, q["text"], opt["option_no"], opt["option_text"],
            "option_routing", expected, actual, passed, notes, screenshot_path
        )
    except OptionOrderError as e:
        log(f"    RESULT: FAIL ({e})")
        screenshot_path = _capture_failure_screenshot(page, qid, opt, "option_routing", screenshots_dir, log) or ""
        return TestResult(
            qid, q["text"], opt["option_no"], opt["option_text"],
            "option_routing", "option is the LAST one on the page", str(e),
            False, "Option order check failed -- see the failure screenshot for the actual order.",
            screenshot_path
        )
    except Exception as e:
        log(f"    RESULT: FAIL (exception: {e})")
        screenshot_path = _capture_failure_screenshot(page, qid, opt, "option_routing", screenshots_dir, log) or ""
        return TestResult(
            qid, q["text"], opt["option_no"], opt["option_text"],
            "option_routing", "no exception", f"exception: {e}",
            False, traceback.format_exc(limit=3), screenshot_path
        )
    finally:
        context.close()
        time.sleep(INTER_TEST_DELAY_MS / 1000)


def _test_multi_select_all(browser, survey_url, questions, qid, q, path, opt, log, screenshots_dir=None,
                            on_manual_help_needed=None):
    """
    For questions marked Q_Type == "MULTI_SELECT" -- e.g. brand-attribute
    association grids/matrices where the real, intended way to answer is
    "tick EVERY row's Yes column", not just one at a time -- this selects
    ALL of the question's real options in a single page visit and a single
    click of Next, instead of _test_option_routing's one-option-per-test
    approach (which is right for genuine "pick exactly one of these"
    questions, but wrong here since testing options individually never
    reflects how the question is actually meant to be answered).

    `opt` here is a synthetic placeholder built by _build_jobs() (Option_No
    "ALL") purely for report/log labelling -- the real option list being
    selected is q["options"], not this single opt.

    Expected routing: since every real option normally shares the same
    routing target on a matrix like this, the first non-empty ROUTING
    found among the question's options is used as the expected next
    question (same TERMINATION handling as _test_option_routing if any
    option is flagged to terminate instead).
    """
    real_options = [o for o in q["options"] if not is_specify_option(o["option_text"])]
    expected_next = None
    any_termination = False
    for o in real_options:
        if o["termination"]:
            any_termination = True
        elif o["routing"] and not expected_next:
            expected_next = o["routing"]

    context = browser.new_context(no_viewport=True)
    page = context.new_page()
    page.set_default_timeout(DEFAULT_TIMEOUT_MS)
    test_label = f"[{qid}] MULTI_SELECT -- all {len(real_options)} option(s) at once"
    try:
        log(f"\n=== Testing {test_label} ===")
        if not goto_with_retry(page, survey_url, log):
            log("    RESULT: FAIL (could not load survey page)")
            return TestResult(
                qid, q["text"], opt["option_no"], opt["option_text"],
                "multi_select_all", "load survey page", "navigation timeout",
                False, "page.goto() timed out on every retry attempt.",
                _capture_failure_screenshot(page, qid, opt, "multi_select_all", screenshots_dir, log) or ""
            )
        page.wait_for_timeout(PAGE_SETTLE_MS)

        if not _replay_path(page, questions, path, log, on_manual_help_needed=on_manual_help_needed):
            log(f"    RESULT: FAIL (could not even reach {qid})")
            return TestResult(
                qid, q["text"], opt["option_no"], opt["option_text"],
                "multi_select_all", "reach question", "could not replay path",
                False, "Failed while navigating baseline path to this question.",
                _capture_failure_screenshot(page, qid, opt, "multi_select_all", screenshots_dir, log) or ""
            )

        log(f"    Selecting all {len(real_options)} option(s) for this MULTI_SELECT question...")
        failures = []
        for o in real_options:
            if is_no_option_row(o["option_text"]):
                continue
            if not select_option(page, o["option_text"], log=log,
                                  on_manual_help_needed=on_manual_help_needed,
                                  q_type=q.get("type"), dropdown=q.get("dropdown", False)):
                failures.append(o["option_text"])
        if failures:
            log(f"    RESULT: FAIL ({len(failures)}/{len(real_options)} option(s) not found on page)")
            return TestResult(
                qid, q["text"], opt["option_no"], opt["option_text"],
                "multi_select_all", "select all options",
                f"{len(failures)} option(s) not found: {failures}",
                False, "select_option() could not locate: " + ", ".join(failures),
                _capture_failure_screenshot(page, qid, opt, "multi_select_all", screenshots_dir, log) or ""
            )

        page.wait_for_timeout(PAGE_SETTLE_MS)
        next_clicked = click_next(page)
        if not next_clicked:
            page.wait_for_timeout(PAGE_SETTLE_MS)
            next_clicked = click_next(page)
        if not next_clicked:
            log("    !! Next/Continue button not found or not clickable after selecting "
                "ALL options -- page never advanced.")
        page.wait_for_timeout(PAGE_SETTLE_MS)

        terminated = looks_terminated(page)
        loose_match = False

        if any_termination and not expected_next:
            expected = "TERMINATE"
            if not terminated:
                terminated = _poll_until_settled(page, lambda: looks_terminated(page),
                                                  max_wait_ms=ROUTING_SETTLE_MAX_WAIT_MS)
            if terminated:
                actual, passed = "TERMINATE", True
            else:
                detected_qid = detect_current_question(page, questions)
                actual = "continued unexpectedly" if detected_qid is None else f"continued to {detected_qid}"
                passed = False
        else:
            expected = f"-> {expected_next}" if expected_next else "(no routing specified)"
            reached_expected = (
                expected_next in questions and
                question_signature_present(page, questions[expected_next])
            ) if expected_next else False
            if not terminated and not reached_expected and expected_next and expected_next in questions:
                reached_expected = _poll_until_settled(
                    page, lambda: question_signature_present(page, questions[expected_next]),
                    max_wait_ms=ROUTING_SETTLE_MAX_WAIT_MS
                )
                if not reached_expected:
                    reached_expected = _poll_until_settled(
                        page, lambda: question_text_present_only(page, questions[expected_next]),
                        max_wait_ms=ROUTING_SETTLE_MAX_WAIT_MS
                    )
                    loose_match = reached_expected
                if reached_expected:
                    terminated = False
                else:
                    terminated = looks_terminated(page)
            if terminated:
                actual = "TERMINATED (unexpected)"
                passed = False
            elif reached_expected:
                actual = f"-> {expected_next}"
                passed = True
            else:
                detected_qid = detect_current_question(page, questions)
                if detected_qid is not None and detected_qid == expected_next:
                    actual = f"-> {detected_qid}"
                    passed = True
                elif detected_qid is None:
                    actual = "unrecognized page (could not match any known question)"
                    passed = False
                else:
                    actual = f"-> {detected_qid}"
                    passed = False

        log(f"    Expected: {expected} | Actual: {actual} | RESULT: {'PASS' if passed else 'FAIL'}")
        notes = "" if passed else f"page showed: {_page_snippet(page)!r}"
        if not passed and not next_clicked:
            notes = ("Next/Continue button was not found or not clickable after selecting "
                     "all options -- the page never advanced. " + notes)
        if passed and loose_match:
            notes = ("Matched by question text only -- not every option's text was "
                     "independently verified on the page. Routing itself is confirmed correct.")
        screenshot_path = "" if passed else (
            _capture_failure_screenshot(page, qid, opt, "multi_select_all", screenshots_dir, log) or ""
        )
        return TestResult(
            qid, q["text"], opt["option_no"], opt["option_text"],
            "multi_select_all", expected, actual, passed, notes, screenshot_path
        )
    except Exception as e:
        log(f"    RESULT: FAIL (exception: {e})")
        screenshot_path = _capture_failure_screenshot(page, qid, opt, "multi_select_all", screenshots_dir, log) or ""
        return TestResult(
            qid, q["text"], opt["option_no"], opt["option_text"],
            "multi_select_all", "no exception", f"exception: {e}",
            False, traceback.format_exc(limit=3), screenshot_path
        )
    finally:
        context.close()
        time.sleep(INTER_TEST_DELAY_MS / 1000)


def _test_no_select_validation(browser, survey_url, questions, qid, q, path, opt, log, screenshots_dir=None,
                                on_manual_help_needed=None):
    context = browser.new_context(no_viewport=True)
    page = context.new_page()
    page.set_default_timeout(DEFAULT_TIMEOUT_MS)
    test_label = f"[{qid}] single-option no-select validation"
    try:
        log(f"\n=== Testing {test_label} ===")
        if not goto_with_retry(page, survey_url, log):
            log("    RESULT: FAIL (could not load survey page)")
            return TestResult(
                qid, q["text"], opt["option_no"], "(none selected)",
                "no_select_validation", "load survey page", "navigation timeout",
                False, "page.goto() timed out on every retry attempt.",
                _capture_failure_screenshot(page, qid, opt, "no_select_validation", screenshots_dir, log) or ""
            )
        page.wait_for_timeout(PAGE_SETTLE_MS)

        if not _replay_path(page, questions, path, log, on_manual_help_needed=on_manual_help_needed):
            log(f"    RESULT: FAIL (could not even reach {qid})")
            return TestResult(
                qid, q["text"], opt["option_no"], "(none selected)",
                "no_select_validation", "reach question", "could not replay path",
                False, "Failed while navigating baseline path to this question.",
                _capture_failure_screenshot(page, qid, opt, "no_select_validation", screenshots_dir, log) or ""
            )

        on_target = question_signature_present(page, q)

        input_type = detect_option_input_type(page, opt["option_text"])
        if input_type not in ("checkbox", "radio"):
            # No distinct toggle to leave unselected -- this option's own
            # control (e.g. a single "I Agree" button on a welcome/consent
            # screen) IS the continue action itself, so "click Next without
            # selecting" isn't a meaningful test here. click_next()'s
            # last-resort fallback clicks any submit-type button on the
            # page regardless of label, which would otherwise click this
            # very option and produce a false "unexpectedly continued"
            # failure. Skip silently, same as check_then_uncheck already
            # does for non-checkbox single options.
            log(f"    (skipping no-select validation: option '{opt['option_text']}' "
                f"is a {input_type or 'non-checkbox/radio'} element -- likely the page's "
                f"own continue action, not a separate toggle)")
            return None

        # Read the control's DEFAULT state before touching anything. Some
        # consent checkboxes are pre-checked, with copy like "Please
        # uncheck the option if you do not agree" -- for those, "leave it
        # alone and click Next" is not a distinct scenario from
        # option_routing's "select it, click Next" (both start and end up
        # checked, both expect the same routing outcome), so running it as
        # a separate reported test is pure duplicate noise. Only applies to
        # checkboxes; radios have no meaningful "default checked" concept
        # here.
        default_checked = None
        if input_type == "checkbox":
            box = find_checkbox_locator(page, opt["option_text"])
            if box is not None:
                try:
                    default_checked = box.is_checked()
                except Exception:
                    default_checked = None

        if default_checked:
            log(f"    (skipping no-select validation: '{opt['option_text']}' is checked by "
                f"default -- leaving it alone is identical to option_routing's 'select it' "
                f"case, so this would just duplicate that test)")
            return None

        click_next(page)  # deliberately skip select_option()
        page.wait_for_timeout(PAGE_SETTLE_MS)

        terminated = looks_terminated(page)
        still_on_target = (not terminated) and question_signature_present(page, q)
        detected_qid = None if (terminated or still_on_target) else detect_current_question(page, questions)

        expected = "blocked / stays on same question (does not silently continue)"
        if terminated:
            actual = "terminated"
            passed = True
        elif still_on_target or not on_target:
            actual = "stayed on same question (blocked as expected)"
            passed = True
        elif detected_qid is None:
            actual = "blocked (page changed but did not match any known question -- likely a validation message)"
            passed = True
        else:
            actual = f"unexpectedly continued to {detected_qid} without a selection"
            passed = False

        log(f"    Expected: {expected} | Actual: {actual} | RESULT: {'PASS' if passed else 'FAIL'}")
        notes = "" if passed else f"page showed: {_page_snippet(page)!r}"
        screenshot_path = "" if passed else (
            _capture_failure_screenshot(page, qid, opt, "no_select_validation", screenshots_dir, log) or ""
        )
        return TestResult(
            qid, q["text"], opt["option_no"], "(none selected)",
            "no_select_validation", expected, actual, passed, notes, screenshot_path
        )
    except Exception as e:
        log(f"    RESULT: FAIL (exception: {e})")
        screenshot_path = _capture_failure_screenshot(page, qid, opt, "no_select_validation", screenshots_dir, log) or ""
        return TestResult(
            qid, q["text"], opt["option_no"], "(none selected)",
            "no_select_validation", "no exception", f"exception: {e}",
            False, traceback.format_exc(limit=3), screenshot_path
        )
    finally:
        context.close()
        time.sleep(INTER_TEST_DELAY_MS / 1000)


def _test_check_then_uncheck(browser, survey_url, questions, qid, q, path, opt, log, screenshots_dir=None,
                              on_manual_help_needed=None):
    context = browser.new_context(no_viewport=True)
    page = context.new_page()
    page.set_default_timeout(DEFAULT_TIMEOUT_MS)
    test_label = f"[{qid}] single-option check-then-uncheck validation"
    try:
        log(f"\n=== Testing {test_label} ===")
        if not goto_with_retry(page, survey_url, log):
            log("    RESULT: FAIL (could not load survey page)")
            return TestResult(
                qid, q["text"], opt["option_no"], "(checked then unchecked)",
                "check_then_uncheck_validation", "load survey page", "navigation timeout",
                False, "page.goto() timed out on every retry attempt.",
                _capture_failure_screenshot(page, qid, opt, "check_then_uncheck_validation", screenshots_dir, log) or ""
            )
        page.wait_for_timeout(PAGE_SETTLE_MS)

        if not _replay_path(page, questions, path, log, on_manual_help_needed=on_manual_help_needed):
            log(f"    RESULT: FAIL (could not even reach {qid})")
            return TestResult(
                qid, q["text"], opt["option_no"], "(checked then unchecked)",
                "check_then_uncheck_validation", "reach question", "could not replay path",
                False, "Failed while navigating baseline path to this question.",
                _capture_failure_screenshot(page, qid, opt, "check_then_uncheck_validation", screenshots_dir, log) or ""
            )

        on_target = question_signature_present(page, q)

        input_type = detect_option_input_type(page, opt["option_text"])
        if input_type != "checkbox":
            # Radios can't be meaningfully "unchecked" -- nothing to test, no
            # pass/fail, same as the original sequential behaviour.
            log(f"    (skipping check-then-uncheck: option '{opt['option_text']}' "
                f"is a {input_type or 'non-checkbox'} element, not a checkbox)")
            return None

        checked_ok = set_checkbox_state(page, opt["option_text"], True, log=log)
        page.wait_for_timeout(PAGE_SETTLE_MS)
        unchecked_ok = set_checkbox_state(page, opt["option_text"], False, log=log)
        page.wait_for_timeout(PAGE_SETTLE_MS)

        if not (checked_ok and unchecked_ok):
            log("    RESULT: FAIL (could not verify checkbox toggle)")
            return TestResult(
                qid, q["text"], opt["option_no"], "(checked then unchecked)",
                "check_then_uncheck_validation", "toggle option on then off",
                "could not verify the checkbox actually toggled to unchecked",
                False, "set_checkbox_state() could not confirm the checked state changed as expected.",
                _capture_failure_screenshot(page, qid, opt, "check_then_uncheck_validation", screenshots_dir, log) or ""
            )

        click_next(page)
        page.wait_for_timeout(PAGE_SETTLE_MS)

        terminated = looks_terminated(page)
        still_on_target = (not terminated) and question_signature_present(page, q)
        detected_qid = None if (terminated or still_on_target) else detect_current_question(page, questions)

        expected = "blocked / terminated (unchecked = does not agree, should not proceed)"
        if terminated:
            actual = "terminated"
            passed = True
        elif still_on_target or not on_target:
            actual = "stayed on same question (blocked as expected)"
            passed = True
        elif detected_qid is None:
            actual = "blocked (page changed but did not match any known question -- likely a validation message)"
            passed = True
        else:
            actual = f"unexpectedly continued to {detected_qid} after unchecking"
            passed = False

        log(f"    Expected: {expected} | Actual: {actual} | RESULT: {'PASS' if passed else 'FAIL'}")
        notes = "" if passed else f"page showed: {_page_snippet(page)!r}"
        screenshot_path = "" if passed else (
            _capture_failure_screenshot(page, qid, opt, "check_then_uncheck_validation", screenshots_dir, log) or ""
        )
        return TestResult(
            qid, q["text"], opt["option_no"], "(checked then unchecked)",
            "check_then_uncheck_validation", expected, actual, passed, notes, screenshot_path
        )
    except Exception as e:
        log(f"    RESULT: FAIL (exception: {e})")
        screenshot_path = _capture_failure_screenshot(
            page, qid, opt, "check_then_uncheck_validation", screenshots_dir, log
        ) or ""
        return TestResult(
            qid, q["text"], opt["option_no"], "(checked then unchecked)",
            "check_then_uncheck_validation", "no exception", f"exception: {e}",
            False, traceback.format_exc(limit=3), screenshot_path
        )
    finally:
        context.close()
        time.sleep(INTER_TEST_DELAY_MS / 1000)


# ----------------------------------------------------------------------
# MANDATORY checks (driven by the sheet's Logic column)
#
#   Logic = "MANDATORY"           -> THIS OPTION is mandatory
#   Logic = "COMPLETE MANDATORY"  -> the WHOLE QUESTION is mandatory
#
# Both run the same two-step scenario on one page visit:
#   Step 1: leave the required input blank and click Next. The survey must
#           BLOCK (stay on the question and show its validation error). If it
#           moves on / terminates instead, the mandatory rule is not enforced
#           -> FAIL with that error.
#   Step 2: only if step 1 was blocked -- now select / enter the text and click
#           Next again. It must reach the correct page (the option's ROUTING,
#           or the termination page) -> PASS.
#
# "Blank" depends on the option:
#   * plain option              -> left unselected
#   * bare "enter text"         -> text box left empty
#   * "Others(enter text)"      -> Others is selected, its text box left empty
#   * COMPLETE MANDATORY        -> nothing selected or entered on the whole question
# ----------------------------------------------------------------------

def _leave_input_blank(page, opt, log):
    """
    Step 1 set-up: put the page in the "user gave no answer" state for what is
    being tested (see the block comment above). opt=None means the whole
    question -- touch nothing. Returns (ok, description); ok is False only
    when a "<label>(enter text)" option couldn't be found. May raise
    OptionOrderError (Others not last).
    """
    if opt is None:
        return True, "nothing selected or entered (whole question left blank)"
    label = parse_labeled_specify(opt["option_text"])
    if label is not None:
        ok = select_labeled_specify_option(page, label, fill_text=None, log=log)
        return ok, f"'{label}' selected but its text box left empty"
    if is_specify_option(opt["option_text"]):
        return True, "text box left empty"
    return True, f"option {opt['option_text']!r} left unselected"


def _recovery_plan(q, opt=None):
    """
    Step 2 plan: what to select/enter so the page SHOULD now proceed, and where
    it should go. Returns dict(options, expected_next, expect_terminate) or None
    if there's nothing usable to verify with.

      * MULTI_SELECT questions need every real option ticked to advance.
      * opt given (option-level MANDATORY): use that option.
      * opt None (COMPLETE MANDATORY): the first option enabled for testing --
        preferring one that routes onward over one that terminates.
    """
    if q.get("type") == "MULTI_SELECT":
        real = [o for o in q["options"]
                if not is_specify_option(o["option_text"]) and not is_no_option_row(o["option_text"])]
        if not real:
            return None
        expected_next = next((o["routing"] for o in real if not o["termination"] and o["routing"]), None)
        any_term = any(o["termination"] for o in real)
        return {"options": real, "expected_next": expected_next,
                "expect_terminate": bool(any_term and not expected_next)}
    if opt is None:
        usable = [o for o in q["options"] if o.get("choose", True) and not is_no_option_row(o["option_text"])]
        pick = (next((o for o in usable if not o["termination"] and o["routing"]), None)
                or next((o for o in usable if o["termination"]), None))
        if pick is None:
            return None
    else:
        pick = opt
    return {"options": [pick],
            "expected_next": None if pick["termination"] else pick["routing"],
            "expect_terminate": bool(pick["termination"])}


def _apply_plan(page, plan, q, log, on_manual_help_needed=None):
    """Select / enter everything in the plan. Returns the text of the first
    option that couldn't be found, or None if all were done."""
    for o in plan["options"]:
        if is_no_option_row(o["option_text"]):
            continue
        if not select_option(page, o["option_text"], log=log,
                             on_manual_help_needed=on_manual_help_needed,
                             q_type=q.get("type"), dropdown=q.get("dropdown", False)):
            return o["option_text"]
    return None


def _evaluate_outcome(page, questions, expected_next, expect_terminate):
    """
    After Next was clicked: did the survey land where it should? Same
    rules as option_routing (strict signature -> polled -> question-text-only
    fallback). Returns (expected, actual, passed, loose_match).
    """
    terminated = looks_terminated(page)
    if expect_terminate:
        if not terminated:
            terminated = _poll_until_settled(page, lambda: looks_terminated(page),
                                              max_wait_ms=ROUTING_SETTLE_MAX_WAIT_MS)
        if terminated:
            return "TERMINATE", "TERMINATE", True, False
        d = detect_current_question(page, questions)
        return "TERMINATE", ("continued unexpectedly" if d is None else f"continued to {d}"), False, False

    expected = f"-> {expected_next}"
    target_q = questions[expected_next]
    reached = (not terminated) and question_signature_present(page, target_q)
    loose = False
    if not terminated and not reached:
        reached = _poll_until_settled(page, lambda: question_signature_present(page, target_q),
                                       max_wait_ms=ROUTING_SETTLE_MAX_WAIT_MS)
        if not reached:
            reached = _poll_until_settled(page, lambda: question_text_present_only(page, target_q),
                                           max_wait_ms=ROUTING_SETTLE_MAX_WAIT_MS)
            loose = reached
    if reached:
        return expected, f"-> {expected_next}", True, loose
    if looks_terminated(page):
        return expected, "TERMINATED (unexpected)", False, False
    d = detect_current_question(page, questions)
    if d is not None and d == expected_next:
        return expected, f"-> {d}", True, False
    if d is None:
        return expected, "unrecognized page (could not match any known question)", False, False
    return expected, f"-> {d}", False, False


def _run_mandatory_test(browser, survey_url, questions, qid, q, path, opt, log, screenshots_dir,
                        on_manual_help_needed, whole_question):
    test_type = "complete_mandatory_validation" if whole_question else "mandatory_validation"
    shown_text = ("(whole question left blank)" if whole_question
                  else f"{opt['option_text']} (left blank)")
    scope = "COMPLETE MANDATORY (whole question)" if whole_question else f"MANDATORY option {opt['option_text']!r}"

    context = browser.new_context(no_viewport=True)
    page = context.new_page()
    page.set_default_timeout(DEFAULT_TIMEOUT_MS)

    def result(expected, actual, passed, notes=""):
        shot = "" if passed else (_capture_failure_screenshot(page, qid, opt, test_type, screenshots_dir, log) or "")
        return TestResult(qid, q["text"], opt["option_no"], shown_text, test_type,
                          expected, actual, passed, notes, shot)

    try:
        log(f"\n=== Testing [{qid}] {scope} ===")
        if not goto_with_retry(page, survey_url, log):
            log("    RESULT: FAIL (could not load survey page)")
            return result("load survey page", "navigation timeout", False,
                          "page.goto() timed out on every retry attempt.")
        page.wait_for_timeout(PAGE_SETTLE_MS)

        if not _replay_path(page, questions, path, log, on_manual_help_needed=on_manual_help_needed):
            log(f"    RESULT: FAIL (could not even reach {qid})")
            return result("reach question", "could not replay path", False,
                          "Failed while navigating baseline path to this question.")

        # ---- Step 1: leave the required input blank, click Next -> must be BLOCKED
        blank_ok, blank_desc = _leave_input_blank(page, None if whole_question else opt, log)
        if not blank_ok:
            log("    RESULT: FAIL (option element not found)")
            return result("select option", "option not found on page", False,
                          "select_labeled_specify_option() could not locate this option's element.")
        log(f"    Step 1: {blank_desc}; clicking Next -- the survey must BLOCK this...")
        page.wait_for_timeout(PAGE_SETTLE_MS)
        next_clicked = click_next(page)
        if not next_clicked:
            page.wait_for_timeout(PAGE_SETTLE_MS)
            next_clicked = click_next(page)
        if not next_clicked:
            log("    RESULT: FAIL (Next button not found -- cannot verify)")
            return result("blocked with a validation error", "Next/Continue button not found", False,
                          "Could not click Next, so the mandatory check could not be performed.")
        page.wait_for_timeout(PAGE_SETTLE_MS * 2)  # long enough for a wrong 'advance' to actually render

        terminated = looks_terminated(page)
        on_target = (not terminated) and question_text_present_only(page, q)
        expected_block = "blocked -- stays on this question with a validation error"
        if not on_target:
            if terminated:
                where = "TERMINATED"
            else:
                d = detect_current_question(page, questions)
                where = f"moved on to {d}" if d else "moved on to an unrecognized page"
            actual = f"{where} without input"
            log(f"    Expected: {expected_block} | Actual: {actual} | RESULT: FAIL")
            return result(expected_block, actual, False,
                          f"ERROR: {scope} is not enforced -- the survey let the respondent continue "
                          f"with {blank_desc}. page showed: {_page_snippet(page)!r}")
        log("    Step 1 OK: survey blocked the blank answer (stayed on the question).")

        # ---- Step 2: now answer properly and click Next -> must reach the CORRECT page
        plan = _recovery_plan(q, None if whole_question else opt)
        if plan is None or not (plan["expected_next"] or plan["expect_terminate"]):
            log("    RESULT: PASS (blocked as expected; no routing in the sheet to verify step 2 against)")
            return result(expected_block, "blocked as expected", True,
                          "Step 2 (answer correctly -> correct page) skipped: no routing/termination "
                          "is defined in the sheet for the option that would be used.")
        failed_opt = _apply_plan(page, plan, q, log, on_manual_help_needed)
        if failed_opt is not None:
            log(f"    RESULT: FAIL (could not select/enter {failed_opt!r} on step 2)")
            return result("answer correctly after the error", f"option {failed_opt!r} not found on page", False,
                          "Step 1 blocked correctly, but the retry could not select/enter the answer.")
        page.wait_for_timeout(PAGE_SETTLE_MS)
        next_clicked = click_next(page)
        if not next_clicked:
            page.wait_for_timeout(PAGE_SETTLE_MS)
            next_clicked = click_next(page)
        page.wait_for_timeout(PAGE_SETTLE_MS)
        exp2, act2, passed2, loose = _evaluate_outcome(page, questions, plan["expected_next"],
                                                        plan["expect_terminate"])
        expected = f"blocked when left blank, then {exp2} once answered"
        if passed2:
            actual = f"blocked when left blank; then {act2}"
            log(f"    Expected: {expected} | Actual: {actual} | RESULT: PASS")
            notes = ("Step 2 matched by question text only -- not every option's text was independently "
                     "verified." if loose else "")
            return result(expected, actual, True, notes)
        actual = f"blocked when left blank; but after answering: {act2}"
        log(f"    Expected: {expected} | Actual: {actual} | RESULT: FAIL")
        notes = f"page showed: {_page_snippet(page)!r}"
        if not next_clicked:
            notes = "Next/Continue button was not found on step 2 -- page never advanced. " + notes
        return result(expected, actual, False, notes)
    except OptionOrderError as e:
        log(f"    RESULT: FAIL ({e})")
        return result("option is the LAST one on the page", str(e), False,
                      "Option order check failed -- see the failure screenshot for the actual order.")
    except Exception as e:
        log(f"    RESULT: FAIL (exception: {e})")
        return result("no exception", f"exception: {e}", False, traceback.format_exc(limit=3))
    finally:
        context.close()
        time.sleep(INTER_TEST_DELAY_MS / 1000)


def _test_option_mandatory(browser, survey_url, questions, qid, q, path, opt, log, screenshots_dir=None,
                            on_manual_help_needed=None):
    """Logic = MANDATORY on one option row -- see the MANDATORY block comment above."""
    return _run_mandatory_test(browser, survey_url, questions, qid, q, path, opt, log, screenshots_dir,
                               on_manual_help_needed, whole_question=False)


def _test_complete_mandatory(browser, survey_url, questions, qid, q, path, opt, log, screenshots_dir=None,
                              on_manual_help_needed=None):
    """Logic = COMPLETE MANDATORY on a question -- `opt` is a placeholder used only for labelling."""
    return _run_mandatory_test(browser, survey_url, questions, qid, q, path, opt, log, screenshots_dir,
                               on_manual_help_needed, whole_question=True)


# ----------------------------------------------------------------------
# Option ORDER / ANCHOR checks (Logic column: RANDOMIZATION,
# NON RANDOMIZATION, ALPHABETICAL ORDER, ANCHOR AT THE END)
#
#   * Order logic is QUESTION-level: whichever row of the question carries
#     it, it applies to the whole question (q["order_logic"]).
#   * "Anchor at the end" is OPTION-level (opt["anchor_end"]): that option
#     must be the LAST one on the live page. Anchored options are taken out
#     of the order comparison and checked separately.
#   * One test per question, no clicking of options: replay the path to the
#     question, read the option labels in DOM order, compare, done.
#   * Everything else in the runner selects options by TEXT (never by
#     index), so a randomized page order can't make the click tests pick
#     the wrong option.
# ----------------------------------------------------------------------

_SCREEN_LABELS_JS = r"""
(wantDropdown) => {
  const norm = s => (s || '').replace(/[\u00a0\u2003]/g, ' ').replace(/\s+/g, ' ').trim();
  const shown = el => {
    if (!el) return false;
    const r = el.getBoundingClientRect();
    if (r.width === 0 || r.height === 0) return false;
    for (let n = el; n && n.nodeType === 1; n = n.parentElement) {
      const cs = getComputedStyle(n);
      if (cs.display === 'none' || cs.visibility === 'hidden') return false;
    }
    return true;
  };
  if (wantDropdown) {
    const lists = [];
    document.querySelectorAll('select').forEach(sel => {
      if (!shown(sel)) return;
      const labs = [];
      sel.querySelectorAll('option').forEach(o => {
        const t = norm(o.textContent);
        if (!t || !o.value) return;                                  // blank placeholder
        if (/^(-+\s*)?(please\s+)?(select|choose)\b/i.test(t)) return; // "Select..." placeholder
        labs.push(t);
      });
      lists.push(labs);
    });
    return {mode: 'dropdown', lists: lists};
  }
  const CTRL = 'input[type="checkbox"], input[type="radio"], [role="checkbox"], [role="radio"]';
  const countCtrl = el => el.querySelectorAll(CTRL).length + (el.matches && el.matches(CTRL) ? 1 : 0);
  // The label text of ONE control. Never falls back to a container that holds
  // several controls (that would return every option's text joined together).
  const labelOf = c => {
    const lb = c.getAttribute('aria-labelledby');
    if (lb) {
      const t = norm(lb.split(/\s+/).map(id => { const e = document.getElementById(id); return e ? e.innerText : ''; }).join(' '));
      if (t) return t;
    }
    if (c.id) {
      const l = document.querySelector('label[for="' + CSS.escape(c.id) + '"]');
      if (l && norm(l.innerText)) return norm(l.innerText);
    }
    const wrap = c.closest('label');
    if (wrap && countCtrl(wrap) <= 1 && norm(wrap.innerText)) return norm(wrap.innerText);
    const al = norm(c.getAttribute('aria-label'));
    if (al) return al;
    // climb to the smallest ancestor that has text and still contains only THIS control
    let el = c;
    while (el.parentElement) {
      const par = el.parentElement;
      if (countCtrl(par) > 1) break;
      el = par;
      const t = norm(el.innerText);
      if (t) return t;
    }
    // last resort: text right after the control
    let n = c.nextSibling, t = '';
    while (n && !t) { t = norm(n.textContent); n = n.nextSibling; }
    return t;
  };
  const labels = [];
  document.querySelectorAll(CTRL).forEach(c => {
    if (c.parentElement && c.parentElement.closest('[role="checkbox"], [role="radio"]')) return;
    const lab = c.closest('label');
    const row = lab || c.parentElement;
    if (!(shown(row) || shown(c))) return;
    labels.push(labelOf(c));
  });
  return {mode: 'inline', lists: [labels]};
}
"""

ORDER_LOGIC_LABELS = {
    "RANDOM": "RANDOMIZATION",
    "NON_RANDOM": "NON RANDOMIZATION",
    "ALPHABETICAL": "ALPHABETICAL ORDER",
}


ORDER_FUZZY_MIN = 0.6   # min text similarity (0-1) to pair an Excel option with a page label when not equal/prefix


def _order_key(text):
    """Comparison key for option labels: whitespace/dash/quote-normalised, case-insensitive."""
    return _normalize_ws(text or "").casefold().strip(" .:;,")


def _order_display_text(opt):
    """
    The text an option shows on the live page, as far as the sheet knows:
    "Others(enter text)" -> "Others". Returns None for rows that are NOT a
    real on-screen option (bare "enter text" box row, "no option" row).
    """
    text = _normalize_ws(opt.get("option_text") or "")
    if not text or is_no_option_row(text) or is_specify_option(text):
        return None
    m = LABELED_SPECIFY_RE.match(text)
    return m.group("label").strip() if m else text


def _read_screen_options(page, q):
    """Visible option labels of the CURRENT page, in DOM (= display) order."""
    data = page.evaluate(_SCREEN_LABELS_JS, bool(q.get("dropdown")))
    lists = data.get("lists") or []
    if not lists:
        return []
    if data.get("mode") == "dropdown" and len(lists) > 1:
        # several <select>s on the page: keep the one that overlaps the sheet's options most
        wanted = {_order_key(_order_display_text(o)) for o in q["options"] if _order_display_text(o)}
        lists = sorted(lists, key=lambda labs: -sum(1 for t in labs if _order_key(t) in wanted))
    return lists[0]


def _match_options_to_screen(options, screen_labels):
    """
    Pair each Excel option with a label on the page.
    Returns (match: {option_list_index -> screen_index}, missing: [Excel option idx],
             extra: [screen idx not matched to any Excel option]).
    Pass 1 = exact (normalised) text. Pass 2 = prefix either way, so
    "Others(enter text)" finds "Other (please specify)".
    """
    screen_keys = [_order_key(t) for t in screen_labels]
    used, match = set(), {}
    cands = [(i, _order_display_text(o)) for i, o in enumerate(options)]
    cands = [(i, t) for i, t in cands if t]

    for i, t in cands:                                            # pass 1: exact
        k = _order_key(t)
        for j, sk in enumerate(screen_keys):
            if j not in used and sk == k:
                match[i] = j
                used.add(j)
                break
    for i, t in cands:                                            # pass 2: prefix
        if i in match:
            continue
        k = _order_key(t)
        variants = {k, k[:-1]} if k.endswith("s") else {k}        # "others" ~ "other ..."
        for j, sk in enumerate(screen_keys):
            if j in used or not sk:
                continue
            if any(v and (sk.startswith(v) or v.startswith(sk)) for v in variants):
                match[i] = j
                used.add(j)
                break
    # pass 3: fuzzy -- sheet text and live-page text often differ a little
    # (e.g. "...specific brand for this condition" vs "...specific toothpaste brands").
    # Best similarity >= ORDER_FUZZY_MIN among labels still unused. Reported in the
    # notes (fuzzy_pairs) but NOT treated as a failure -- order is what's being tested here.
    fuzzy = {}
    for i, t in cands:
        if i in match:
            continue
        k = _order_key(t)
        best_j, best_r = None, 0.0
        for j, sk in enumerate(screen_keys):
            if j in used or not sk:
                continue
            r = SequenceMatcher(None, k, sk).ratio()
            if r > best_r:
                best_j, best_r = j, r
        if best_j is not None and best_r >= ORDER_FUZZY_MIN:
            match[i] = best_j
            used.add(best_j)
            fuzzy[i] = best_j
    _match_options_to_screen.last_fuzzy = fuzzy
    missing = [i for i, _t in cands if i not in match]
    extra = [j for j in range(len(screen_labels)) if j not in used]
    return match, missing, extra


def _evaluate_option_order(q, screen_labels):
    """
    Pure comparison (no browser) -- returns dict:
      order_mode, order_passed (None if the question has no order logic),
      order_detail, anchor_passed (None if no anchored option), anchor_detail,
      passed (overall).
    """
    options = q["options"]
    mode = q.get("order_logic")
    match, missing, extra = _match_options_to_screen(options, screen_labels)
    name = lambda i: _order_display_text(options[i])
    actual_txt = " | ".join(screen_labels)

    anchored = [i for i, o in enumerate(options) if o.get("anchor_end") and _order_display_text(o)]
    free = [i for i, o in enumerate(options) if i not in anchored and _order_display_text(o)]

    out = {"order_mode": mode, "order_passed": None, "order_detail": "",
           "anchor_passed": None, "anchor_detail": ""}

    # ---------------- ORDER (question-level) ----------------
    if mode:
        problems = []
        if missing:
            problems.append(f"missing on page: {[name(i) for i in missing]}")
        if extra:
            problems.append(f"extra on page (not in Excel): {[screen_labels[j] for j in extra]}")

        free_matched = sorted((i for i in free if i in match), key=lambda i: match[i])
        if mode == "NON_RANDOM":
            exp = [i for i in free if i in match]            # Excel order
            if free_matched != exp:
                problems.append(f"expected Excel order {[name(i) for i in exp]} "
                                f"but page shows {[name(i) for i in free_matched]}")
        elif mode == "ALPHABETICAL":
            keys = [_order_key(name(i)) for i in free_matched]
            if keys != sorted(keys):
                problems.append(f"expected A-Z {[name(i) for i in sorted(free_matched, key=lambda i: _order_key(name(i)))]} "
                                f"but page shows {[name(i) for i in free_matched]}")
        # RANDOM: any order passes -- only the option SET (missing/extra above) is checked.

        out["order_passed"] = not problems
        out["order_detail"] = ("; ".join(problems) if problems
                               else {"RANDOM": "all options present (any order accepted)",
                                     "NON_RANDOM": "matches Excel order",
                                     "ALPHABETICAL": "A-Z order OK"}.get(mode, "OK"))

    # ---------------- ANCHOR (option-level) ----------------
    if anchored:
        total = len(screen_labels)
        k = len(anchored)
        problems = []
        not_found = [name(i) for i in anchored if i not in match]
        if not_found:
            problems.append(f"anchored option not found on page: {not_found}")
        else:
            actual_pos = [match[i] for i in anchored]                 # Excel order of the anchored options
            expected_pos = list(range(total - k, total))
            if actual_pos != expected_pos:
                problems.append(
                    "expected last: " + ", ".join(name(i) for i in anchored)
                    + " | actual position(s): "
                    + ", ".join(f"{name(i)}=#{match[i] + 1} of {total}" for i in anchored))
        out["anchor_passed"] = not problems
        out["anchor_detail"] = ("; ".join(problems) if problems
                                else "last on page: " + ", ".join(name(i) for i in anchored))

    flags = [out["order_passed"], out["anchor_passed"]]
    out["passed"] = all(f for f in flags if f is not None)
    out["fuzzy"] = [f"'{name(i)}' ~ '{screen_labels[j]}'"
                    for i, j in getattr(_match_options_to_screen, "last_fuzzy", {}).items()]
    out["screen"] = actual_txt
    return out


def _test_option_order(browser, survey_url, questions, qid, q, path, opt, log, screenshots_dir=None,
                        on_manual_help_needed=None):
    """
    ONE browser visit per question, but SEPARATE report rows (returns a list of TestResult):
      * ORDER row  (test_type "option_order")  -- RANDOMIZATION / NON RANDOMIZATION / ALPHABETICAL
      * ANCHOR row (test_type "option_anchor") -- "anchor at the end" options are last on the page
    A row is only produced for the checks the question actually has.
    """
    mode = q.get("order_logic")
    anchored_names = [_order_display_text(o) for o in q["options"] if o.get("anchor_end") and _order_display_text(o)]
    mode_name = {"RANDOM": "RANDOMIZATION", "NON_RANDOM": "NON RANDOMIZATION",
                 "ALPHABETICAL": "ALPHABETICAL"}.get(mode, mode)
    scope_bits = ([mode_name] if mode else []) + (["ANCHOR AT END: " + ", ".join(anchored_names)] if anchored_names else [])

    context = browser.new_context(no_viewport=True)
    page = context.new_page()
    page.set_default_timeout(DEFAULT_TIMEOUT_MS)

    def rows(order_ok, order_actual, order_notes, anchor_ok, anchor_actual, anchor_notes):
        """Build the separate result rows; one failure screenshot is shared by the failed rows."""
        shot = ""
        if (order_ok is False) or (anchor_ok is False):
            shot = _capture_failure_screenshot(page, qid, opt, "option_order", screenshots_dir, log) or ""
        out = []
        if mode:
            out.append(TestResult(qid, q["text"], "ORDER", f"({mode_name})", "option_order",
                                  mode_name, order_actual, bool(order_ok), order_notes,
                                  "" if order_ok else shot))
        if anchored_names:
            out.append(TestResult(qid, q["text"], "ANCHOR", "(anchor at end)", "option_anchor",
                                  "ANCHOR AT END", anchor_actual, bool(anchor_ok), anchor_notes,
                                  "" if anchor_ok else shot))
        return out

    def fail_all(actual, notes):
        return rows(False, actual, notes, False, actual, notes)

    try:
        log(f"\n=== Testing [{qid}] option order: {' + '.join(scope_bits)} ===")
        if not goto_with_retry(page, survey_url, log):
            log("    RESULT: FAIL (could not load survey page)")
            return fail_all("navigation timeout", "page.goto() timed out on every retry attempt.")
        page.wait_for_timeout(PAGE_SETTLE_MS)

        if not _replay_path(page, questions, path, log, on_manual_help_needed=on_manual_help_needed):
            log(f"    RESULT: FAIL (could not even reach {qid})")
            return fail_all("could not replay path", "Failed while navigating baseline path to this question.")

        # Question TEXT only -- not question_signature_present(), which demands every
        # option's literal Excel text on the page and so false-fails whenever one option's
        # sheet text differs slightly from the page (the order test reports that itself).
        _poll_until_settled(page, lambda: question_text_present_only(page, q),
                            max_wait_ms=ROUTING_SETTLE_MAX_WAIT_MS)
        if not question_text_present_only(page, q):
            log(f"    RESULT: FAIL (question {qid} is not on screen)")
            return fail_all("question not on screen", f"page showed: {_page_snippet(page)!r}")

        screen = _read_screen_options(page, q)
        log(f"    options on page ({len(screen)}): {screen}")
        if not screen:
            log("    RESULT: FAIL (could not read any option labels from the page)")
            return fail_all("no option labels found on page",
                            "No visible checkbox/radio/<select> options could be read -- if this question "
                            "uses a custom control (images / grid), the order check cannot read it.")

        ev = _evaluate_option_order(q, screen)
        fuzzy_note = ""
        if ev.get("fuzzy"):
            fuzzy_note = " || text differs between Excel and page (matched by similarity): " + "; ".join(ev["fuzzy"])
        page_order = f" || page order: {ev['screen']}"

        o_ok, a_ok = ev["order_passed"], ev["anchor_passed"]
        o_act = f"{mode_name} {'PASS' if o_ok else 'FAIL'}" if o_ok is not None else ""
        a_act = f"ANCHOR {'PASS' if a_ok else 'FAIL'}" if a_ok is not None else ""
        if o_ok is not None:
            log(f"    {qid} | {mode_name} | {o_act}  ({ev['order_detail']})")
        if a_ok is not None:
            log(f"    {qid} | ANCHOR AT END | {a_act}  ({ev['anchor_detail']})")
        log(f"    RESULT: {'PASS' if ev['passed'] else 'FAIL'}")

        return rows(o_ok, o_act, (ev["order_detail"] + fuzzy_note + page_order) if o_ok is not None else "",
                    a_ok, a_act, (ev["anchor_detail"] + fuzzy_note + page_order) if a_ok is not None else "")
    except Exception as e:
        log(f"    RESULT: FAIL (exception: {e})")
        return fail_all(f"exception: {e}", traceback.format_exc(limit=3))
    finally:
        context.close()
        time.sleep(INTER_TEST_DELAY_MS / 1000)


def _build_jobs(questions, paths):
    """
    Flatten every (question, option) test into one independent job list.
    Each job is (test_fn, qid, opt) -- everything a worker needs, since
    `path` and `q` are looked up from `paths`/`questions` (shared,
    READ-ONLY dicts -- safe to share across threads).

    For single-option questions, up to three tests are scheduled, but only
    the two that carry distinct signal ever show up in the report:
      1. option_routing -- select the option (checks the box) and clicks
         Next; expects the survey to proceed to opt["routing"]. This is
         the "I check the box, then click Next -> should move on" case.
      2. no_select_validation -- clicks Next WITHOUT ever touching the
         option; expects the survey to block/terminate. This is the "I
         leave the box unchecked, then click Next -> should NOT proceed"
         case. It self-skips (returns None, nothing added to the report)
         in two situations: the control isn't a real checkbox/radio (e.g.
         a single-button "Continue" action), or the checkbox is checked
         BY DEFAULT -- in which case leaving it alone is the same
         scenario as option_routing and would just be a duplicate line.
      3. check_then_uncheck -- checks the box, then unchecks it again,
         then clicks Next; expects block/terminate. This is the "I check
         it, then change my mind and uncheck it -> should NOT proceed"
         case. Self-skips the same way for non-checkbox controls.
    """
    jobs = []
    skipped = []  # (qid, opt) pairs excluded because Option_Choosing wasn't "yes"
    for qid, path in paths.items():
        q = questions[qid]
        options = q["options"]

        # Logic = COMPLETE MANDATORY -> one whole-question blank-then-answer test.
        if q.get("complete_mandatory") and options:
            jobs.append((_test_complete_mandatory, qid, {
                "option_no": "QUESTION",
                "option_text": "(whole question)",
                "termination": False,
                "specify_text": None,
                "routing": None,
                "choose": True,
                "row_idx": q.get("row_idx", options[0]["row_idx"]),
            }))

        # Logic = RANDOMIZATION / NON RANDOMIZATION / ALPHABETICAL ORDER (question-level)
        # and/or ANCHOR AT THE END (option-level) -> one option-order test, no option clicks.
        if options and (q.get("order_logic") or any(o.get("anchor_end") for o in options)):
            jobs.append((_test_option_order, qid, {
                "option_no": "ORDER",
                "option_text": "(option order)",
                "termination": False,
                "specify_text": None,
                "routing": None,
                "choose": True,
                "row_idx": q.get("row_idx", options[0]["row_idx"]),
            }))

        if q.get("type") == "MULTI_SELECT":
            # Whole-question test instead of per-option: select every real
            # option at once (see _test_multi_select_all's docstring for
            # why). A synthetic "ALL" placeholder option carries the report
            # labelling since there's no single real option to attribute
            # this test to.
            real_count = len([o for o in options if not is_specify_option(o["option_text"])])
            if options:
                placeholder = {
                    "option_no": "ALL",
                    "option_text": f"(all {real_count} options)",
                    "termination": False,
                    "specify_text": None,
                    "routing": None,
                    "choose": True,
                    "row_idx": options[0]["row_idx"],
                }
                jobs.append((_test_multi_select_all, qid, placeholder))
            for opt in options:  # Logic = MANDATORY on individual options of a MULTI_SELECT question
                if opt.get("mandatory") and opt.get("choose", True) and not is_no_option_row(opt["option_text"]):
                    jobs.append((_test_option_mandatory, qid, opt))
            continue

        for opt in options:
            if not opt.get("choose", True):
                skipped.append((qid, opt))
                continue
            # An option that only carries "anchor at the end" and has NO routing is there
            # just for the order check -- there is no route to test, so don't run the
            # routing test (it would FAIL with "(no routing specified)").
            if not (opt.get("anchor_end") and not opt.get("routing") and not opt.get("termination")):
                jobs.append((_test_option_routing, qid, opt))
            # Logic = MANDATORY on this option -> also run the blank-then-answer check.
            if opt.get("mandatory") and not is_no_option_row(opt["option_text"]):
                jobs.append((_test_option_mandatory, qid, opt))
        if len(options) == 1:
            opt = options[0]
            if opt.get("choose", True):
                jobs.append((_test_no_select_validation, qid, opt))
                jobs.append((_test_check_then_uncheck, qid, opt))
    return jobs, skipped


def _as_result_list(result):
    """A test function returns None (skipped), one TestResult, or a LIST of TestResults (option order test)."""
    if result is None:
        return []
    return list(result) if isinstance(result, (list, tuple)) else [result]


def _worker(worker_id, jobs_chunk, survey_url, questions, paths, headless, slow_mo, log, results_lock, summary,
            on_result=None, screenshots_dir=None, on_manual_help_needed=None):
    """
    One "window" of parallel testing: launches its OWN Playwright + browser
    instance (sync Playwright objects must not be shared across threads),
    then works through its assigned slice of jobs sequentially, same as the
    original single-threaded loop did for all of them.
    """
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless, slow_mo=slow_mo, args=_browser_launch_args(worker_id))
        try:
            for test_fn, qid, opt in jobs_chunk:
                q = questions[qid]
                path = paths[qid]
                result = test_fn(browser, survey_url, questions, qid, q, path, opt,
                                  lambda m: log(f"[worker {worker_id}] {m}"), screenshots_dir,
                                  on_manual_help_needed=on_manual_help_needed)
                for result in _as_result_list(result):
                    with results_lock:
                        summary.results.append(result)
                    if on_result:
                        on_result(result)
        finally:
            browser.close()


def run_tests(survey_url, questions, start_qid, paths, log=print, headless=True, slow_mo=0, max_workers=1,
              on_result=None, capture_failure_screenshots=True, screenshots_dir=None,
              on_manual_help_needed=None):
    """
    Main driver. For every question and every option, replay the baseline
    path to reach that question, test the option, and record PASS/FAIL.

    max_workers: how many browser "windows" to run at once. Every test is
    already fully self-contained (fresh context, full path replay from a
    clean page load), so splitting the job list across N parallel browser
    instances is safe and produces identical results to running them one at
    a time -- just faster. Keep this modest (e.g. 3-5): too high and you
    risk tripping the same anti-flood behaviour on the survey host that
    INTER_TEST_DELAY_MS exists to avoid.

    log: callable(str) used for live progress output (wired to the GUI).
    on_result: optional callable(TestResult), invoked immediately as each
    individual test finishes (in addition to being appended to
    summary.results) -- lets a GUI populate a live, structured results
    table as tests complete instead of waiting for the whole run to end.

    on_manual_help_needed: optional callable(option_text) -> bool, passed
    all the way down to select_option() (see its docstring). Only called
    when an option can't be found by any text-based strategy at all -- NOT
    for every option, and NOT as an AI-vision guess (that's deliberately
    not used here per policy). If max_workers > 1, this can be called from
    SEVERAL worker threads at once when more than one hits an unfindable
    option around the same time -- the callback implementation is
    responsible for serializing concurrent calls itself (e.g. a lock
    around actually showing a dialog) so multiple popups don't collide;
    run_tests does not add any such locking on its own.

    capture_failure_screenshots: when True (default), every FAILED test --
    including the classic "option is flagged TERMINATION in the sheet but
    the survey moved on to the next question anyway" case -- gets a
    full-page screenshot of exactly what the browser was showing at the
    moment of failure. Screenshots are named with the question, option, and
    test type so each one traces straight back to its row in the report.

    screenshots_dir: where to save those screenshots. Defaults to a fresh
    timestamped subfolder under SCREENSHOTS_ROOT_DIR (in the current
    working directory) so repeated runs never clobber each other's
    evidence. Pass capture_failure_screenshots=False to disable entirely.
    """
    summary = RunSummary()
    jobs, skipped = _build_jobs(questions, paths)
    summary.skipped_count = len(skipped)
    if skipped:
        log(f"Option_Choosing: skipping {len(skipped)} option(s) not marked 'yes' for testing:")
        for qid, opt in skipped:
            log(f"    [{qid}] option {opt['option_no']} ({opt['option_text']!r}) -- not selected for testing")

    if capture_failure_screenshots:
        if not screenshots_dir:
            stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            screenshots_dir = os.path.join(os.getcwd(), SCREENSHOTS_ROOT_DIR, stamp)
        os.makedirs(screenshots_dir, exist_ok=True)
        summary.screenshots_dir = screenshots_dir
    else:
        screenshots_dir = None

    if max_workers <= 1:
        # Sequential path: one browser, same as the original behaviour.
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=headless, slow_mo=slow_mo, args=_browser_launch_args(0))
            try:
                for test_fn, qid, opt in jobs:
                    q = questions[qid]
                    path = paths[qid]
                    result = test_fn(browser, survey_url, questions, qid, q, path, opt, log, screenshots_dir,
                                      on_manual_help_needed=on_manual_help_needed)
                    for result in _as_result_list(result):
                        summary.results.append(result)
                        if on_result:
                            on_result(result)
            finally:
                browser.close()
        return summary

    # Parallel path: split the flattened job list round-robin across
    # max_workers threads, each driving its own browser instance.
    max_workers = min(max_workers, len(jobs)) or 1
    chunks = [jobs[i::max_workers] for i in range(max_workers)]
    results_lock = threading.Lock()
    log_lock = threading.Lock()

    def safe_log(msg):
        with log_lock:
            log(msg)

    threads = [
        threading.Thread(
            target=_worker,
            args=(i, chunk, survey_url, questions, paths, headless, slow_mo, safe_log, results_lock, summary,
                  on_result, screenshots_dir),
            kwargs={"on_manual_help_needed": on_manual_help_needed},
            daemon=True,
        )
        for i, chunk in enumerate(chunks)
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    return summary