import os
import re
import datetime
import shutil
from collections import deque
import openpyxl

# Columns that are safe to edit from the GUI's routing-fix dialog, mapped
# 1:1 to the header names read by _read_headers(). Keeping this as a single
# source of truth means the GUI never has to guess a raw column letter --
# it always goes through save_edits() using these names.
#
# "TERMINATION" is kept as an editable field name for the GUI even though the
# sheet now uses a single "Logic" column instead: when the sheet has no
# TERMINATION column, save_edits() translates a TERMINATION edit into adding /
# removing the word TERMINATE inside the Logic cell (other Logic words such as
# MANDATORY are left alone).
EDITABLE_FIELDS = ["Option_Text", "TERMINATION", "Logic", "ROUTING"]


class SurveyParseError(Exception):
    pass


# --- Question-level ORDER logic + option-level ANCHOR logic --------------------
# Order words apply to the WHOLE question (wherever in the question's rows they
# are typed); "anchor at the end" applies to the OPTION ROW it is typed on.
ORDER_RANDOM = "RANDOM"
ORDER_NON_RANDOM = "NON_RANDOM"
ORDER_ALPHABETICAL = "ALPHABETICAL"

_RE_NON_RANDOM = re.compile(r"\bnon\s*random\w*(?:\s+order)?")
_RE_RANDOM = re.compile(r"\brandom\w*(?:\s+order)?")
_RE_ALPHABETICAL = re.compile(r"\balphabet\w*(?:\s+order)?")
_RE_ANCHOR_END = re.compile(r"\banchor\w*(?:\s+(?:at|to|in|on))?(?:\s+the)?\s+(?:end|last|bottom)\b")


def parse_logic(value):
    """
    Parse one cell of the sheet's "Logic" column. Recognised words (case-,
    space-, underscore- and hyphen-insensitive; may be combined with commas,
    e.g. "TERMINATE, MANDATORY"):

        TERMINATE            -> choosing this option ends the survey
        MANDATORY            -> THIS OPTION is mandatory: leaving it
                                unselected / its text box empty must be blocked
        COMPLETE MANDATORY   -> the WHOLE QUESTION is mandatory: clicking Next
                                with nothing selected / entered must be blocked
        DROPDOWN (or "DROP DOWN") -> the QUESTION's answer control is a
                                dropdown/picklist (e.g. year-of-birth), so
                                options must be selected by opening the
                                dropdown and choosing the matching entry,
                                not by clicking an inline radio/checkbox
        RANDOMIZATION        -> QUESTION-level: options may appear in any order
                                (Excel order is also fine); only the option SET
                                is checked on the live page
        NON RANDOMIZATION    -> QUESTION-level: options must appear exactly in
                                the Excel order
        ALPHABETICAL (ORDER) -> QUESTION-level: options must appear A-Z
        ANCHOR AT THE END    -> OPTION-level: this option must be the LAST one
                                on the live page (e.g. "Other(enter text)")

    Returns dict: raw, terminate, mandatory, complete_mandatory, dropdown,
    order (None | RANDOM | NON_RANDOM | ALPHABETICAL -- first one found),
    order_all (every distinct order word found; >1 means conflicting),
    anchor_end, unknown (unknown = any leftover text that isn't one of the
    words above -- lets validate_routing() flag typos like "MANDATROY" instead
    of silently ignoring them).
    """
    raw = "" if value in (None, "") else str(value).strip()
    norm = re.sub(r"[\s_\-]+", " ", raw.lower())
    complete = "complete mandatory" in norm
    rest = norm.replace("complete mandatory", " ")
    dropdown = "dropdown" in rest.replace(" ", "")
    rest_no_dd = re.sub(r"drop\s*down", " ", rest)

    # Order / anchor words. "non random..." must be consumed BEFORE "random..."
    # (it contains it), so each regex is applied to what the previous left over.
    order_all = []
    work = rest_no_dd
    if _RE_NON_RANDOM.search(work):
        order_all.append(ORDER_NON_RANDOM)
        work = _RE_NON_RANDOM.sub(" ", work)
    if _RE_RANDOM.search(work):
        order_all.append(ORDER_RANDOM)
        work = _RE_RANDOM.sub(" ", work)
    if _RE_ALPHABETICAL.search(work):
        order_all.append(ORDER_ALPHABETICAL)
        work = _RE_ALPHABETICAL.sub(" ", work)
    anchor_end = bool(_RE_ANCHOR_END.search(work))
    work = _RE_ANCHOR_END.sub(" ", work)

    leftover = re.sub(r"mandatory|terminat\w*", " ", work)
    leftover = re.sub(r"\band\b|[\s,;/&+|]+", " ", leftover).strip()
    return {
        "raw": raw,
        "terminate": bool(re.search(r"terminat", norm)),
        "mandatory": "mandatory" in rest,
        "complete_mandatory": complete,
        "dropdown": dropdown,
        "order": order_all[0] if order_all else None,
        "order_all": order_all,
        "anchor_end": anchor_end,
        "unknown": leftover,
    }


def _set_terminate_in_logic(old_value, flag_value):
    """
    Return a new Logic cell value with the TERMINATE word added (flag_value
    truthy) or removed (falsy), keeping every other word (MANDATORY etc.).
    """
    old = "" if old_value in (None, "") else str(old_value)
    kept = re.sub(r"terminat\w*", " ", old, flags=re.IGNORECASE)
    kept = [t.strip() for t in re.split(r"[,;/&+|]+", kept) if t.strip()]
    truthy = str(flag_value).strip().lower() not in ("", "no", "n", "false", "0", "none")
    if truthy:
        kept.append("TERMINATE")
    return ", ".join(kept) if kept else None


def _read_headers(ws):
    """Read row 1 and return (col: dict[name -> 0-based index], headers: list, specify_col_name: str|None)."""
    header_row = next(ws.iter_rows(min_row=1, max_row=1))
    headers = [str(c.value).strip() if c.value else "" for c in header_row]
    required = ["Row_Type", "Q_No", "Q_Text", "Q_Type", "Option_No", "Option_Text", "ROUTING"]
    col = {}
    for name in required:
        if name not in headers:
            raise SurveyParseError(f"Required column '{name}' not found in sheet headers: {headers}")
        col[name] = headers.index(name)

    # Termination / mandatory rules live in a single "Logic" column (words:
    # TERMINATE, MANDATORY, COMPLETE MANDATORY -- see parse_logic()). The old
    # separate "TERMINATION" column is still honoured if a sheet has one, so
    # older routing files keep working; at least one of the two must exist.
    logic_col = next(
        (h for h in headers if h.replace(" ", "_").replace("-", "_").lower() == "logic"),
        None,
    )
    if logic_col:
        col["Logic"] = headers.index(logic_col)
    if "TERMINATION" in headers:
        col["TERMINATION"] = headers.index("TERMINATION")
    if "Logic" not in col and "TERMINATION" not in col:
        raise SurveyParseError(
            f"Required column 'Logic' (or legacy 'TERMINATION') not found in sheet headers: {headers}"
        )

    # Optional column: lets the sheet author specify exactly what text should be
    # typed into an "(specify)" / open-end text box that appears after selecting
    # a given option (e.g. "Other States & Territories (specify)"). Entirely
    # optional -- if the column isn't present, options simply have no
    # predefined specify text and the test runner falls back to a
    # dynamically-generated placeholder instead.
    SPECIFY_COL_NAMES = ["Specify_Text", "Specify_Answer", "Open_Text", "Open_End_Text"]
    specify_col = next((name for name in SPECIFY_COL_NAMES if name in headers), None)
    if specify_col:
        col["Specify_Text"] = headers.index(specify_col)

    # Optional column: lets the sheet author mark, per OPTION row, whether that
    # specific option should actually be exercised by the automated test run.
    # A value of "yes" (case-insensitive) means "test this option"; anything
    # else (blank, "no", etc.) means "skip this option -- don't click/select
    # it during the run". Matched case-insensitively and independent of
    # underscores/spaces so "Option_Choosing", "Option choosing",
    # "OPTION_CHOOSING", etc. all resolve to the same column. Entirely
    # optional -- if the column isn't present at all, every option defaults
    # to being tested (identical to the runner's previous behaviour).
    choosing_col = next(
        (h for h in headers if h.replace(" ", "_").replace("-", "_").lower() == "option_choosing"),
        None,
    )
    if choosing_col:
        col["Option_Choosing"] = headers.index(choosing_col)

    return col, headers, specify_col


def load_survey(xlsx_path, sheet_name=None):
    """Return (questions: dict[qid -> question], start_qid: str, order: list[str], sheet_name: str).

    Each option dict also carries a "row_idx" (1-based sheet row number) so
    that a specific option's ROUTING / TERMINATION / Option_Text can later be
    located and edited precisely via save_edits(), without guessing.
    """
    wb = openpyxl.load_workbook(xlsx_path, data_only=True)
    ws = wb[sheet_name] if sheet_name else wb.active
    resolved_sheet_name = ws.title

    col, headers, _specify_col = _read_headers(ws)

    questions = {}
    order = []
    current_q = None

    for row_idx, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
        def get(colname):
            idx = col.get(colname)
            if idx is None:
                return None
            return row[idx] if idx < len(row) else None

        row_type = get("Row_Type")
        q_no = get("Q_No")
        q_text = get("Q_Text")
        q_type = get("Q_Type")
        opt_no = get("Option_No")
        opt_text = get("Option_Text")
        term = get("TERMINATION")   # legacy column (None if the sheet doesn't have one)
        logic = parse_logic(get("Logic"))
        routing = get("ROUTING")
        specify_text = get("Specify_Text")
        choosing_val = get("Option_Choosing")

        if q_no not in (None, ""):
            current_q = str(q_no).strip()
            questions[current_q] = {
                "qid": current_q,
                "row_type": (str(row_type).strip() if row_type else ""),
                "text": (str(q_text).strip() if q_text else ""),
                "type": (str(q_type).strip().upper() if q_type else ""),
                "row_idx": row_idx,
                "complete_mandatory": False,   # set True if any of its rows says COMPLETE MANDATORY
                "dropdown": False,             # set True if any of its rows says DROPDOWN
                "order_logic": None,           # RANDOM / NON_RANDOM / ALPHABETICAL (question-level, from any of its rows)
                "order_conflict": [],          # >1 different order words found in this question (flagged by validate_routing)
                "options": [],
            }
            order.append(current_q)

        if current_q is not None and logic["complete_mandatory"]:
            questions[current_q]["complete_mandatory"] = True
        if current_q is not None and logic["dropdown"]:
            questions[current_q]["dropdown"] = True
        if current_q is not None and logic["order_all"]:
            qd = questions[current_q]
            for ow in logic["order_all"]:
                if qd["order_logic"] is None:
                    qd["order_logic"] = ow
                elif ow != qd["order_logic"] and ow not in qd["order_conflict"]:
                    qd["order_conflict"].append(ow)

        if current_q is not None and opt_no not in (None, ""):
            # "choose" -- whether the runner should actually exercise this
            # option during the automated pass. If the Option_Choosing column
            # isn't present in the sheet at all, every option is tested (old
            # behaviour, fully backward compatible). If the column IS present,
            # only rows whose value is literally "yes" (case-insensitive) are
            # tested -- blank/"no"/anything else means "skip".
            if "Option_Choosing" in col:
                choose = str(choosing_val).strip().lower() == "yes" if choosing_val not in (None, "") else False
            else:
                choose = True

            questions[current_q]["options"].append({
                "option_no": opt_no,
                "option_text": (str(opt_text).strip() if opt_text else ""),
                "termination": bool(term and str(term).strip()) or logic["terminate"],
                "mandatory": logic["mandatory"],
                "anchor_end": logic["anchor_end"],   # option-level: must be LAST on the live page
                "logic": logic["raw"],
                "logic_unknown": logic["unknown"],
                "specify_text": (str(specify_text).strip() if specify_text not in (None, "") else None),
                "routing": (str(routing).strip() if routing not in (None, "") else None),
                "choose": choose,
                "row_idx": row_idx,
            })

    if not order:
        raise SurveyParseError("No question rows found (no row had a Q_No value).")

    start_qid = order[0]
    return questions, start_qid, order, resolved_sheet_name


def save_edits(xlsx_path, edits, sheet_name=None, make_backup=True):
    """
    Apply a batch of cell-level edits directly to the routing Excel file,
    without touching anything else in the workbook (formatting, other
    sheets, other rows are left untouched).

    edits: list of dicts, each {"row_idx": int, "field": one of EDITABLE_FIELDS, "value": str}
           row_idx and field normally come straight from an option dict
           returned by load_survey() (option["row_idx"]) paired with the
           field the user changed in the GUI's edit dialog.

    Returns: (backup_path_or_None, applied: list[dict]) -- applied echoes
    back what was written, so the caller can log a clear before/after line
    per change.

    A timestamped backup copy of the original file is made first (unless
    make_backup=False) so a bad edit never destroys the only copy of the
    routing sheet.
    """
    backup_path = None
    if make_backup:
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        root, ext = os.path.splitext(xlsx_path)
        backup_path = f"{root}_backup_{stamp}{ext}"
        shutil.copy2(xlsx_path, backup_path)

    # Load WITHOUT data_only so any existing formulas elsewhere in the sheet
    # are preserved rather than being flattened to their last-computed value.
    wb = openpyxl.load_workbook(xlsx_path, data_only=False)
    ws = wb[sheet_name] if sheet_name else wb.active
    col, _headers, _specify_col = _read_headers(ws)

    applied = []
    for edit in edits:
        row_idx = edit["row_idx"]
        field = edit["field"]
        value = edit["value"]
        if field not in EDITABLE_FIELDS:
            raise SurveyParseError(f"'{field}' is not an editable field (allowed: {EDITABLE_FIELDS})")
        if field == "TERMINATION" and "TERMINATION" not in col and "Logic" in col:
            # Sheet uses the single Logic column: add/remove the word TERMINATE
            # inside it, leaving other words (e.g. MANDATORY) untouched.
            col_idx = col["Logic"] + 1
            old_value = ws.cell(row=row_idx, column=col_idx).value
            value = _set_terminate_in_logic(old_value, value)
        elif field not in col:
            raise SurveyParseError(f"Column for '{field}' not found in sheet headers: {_headers}")
        else:
            col_idx = col[field] + 1  # openpyxl columns are 1-based
            old_value = ws.cell(row=row_idx, column=col_idx).value
        ws.cell(row=row_idx, column=col_idx, value=value)
        applied.append({"row_idx": row_idx, "field": field, "old_value": old_value, "new_value": value})

    wb.save(xlsx_path)
    return backup_path, applied


def validate_routing(questions):
    """Sanity-check that every ROUTING target actually exists as a question.
    Returns a list of warning strings (empty if everything resolves)."""
    warnings = []
    for qid, q in questions.items():
        for opt in q["options"]:
            if not opt["termination"] and opt["routing"] and opt["routing"] not in questions:
                warnings.append(
                    f"Question {qid} option {opt['option_no']} ('{opt['option_text']}') "
                    f"routes to unknown Q_No '{opt['routing']}'"
                )
            if opt.get("logic_unknown"):
                warnings.append(
                    f"Question {qid} option {opt['option_no']} ('{opt['option_text']}') has an "
                    f"unrecognised Logic value {opt['logic']!r} (allowed: TERMINATE, MANDATORY, "
                    f"COMPLETE MANDATORY, DROPDOWN, RANDOMIZATION, NON RANDOMIZATION, "
                    f"ALPHABETICAL ORDER, ANCHOR AT THE END) -- check for a typo"
                )
        if q.get("order_conflict"):
            warnings.append(
                f"Question {qid} has conflicting order logic: {q['order_logic']} and "
                f"{', '.join(q['order_conflict'])} -- only {q['order_logic']} will be tested"
            )
    return warnings


def build_baseline_paths(questions, start_qid):
    """
    BFS over the question graph (edges = non-terminating options) to find
    the SHORTEST sequence of (qid, option) choices needed to reach every
    reachable question from start_qid.

    Returns: dict[qid -> list[(qid_visited, option_dict)]]
             (the path of answers to give, in order, to land on `qid`
             without yet having answered `qid` itself)
    """
    paths = {start_qid: []}
    q = deque([start_qid])
    while q:
        cur = q.popleft()
        cur_path = paths[cur]
        for opt in questions[cur]["options"]:
            if opt["termination"]:
                continue
            nxt = opt["routing"]
            if not nxt or nxt not in questions:
                continue
            if nxt not in paths:
                paths[nxt] = cur_path + [(cur, opt)]
                q.append(nxt)
    return paths


def unreachable_questions(questions, start_qid):
    paths = build_baseline_paths(questions, start_qid)
    return [qid for qid in questions if qid not in paths]


if __name__ == "__main__":
    import sys
    import json

    path = sys.argv[1] if len(sys.argv) > 1 else "/mnt/user-data/uploads/QNR_Simplified_2__1_.xlsx"
    questions, start_qid, order, sheet_name = load_survey(path)
    print(f"Sheet: {sheet_name}")

    print(f"Start question: {start_qid}")
    print(f"Total questions parsed: {len(questions)}")
    for qid in order:
        q = questions[qid]
        cm = "  [COMPLETE MANDATORY]" if q.get("complete_mandatory") else ""
        dd = "  [DROPDOWN]" if q.get("dropdown") else ""
        ol = f"  [ORDER: {q['order_logic']}]" if q.get("order_logic") else ""
        print(f"\n[{qid}] ({q['row_type']}, {q['type']}) {q['text'][:70]!r}{cm}{dd}{ol}")
        for opt in q["options"]:
            tag = "TERMINATE" if opt["termination"] else f"-> {opt['routing']}"
            if opt.get("mandatory"):
                tag += "  [MANDATORY]"
            if opt.get("anchor_end"):
                tag += "  [ANCHOR END]"
            print(f"    {opt['option_no']}. {opt['option_text']!r:40} {tag}")

    print("\nRouting warnings:")
    warnings = validate_routing(questions)
    print(warnings if warnings else "  none")

    print("\nBaseline paths (BFS) to reach each question:")
    paths = build_baseline_paths(questions, start_qid)
    for qid, path in paths.items():
        steps = " -> ".join(f"{p[0]}:opt{p[1]['option_no']}" for p in path) or "(start)"
        print(f"  {qid}: {steps}")

    print("\nUnreachable questions:", unreachable_questions(questions, start_qid) or "none")