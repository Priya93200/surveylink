

import os
import datetime
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter


PASS_FILL = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
FAIL_FILL = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
HEADER_FILL = PatternFill(start_color="305496", end_color="305496", fill_type="solid")
HEADER_FONT = Font(color="FFFFFF", bold=True, name="Arial")
CELL_FONT = Font(name="Arial")
LINK_FONT = Font(name="Arial", color="0563C1", underline="single")


def write_report(summary, out_path, survey_url):
    wb = openpyxl.Workbook()

    # ---- Summary sheet ----
    ws_sum = wb.active
    ws_sum.title = "Summary"
    ws_sum["A1"] = "Survey Link Test Summary"
    ws_sum["A1"].font = Font(bold=True, size=14, name="Arial")
    ws_sum["A3"] = "Survey URL"
    ws_sum["B3"] = survey_url
    ws_sum["A4"] = "Run timestamp"
    ws_sum["B4"] = datetime.datetime.now().isoformat(timespec="seconds")
    ws_sum["A5"] = "Total tests"
    ws_sum["B5"] = summary.total
    ws_sum["A6"] = "Passed"
    ws_sum["B6"] = summary.passed
    ws_sum["A7"] = "Failed"
    ws_sum["B7"] = summary.failed
    last_row = 7
    screenshots_dir = getattr(summary, "screenshots_dir", "")
    if screenshots_dir:
        last_row = 8
        ws_sum["A8"] = "Failure screenshots"
        ws_sum["B8"] = screenshots_dir
    for r in range(3, last_row + 1):
        ws_sum[f"A{r}"].font = Font(bold=True, name="Arial")
        ws_sum[f"B{r}"].font = CELL_FONT
    ws_sum.column_dimensions["A"].width = 18
    ws_sum.column_dimensions["B"].width = 60

    # ---- Detail sheet ----
    ws = wb.create_sheet("Test Results")
    headers = ["Q_No", "Question Text", "Option_No", "Option Text",
               "Test Type", "Expected", "Actual", "Result", "Notes", "Screenshot"]
    ws.append(headers)
    for col_idx, _ in enumerate(headers, start=1):
        c = ws.cell(row=1, column=col_idx)
        c.font = HEADER_FONT
        c.fill = HEADER_FILL
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    for r in summary.results:
        screenshot_path = getattr(r, "screenshot_path", "") or ""
        row = [
            r.qid, r.q_text, r.option_no, r.option_text,
            r.test_type, r.expected, r.actual,
            "PASS" if r.passed else "FAIL", r.notes,
            os.path.basename(screenshot_path) if screenshot_path else "",
        ]
        ws.append(row)
        result_cell = ws.cell(row=ws.max_row, column=8)
        result_cell.fill = PASS_FILL if r.passed else FAIL_FILL
        result_cell.font = Font(bold=True, name="Arial")
        for col_idx in range(1, len(headers) + 1):
            cell = ws.cell(row=ws.max_row, column=col_idx)
            if col_idx != 8:
                cell.font = CELL_FONT
            cell.alignment = Alignment(vertical="top", wrap_text=True)

        # Turn the screenshot cell into a clickable link straight to the
        # saved evidence image (only present on FAILED rows -- see
        # playwright_runner._capture_failure_screenshot).
        if screenshot_path:
            link_cell = ws.cell(row=ws.max_row, column=10)
            link_cell.hyperlink = screenshot_path
            link_cell.font = LINK_FONT

    widths = [10, 45, 10, 30, 20, 30, 30, 10, 40, 30]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w
    ws.freeze_panes = "A2"

    # Open the file straight onto Test Results (the actual per-test data)
    # rather than Summary -- the two-tab layout otherwise makes it easy to
    # miss that the detail rows are one tab over.
    wb.active = wb.sheetnames.index("Test Results")
    for sheet in wb.worksheets:
        sheet.sheet_view.tabSelected = (sheet.title == "Test Results")

    wb.save(out_path)
    return out_path