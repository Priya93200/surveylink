"""
ai_assistant.py
================
Floating "Ask AI" chat bubble + popup chat window for the Survey Link
Flow Tester GUI. It talks to the OpenAI Chat Completions API and can
answer questions about the survey data currently loaded, the last test
run, and any errors that showed up in the log -- because the host app
feeds it a fresh context snapshot on every question (see
`context_provider` below).

The GUI part is written for PySide6 (Qt). It only needs a QMainWindow /
QWidget to attach to, so it can be dropped into any of your Qt apps.

--------------------------------------------------------------------
SECURITY NOTE ON THE API KEY -- READ THIS
--------------------------------------------------------------------
Never hardcode a real API key inside a .py file. Files get committed,
screenshotted, pasted into chats/tickets, or shared over Slack, and a
key is a bearer credential -- anyone who has the string can spend on
your account. This module deliberately does NOT contain a key. It
looks for one in this order:

    1. The OPENAI_API_KEY environment variable.
    2. A local file `ai_config.json` sitting next to this script
       (created automatically the first time you enter a key in the
       "Set API key" dialog). Add this file to .gitignore.

If a key has ever been pasted somewhere outside your own machine
(a chat window, an issue tracker, a shared doc, etc.), treat it as
compromised: revoke it at https://platform.openai.com/api-keys and
generate a new one, then enter the new one via the dialog below.

How to set your key
--------------------
Option A -- environment variable (recommended):
    Windows (PowerShell):   setx OPENAI_API_KEY "sk-...."
    macOS / Linux (bash):   export OPENAI_API_KEY="sk-...."
    Then just run the app normally.

Option B -- in-app dialog:
    Click the chat bubble -> "Set API key" -> paste the key.
    It's written to ai_config.json (local file, not env-wide) and
    reused on future launches from that same folder.
"""

import os
import json
import base64
import threading
import urllib.request
import urllib.error

from PySide6.QtCore import Qt, QEvent, QPoint, Signal
from PySide6.QtGui import QColor, QFont, QTextCharFormat, QTextCursor
from PySide6.QtWidgets import (
    QCheckBox, QDialog, QGraphicsDropShadowEffect, QHBoxLayout, QLabel,
    QLineEdit, QMessageBox, QPushButton, QTextEdit, QVBoxLayout,
)

# Optional: pick up OPENAI_API_KEY from a .env file if python-dotenv is installed.
try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ai_config.json")
OPENAI_CHAT_URL = "https://api.openai.com/v1/chat/completions"
DEFAULT_MODEL = "gpt-4.1-mini"  # change to "gpt-5-mini", "gpt-5.1-mini", etc. if your project has those enabled
MAX_CONTEXT_CHARS = 6000        # keep the context snapshot from ballooning the prompt

# ======================================================================
# HARDCODED API KEY -- paste your key between the quotes below.
# This is checked FIRST (before the env var / ai_config.json), so the app,
# the chat bubble and playwright_runner's logo matching all use it.
# Keep this file out of git / chats / shared drives.
# ======================================================================
HARDCODED_API_KEY = "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"   # e.g. "sk-proj-...."


BUBBLE_BG = "#4f46e5"
BUBBLE_BG_HOVER = "#4338ca"
PANEL_BG = "#ffffff"
BORDER = "#e5e7eb"
TEXT = "#1f2937"
MUTED = "#6b7280"
PRIMARY = "#4f46e5"
SUCCESS = "#059669"
DANGER = "#dc2626"


# ======================================================================
# Key storage
# ======================================================================
def load_api_key():
    """Hardcoded constant first (if set), then env var, then local config
    file. Returns None if not set anywhere."""
    if HARDCODED_API_KEY and HARDCODED_API_KEY.strip() and "PASTE_YOUR_KEY" not in HARDCODED_API_KEY:
        return HARDCODED_API_KEY.strip()
    key = os.environ.get("OPENAI_API_KEY")
    if key:
        return key.strip()
    if os.path.isfile(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            key = data.get("openai_api_key")
            if key:
                return key.strip()
        except Exception:
            pass
    return None


def save_api_key(key):
    data = {}
    if os.path.isfile(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            data = {}
    data["openai_api_key"] = key.strip()
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


# ======================================================================
# OpenAI call (plain urllib -- no extra dependency on the `openai` package)
# ======================================================================
class OpenAIError(Exception):
    pass


def ask_openai(messages, api_key, model=DEFAULT_MODEL, timeout=45):
    # GPT-5 family (and reasoning models like o-series) use a different
    # token-limit param and only accept the default temperature (1) --
    # passing "temperature" or "max_tokens" to them raises a 400 error.
    is_reasoning_family = model.startswith("gpt-5") or model.startswith("o")

    body_params = {
        "model": model,
        "messages": messages,
    }
    if is_reasoning_family:
        body_params["max_completion_tokens"] = 700
    else:
        body_params["temperature"] = 0.3
        body_params["max_tokens"] = 700

    payload = json.dumps(body_params).encode("utf-8")

    req = urllib.request.Request(
        OPENAI_CHAT_URL,
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="replace")
        if e.code == 401:
            raise OpenAIError("Invalid or revoked API key (401). Set a fresh key via the chat window.")
        raise OpenAIError(f"OpenAI API error {e.code}: {detail[:400]}")
    except urllib.error.URLError as e:
        raise OpenAIError(f"Could not reach OpenAI API: {e.reason}")

    try:
        return body["choices"][0]["message"]["content"].strip()
    except (KeyError, IndexError):
        raise OpenAIError(f"Unexpected response shape from API: {body}")


# ======================================================================
# Image / logo identification (vision) -- used by playwright_runner.py's
# unlabeled-option fallback: a checkbox/radio next to a bare logo image,
# color swatch, or icon with no matchable text at all (no accessible
# label, no alt text). Reuses ask_openai() above for the actual network
# call, so it automatically gets the same GPT-5-family parameter handling
# (max_completion_tokens instead of max_tokens, no custom temperature).
# ======================================================================
IMAGE_MATCH_MODEL = "gpt-5"  # vision-capable; "gpt-5-mini", "gpt-4o", "gpt-4.1-mini" etc. also work


def identify_brand_logo(image_bytes, option_text, api_key, model=IMAGE_MATCH_MODEL):
    """
    Ask a vision-capable model whether a cropped screenshot of a single
    unlabeled option (an image with no surrounding text -- a brand logo,
    a color swatch, an icon, a symbol, anything) matches the label given in
    `option_text` (straight from the routing sheet's Option_Text column,
    e.g. "Alcon", "Red", "Recommended by family/ friends").

    Returns True/False. Raises OpenAIError on a request failure -- the
    caller (playwright_runner._select_image_option) treats that as "no
    match" for this particular image and moves on to the next candidate
    rather than aborting the whole test.

    NOTE: kept for backward compatibility / single-candidate cases.
    identify_brand_logo_among() below is preferred whenever there's more
    than one candidate -- see its docstring for why.
    """
    b64 = base64.b64encode(image_bytes).decode("ascii")
    messages = [
        {
            "role": "system",
            "content": (
                "You compare a text label to an image cropped from a survey "
                "webpage. The label can describe ANY kind of visual -- a "
                "company/brand logo, a plain color swatch, an icon, a "
                "symbol, an illustration -- not only logos; judge whatever "
                "the image actually shows against the label's plain meaning. "
                "Reply with exactly one word: YES or NO. No punctuation, no "
                "explanation, no extra words."
            ),
        },
        {
            "role": "user",
            "content": [
                {
                    "type": "text",
                    "text": (
                        f"Does this image match the label '{option_text}'? "
                        "Reply YES or NO only."
                    ),
                },
                {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}},
            ],
        },
    ]
    answer = ask_openai(messages, api_key, model=model, timeout=30)
    return answer.strip().upper().startswith("Y")


def identify_brand_logo_among(image_bytes_list, option_text, api_key, model=IMAGE_MATCH_MODEL, mode="brand"):
    """
    Ask a vision-capable model to pick WHICH of several candidate images
    matches the label given in `option_text`, in a single request.

    mode="brand" (default): asks specifically "which image shows the LOGO
    of the BRAND '{option_text}'?" -- sharp and confident, and the right
    framing whenever option_text plausibly IS a real brand/company name
    (e.g. "Alcon", "Johnson & Johnson Acuvue"). This wording is kept as
    the default because it's measurably more reliable for real brand
    logos than the broader mode="generic" below -- broadening the wording
    to cover colors/icons/etc. made the model noticeably LESS confident
    even on clear-cut brand logos it used to match consistently (more
    hedged phrasing tends to make the model answer "unsure/NONE" more
    often, even for genuinely unambiguous cases).

    mode="generic": asks the broader "which image matches the label" with
    explicit permission for colors/icons/symbols/etc. -- necessary for
    anything that ISN'T a real brand name (e.g. "Red", "Recommended by
    family/ friends"), where mode="brand" has no correct answer to give
    (asking "which is the LOGO of the BRAND 'Red'" is ill-posed even when
    a red swatch is on screen) and reliably returns NONE.

    Callers should try mode="brand" first and only fall back to
    mode="generic" if that finds nothing -- see
    playwright_runner._select_image_option()'s two-attempt loop. This
    keeps the already-reliable brand-logo path exactly as sharp as before
    while still covering non-brand cases the old approach couldn't handle
    at all.

    This is deliberately preferred over calling identify_brand_logo() once
    per candidate: asking N independent, isolated "does this match?"
    questions gives the model no comparative context and no way to reason
    about "this one is a closer match than that one" -- in practice that
    shows up as real flakiness, where the exact same image grid correctly
    matches on one test run and comes back "no match found" on the next,
    purely because a single borderline crop got an independent,
    low-confidence "no". Showing every candidate together, numbered, in one
    prompt lets the model directly compare them and make one relative
    decision instead of several unrelated absolute ones -- meaningfully
    more consistent in practice, and it's also fewer API calls.

    image_bytes_list: list of PNG bytes, one per candidate, in the same
    order the caller will click them by index.

    Returns the 0-based index of the matching candidate, or None if the
    model reports no match. Raises OpenAIError on a request failure --
    the caller treats that the same as "no match" and can retry or move on.
    """
    if mode == "generic":
        question_text = (
            f"Each image below is numbered 1 to {len(image_bytes_list)}, in that order. "
            f"Which numbered image matches the label '{option_text}'? The label might "
            "describe a company/brand logo, a plain color, an icon, a symbol, or any "
            "other visual -- judge each image against the label's plain meaning, "
            "whatever kind of image that turns out to require. "
            "Reply with ONLY the number (e.g. '3'). If none of them match, reply with "
            "exactly: NONE. No other words, no punctuation."
        )
        system_text = (
            "You compare a text label to a set of numbered images cropped from a "
            "survey webpage. Labels can describe ANY kind of visual -- a company/"
            "brand logo, a plain color swatch, an icon, a symbol, an illustration -- "
            "not only logos. Reply with ONLY a single number, or the word NONE. "
            "No punctuation, no explanation, no extra words."
        )
    else:
        question_text = (
            f"Each image below is numbered 1 to {len(image_bytes_list)}, in that order. "
            f"Which numbered image shows the logo of the brand '{option_text}'? "
            "Reply with ONLY the number (e.g. '3'). If none of them show that brand's "
            "logo, reply with exactly: NONE. No other words, no punctuation."
        )
        system_text = (
            "You identify company/brand logos in numbered screenshots taken from a "
            "survey webpage. Reply with ONLY a single number, or the word NONE. "
            "No punctuation, no explanation, no extra words."
        )

    content = [{"type": "text", "text": question_text}]
    for i, image_bytes in enumerate(image_bytes_list, start=1):
        b64 = base64.b64encode(image_bytes).decode("ascii")
        content.append({"type": "text", "text": f"Image {i}:"})
        content.append({"type": "image_url", "image_url": {"url": f"data:image/png;base64,{b64}"}})

    messages = [
        {"role": "system", "content": system_text},
        {"role": "user", "content": content},
    ]
    answer = ask_openai(messages, api_key, model=model, timeout=45).strip().upper()
    if answer == "NONE" or not answer:
        return None
    # Model occasionally wraps the number in stray punctuation/words despite
    # instructions ("Image 3", "#3.") -- pull out the first integer found.
    digits = "".join(ch for ch in answer if ch.isdigit())
    if not digits:
        return None
    idx = int(digits) - 1
    if 0 <= idx < len(image_bytes_list):
        return idx
    return None


SYSTEM_PROMPT = (
    "You are an in-app assistant embedded in a desktop tool called "
    "'Survey Link Flow Tester'. That tool parses a QNR-style routing "
    "Excel sheet (questions, options, TERMINATION flags, ROUTING targets), "
    "then drives an automated Playwright browser session through a live "
    "survey link to check that the routing logic (branching / termination) "
    "actually matches what the Excel sheet says, and produces a PASS/FAIL "
    "report.\n\n"
    "You will be given a CONTEXT SNAPSHOT of the user's current session: "
    "the survey URL, the loaded routing sheet's questions, any routing "
    "warnings, the most recent test run's results, and the tail of the "
    "live log (which is where error messages show up). Use it to answer "
    "the user's question. If the answer isn't in the context, say so "
    "plainly instead of guessing, and suggest what the user could check "
    "or click in the app (e.g. 'Preview Structure', 'Run Test', the "
    "Live Log tab) to get the missing information. Be concise and "
    "practical -- this is a working tool, not a chat toy."
)


def _truncate(s, limit):
    if s is None:
        return ""
    s = str(s)
    if len(s) <= limit:
        return s
    return s[-limit:]  # keep the tail -- most recent log lines matter most


def build_context_block(context: dict) -> str:
    """Turn the host app's context dict into a compact text block for the prompt."""
    if not context:
        return "(no survey/session data loaded yet)"

    lines = []
    if context.get("survey_url"):
        lines.append(f"Survey URL: {context['survey_url']}")
    if context.get("excel_path"):
        lines.append(f"Routing Excel file: {context['excel_path']}")
    if context.get("sheet_name"):
        lines.append(f"Sheet: {context['sheet_name']}")

    if context.get("question_count") is not None:
        lines.append(f"Questions parsed: {context['question_count']}  (start question: {context.get('start_qid')})")

    warnings = context.get("routing_warnings") or []
    if warnings:
        lines.append(f"Routing warnings ({len(warnings)}):")
        for w in warnings[:15]:
            lines.append(f"  - {w}")
        if len(warnings) > 15:
            lines.append(f"  ... and {len(warnings) - 15} more")

    unreachable = context.get("unreachable_questions") or []
    if unreachable:
        lines.append(f"Unreachable questions: {unreachable}")

    summary = context.get("last_run_summary")
    if summary:
        lines.append(
            f"Last run: total={summary.get('total')} passed={summary.get('passed')} "
            f"failed={summary.get('failed')} skipped={summary.get('skipped')}"
        )
        failed_rows = summary.get("failed_rows") or []
        if failed_rows:
            lines.append(f"Failed test rows ({len(failed_rows)}):")
            for r in failed_rows[:15]:
                lines.append(
                    f"  - Q{r.get('qid')} opt {r.get('option_no')} [{r.get('test_type')}]: "
                    f"expected={r.get('expected')!r} actual={r.get('actual')!r} notes={r.get('notes')!r}"
                )
            if len(failed_rows) > 15:
                lines.append(f"  ... and {len(failed_rows) - 15} more failed rows")

    log_tail = context.get("log_tail")
    if log_tail:
        lines.append("Recent Live Log output (most recent lines):")
        lines.append(_truncate(log_tail, 2500))

    text = "\n".join(lines)
    return _truncate(text, MAX_CONTEXT_CHARS)


# ======================================================================
# Qt GUI (PySide6)
# ======================================================================
CHAT_STYLE = """
QDialog { background: #f4f6fb; }
* { font-family: 'Segoe UI', 'Inter', 'Helvetica Neue', Arial, sans-serif; font-size: 13px; color: #1f2937; }
QLabel#title { font-size: 15px; font-weight: 700; color: #111827; }
QLabel#muted { color: #6b7280; font-size: 12px; }
QTextEdit {
    background: #ffffff; border: 1px solid #e5e7eb; border-radius: 10px;
    padding: 8px; selection-background-color: #c7d2fe;
}
QLineEdit {
    background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px;
    padding: 8px 10px; selection-background-color: #c7d2fe;
}
QLineEdit:focus { border: 1px solid #6366f1; background: #ffffff; }
QPushButton {
    background: #ffffff; border: 1px solid #d1d5db; border-radius: 8px;
    padding: 8px 14px; font-weight: 600; color: #374151;
}
QPushButton:hover { background: #f3f4f6; }
QPushButton:disabled { background: #f3f4f6; color: #9ca3af; border-color: #e5e7eb; }
QPushButton#primary { background: #4f46e5; border: 1px solid #4f46e5; color: #ffffff; }
QPushButton#primary:hover { background: #4338ca; }
QPushButton#primary:disabled { background: #c7d2fe; border-color: #c7d2fe; color: #ffffff; }
QPushButton#ghost { background: transparent; border: none; color: #6b7280; }
QPushButton#ghost:hover { color: #111827; background: #e5e7eb; }
QCheckBox { spacing: 8px; color: #374151; }
QScrollBar:vertical { background: transparent; width: 10px; margin: 2px; }
QScrollBar::handle:vertical { background: #cbd5e1; border-radius: 4px; min-height: 30px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
"""


def _plain_button(text, object_name=None):
    btn = QPushButton(text)
    if object_name:
        btn.setObjectName(object_name)
    btn.setAutoDefault(False)
    btn.setDefault(False)
    btn.setCursor(Qt.CursorShape.PointingHandCursor)
    return btn


# ======================================================================
# API key dialog
# ======================================================================
class ApiKeyDialog(QDialog):
    def __init__(self, parent, on_saved):
        super().__init__(parent)
        self.setWindowTitle("Set OpenAI API key")
        self.setStyleSheet(CHAT_STYLE)
        self.setModal(True)
        self.setMinimumWidth(440)
        self.on_saved = on_saved

        root = QVBoxLayout(self)
        root.setContentsMargins(22, 20, 22, 18)
        root.setSpacing(10)

        info = QLabel(
            "Paste your OpenAI API key. It's saved locally to ai_config.json next "
            "to this app (not sent anywhere except OpenAI when you ask a question)."
        )
        info.setWordWrap(True)
        root.addWidget(info)

        self.key_edit = QLineEdit()
        self.key_edit.setEchoMode(QLineEdit.EchoMode.Password)
        self.key_edit.setPlaceholderText("sk-\u2026")
        self.key_edit.returnPressed.connect(self._save)
        root.addWidget(self.key_edit)

        show_chk = QCheckBox("Show key")
        show_chk.toggled.connect(
            lambda on: self.key_edit.setEchoMode(
                QLineEdit.EchoMode.Normal if on else QLineEdit.EchoMode.Password
            )
        )
        root.addWidget(show_chk)

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel = _plain_button("Cancel")
        cancel.clicked.connect(self.reject)
        save = _plain_button("Save", "primary")
        save.clicked.connect(self._save)
        buttons.addWidget(cancel)
        buttons.addWidget(save)
        root.addSpacing(4)
        root.addLayout(buttons)

    def _save(self):
        key = self.key_edit.text().strip()
        if not key:
            QMessageBox.warning(self, "Missing key", "Please paste a key first.")
            return
        try:
            save_api_key(key)
        except Exception as e:
            QMessageBox.critical(self, "Could not save key", str(e))
            return
        self.on_saved(key)
        self.accept()


# ======================================================================
# Chat window
# ======================================================================
class ChatWindow(QDialog):
    """Popup chat window. Created once, then just shown/hidden (closing it
    only hides it, so history/state stay alive)."""

    # status ("ok" / "err"), question, payload -- emitted from the worker
    # thread; Qt delivers it on the GUI thread.
    reply_ready = Signal(str, str, str)

    def __init__(self, parent, context_provider, model=DEFAULT_MODEL):
        super().__init__(parent)
        self.setWindowTitle("Ask AI \u2014 Survey Tester Assistant")
        self.setStyleSheet(CHAT_STYLE)
        self.setModal(False)
        self.resize(420, 560)
        self.setMinimumSize(340, 420)
        self.context_provider = context_provider
        self.model = model
        self.history = [{"role": "system", "content": SYSTEM_PROMPT}]
        self.reply_ready.connect(self._on_reply)
        self._build_ui()

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(14, 12, 14, 12)
        root.setSpacing(10)

        header = QHBoxLayout()
        title = QLabel("AI Assistant")
        title.setObjectName("title")
        key_btn = _plain_button("Set API key")
        key_btn.clicked.connect(self._open_key_dialog)
        clear_btn = _plain_button("Clear chat", "ghost")
        clear_btn.clicked.connect(self._clear_chat)
        header.addWidget(title)
        header.addStretch(1)
        header.addWidget(clear_btn)
        header.addWidget(key_btn)
        root.addLayout(header)

        self.chat_box = QTextEdit()
        self.chat_box.setReadOnly(True)
        root.addWidget(self.chat_box, 1)
        self._append_system_line(
            "Hi! I can see your current survey link, routing sheet, and the "
            "latest test run / log output. Ask me things like \u201cwhy did "
            "Q5 fail?\u201d or \u201cwhat does this error mean?\u201d"
        )

        row = QHBoxLayout()
        row.setSpacing(8)
        self.input_edit = QLineEdit()
        self.input_edit.setPlaceholderText("Ask about your survey, a failed test, or an error\u2026")
        self.input_edit.returnPressed.connect(self._send)
        self.send_btn = _plain_button("Send", "primary")
        self.send_btn.clicked.connect(self._send)
        row.addWidget(self.input_edit, 1)
        row.addWidget(self.send_btn)
        root.addLayout(row)

        self.status_label = QLabel("")
        self.status_label.setObjectName("muted")
        root.addWidget(self.status_label)

    # ---- helpers ----
    def _open_key_dialog(self):
        ApiKeyDialog(self, on_saved=lambda _k: self.status_label.setText("API key saved.")).exec()

    def _write(self, text, color=TEXT, bold=False):
        cursor = self.chat_box.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)
        fmt = QTextCharFormat()
        fmt.setForeground(QColor(color))
        fmt.setFontWeight(QFont.Weight.Bold if bold else QFont.Weight.Normal)
        cursor.insertText(text, fmt)
        self.chat_box.setTextCursor(cursor)
        self.chat_box.ensureCursorVisible()

    def _append_system_line(self, text):
        self._write(text + "\n\n", MUTED)

    def _append_message(self, role_label, color, text):
        self._write(f"{role_label}: ", color, bold=True)
        self._write(text + "\n\n", TEXT)

    def _clear_chat(self):
        self.history = [{"role": "system", "content": SYSTEM_PROMPT}]
        self.chat_box.clear()
        self._append_system_line("Chat cleared.")

    # ---- sending ----
    def _send(self):
        question = self.input_edit.text().strip()
        if not question or not self.send_btn.isEnabled():
            return

        api_key = load_api_key()
        if not api_key:
            QMessageBox.warning(
                self, "No API key set",
                "No OpenAI API key found. Click 'Set API key' first, or set "
                "the OPENAI_API_KEY environment variable and restart the app.",
            )
            self._open_key_dialog()
            return

        self.input_edit.clear()
        self._append_message("You", PRIMARY, question)
        self.send_btn.setEnabled(False)
        self.status_label.setText("Thinking\u2026")

        # Fresh context snapshot on every question so answers stay current
        # with whatever just happened in the tool.
        try:
            context = self.context_provider() if self.context_provider else {}
        except Exception:
            context = {}
        context_block = build_context_block(context)

        turn_messages = list(self.history) + [{
            "role": "user",
            "content": f"CONTEXT SNAPSHOT:\n{context_block}\n\nUSER QUESTION:\n{question}",
        }]

        def worker():
            try:
                reply = ask_openai(turn_messages, api_key, model=self.model)
                self.reply_ready.emit("ok", question, reply)
            except OpenAIError as e:
                self.reply_ready.emit("err", question, str(e))
            except Exception as e:
                self.reply_ready.emit("err", question, f"Unexpected error: {e}")

        threading.Thread(target=worker, daemon=True).start()

    def _on_reply(self, status, question, payload):
        self.send_btn.setEnabled(True)
        self.status_label.setText("")
        if status == "ok":
            self.history.append({"role": "user", "content": question})
            self.history.append({"role": "assistant", "content": payload})
            self._append_message("Assistant", SUCCESS, payload)
        else:
            self._append_message("Error", DANGER, payload)
        self.input_edit.setFocus()


# ======================================================================
# Floating chat bubble
# ======================================================================
class ChatBubble(QPushButton):
    """Round floating button pinned to the bottom-right corner of a window,
    so it stays visible whichever tab/panel is showing underneath."""

    SIZE = 56

    def __init__(self, parent, context_provider, model=DEFAULT_MODEL, margin=(32, 24)):
        super().__init__("\U0001F4AC", parent)
        self._margin = margin
        self.setFixedSize(self.SIZE, self.SIZE)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setToolTip("Ask AI")
        self.setStyleSheet(
            f"QPushButton {{ background: {BUBBLE_BG}; border: none; border-radius: {self.SIZE // 2}px;"
            " font-size: 22px; color: #ffffff; padding: 0; }"
            f"QPushButton:hover {{ background: {BUBBLE_BG_HOVER}; }}"
        )
        shadow = QGraphicsDropShadowEffect(self)
        shadow.setBlurRadius(18)
        shadow.setOffset(0, 4)
        shadow.setColor(QColor(17, 24, 39, 90))
        self.setGraphicsEffect(shadow)

        self.chat_window = ChatWindow(parent.window(), context_provider, model=model)
        self.clicked.connect(self._toggle)

        parent.installEventFilter(self)
        self._reposition()
        self.show()
        self.raise_()

    def eventFilter(self, obj, event):
        if obj is self.parent() and event.type() in (QEvent.Type.Resize, QEvent.Type.Show):
            self._reposition()
        return super().eventFilter(obj, event)

    def _reposition(self):
        parent = self.parentWidget()
        if parent is None:
            return
        status_h = 0
        status_bar = getattr(parent, "statusBar", None)
        if callable(status_bar):
            try:
                status_h = status_bar().height()
            except Exception:
                status_h = 0
        x = parent.width() - self.SIZE - self._margin[0]
        y = parent.height() - status_h - self.SIZE - self._margin[1]
        self.move(max(x, 0), max(y, 0))
        self.raise_()

    def _toggle(self):
        if self.chat_window.isVisible():
            self.chat_window.hide()
            return
        self._position_near_bubble()
        self.chat_window.show()
        self.chat_window.raise_()
        self.chat_window.activateWindow()
        self.chat_window.input_edit.setFocus()

    def _position_near_bubble(self):
        # Pop the window up just above/left of the bubble, fully on screen.
        origin = self.mapToGlobal(QPoint(0, 0))
        w, h = self.chat_window.width(), self.chat_window.height()
        x = max(origin.x() - w + self.SIZE, 20)
        y = max(origin.y() - h - 10, 20)
        screen = self.screen()
        if screen is not None:
            area = screen.availableGeometry()
            x = min(x, area.right() - w - 10)
            y = min(y, area.bottom() - h - 10)
        self.chat_window.move(max(x, 0), max(y, 0))


def attach_chat_bubble(window, context_provider, model=DEFAULT_MODEL, margin=(32, 24)):
    """
    Create the floating bubble and pin it to the bottom-right of `window`
    (a QMainWindow / QWidget). Call once, after the rest of the UI is built:

        attach_chat_bubble(self, self.get_ai_context)

    context_provider: a zero-arg callable returning a dict (see
    build_context_block() for the keys it understands). It is called fresh
    every time the user asks a question, so just read whatever state the
    host app already tracks -- no need to cache it.
    """
    return ChatBubble(window, context_provider, model=model, margin=margin)