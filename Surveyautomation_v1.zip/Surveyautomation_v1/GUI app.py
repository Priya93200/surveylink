import os
import sys
import time
import datetime
import threading

from PySide6.QtCore import Qt, QObject, QPointF, QRectF, QTimer, QUrl, Signal
from PySide6.QtGui import (
    QAction, QColor, QDesktopServices, QFont, QPainter, QPen,
    QTextCharFormat, QTextCursor,
)
from PySide6.QtWidgets import (
    QAbstractItemView, QApplication, QCheckBox, QCompleter, QDialog, QFileDialog, QFrame,
    QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMainWindow, QMessageBox,
    QProgressBar, QPushButton, QScrollArea, QSpinBox, QTabWidget, QTableWidget,
    QTableWidgetItem, QTextEdit, QTreeWidget, QTreeWidgetItem, QVBoxLayout,
    QWidget, QGridLayout,
)

from survey_model import (
    load_survey, validate_routing, build_baseline_paths, unreachable_questions,
    save_edits, SurveyParseError,
)
from playwright_runner import run_tests, _build_jobs
from report_writer import write_report

# The floating "Ask AI" bubble lives in ai_assistant.py. If that module is
# still written for Tkinter it can't attach to a Qt window, so we guard it
# (see the note at the bottom of _build_ui).
try:
    from ai_assistant import attach_chat_bubble
except Exception:  # pragma: no cover
    attach_chat_bubble = None


# ======================================================================
# Palette
# ======================================================================
PRIMARY = "#4f46e5"
SUCCESS = "#059669"
DANGER = "#dc2626"
WARN = "#b45309"
TEXT = "#1f2937"
MUTED = "#6b7280"

STYLE = """
* { font-family: 'Segoe UI', 'Inter', 'Helvetica Neue', Arial, sans-serif; font-size: 13px; color: #1f2937; }
QMainWindow, QScrollArea, QWidget#page, QDialog { background: #f4f6fb; }
QScrollArea { border: none; }

QMenuBar { background: #f4f6fb; }
QMenuBar::item { padding: 6px 12px; background: transparent; border-radius: 6px; }
QMenuBar::item:selected { background: #e0e7ff; }
QMenu { background: #ffffff; border: 1px solid #e5e7eb; padding: 6px; }
QMenu::item { padding: 7px 22px; border-radius: 6px; }
QMenu::item:selected { background: #eef2ff; color: #4f46e5; }
QMenu::separator { height: 1px; background: #e5e7eb; margin: 6px 8px; }

QToolTip { background: #111827; color: #ffffff; border: none; padding: 6px 8px; }

QLabel#title { font-size: 26px; font-weight: 700; color: #111827; }
QLabel#subtitle { color: #6b7280; font-size: 13px; }

QFrame#card { background: #ffffff; border: 1px solid #e5e7eb; border-radius: 14px; }
QLabel#cardTitle { font-size: 15px; font-weight: 600; color: #111827; }
QLabel#cardHint { color: #6b7280; font-size: 12px; }
QLabel#badge {
    background: #eef2ff; color: #4f46e5; border-radius: 12px;
    min-width: 24px; max-width: 24px; min-height: 24px; max-height: 24px;
    font-weight: 700; qproperty-alignment: AlignCenter;
}
QLabel#fieldLabel { color: #374151; font-weight: 600; }
QLabel#muted { color: #6b7280; font-size: 12px; }
QLabel#elapsed { color: #6b7280; font-weight: 600; }
QLabel#pct { color: #4f46e5; font-weight: 700; }
QLabel#chip { background: #f3f4f6; color: #374151; border-radius: 10px; padding: 3px 12px; font-size: 12px; font-weight: 600; }
QLabel#chipPass { background: #ecfdf5; color: #047857; border-radius: 10px; padding: 3px 12px; font-size: 12px; font-weight: 600; }
QLabel#chipFail { background: #fef2f2; color: #b91c1c; border-radius: 10px; padding: 3px 12px; font-size: 12px; font-weight: 600; }

QLineEdit {
    background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px;
    padding: 8px 10px; selection-background-color: #c7d2fe;
}
QLineEdit:focus { border: 1px solid #6366f1; background: #ffffff; }
QLineEdit:read-only { color: #4b5563; }
QLineEdit:disabled { background: #f3f4f6; color: #9ca3af; }

QSpinBox {
    background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 8px;
    padding: 7px 10px; min-width: 56px; selection-background-color: #c7d2fe;
}
QSpinBox:focus { border: 1px solid #6366f1; background: #ffffff; }
QSpinBox::up-button, QSpinBox::down-button { width: 0; border: none; }

QCheckBox { spacing: 8px; font-weight: 600; color: #374151; }

QTextEdit {
    background: #f9fafb; border: 1px solid #e5e7eb; border-radius: 10px;
    padding: 8px; selection-background-color: #c7d2fe;
}
QTextEdit#log { background: #ffffff; font-family: Consolas, 'Cascadia Mono', 'Courier New', monospace; font-size: 12px; }

QPushButton {
    background: #ffffff; border: 1px solid #d1d5db; border-radius: 8px;
    padding: 8px 16px; font-weight: 600; color: #374151;
}
QPushButton:hover { background: #f3f4f6; }
QPushButton:disabled { background: #f3f4f6; color: #9ca3af; border-color: #e5e7eb; }
QPushButton#primary { background: #4f46e5; border: 1px solid #4f46e5; color: #ffffff; padding: 10px 26px; font-size: 14px; }
QPushButton#primary:hover { background: #4338ca; }
QPushButton#primary:disabled { background: #c7d2fe; border-color: #c7d2fe; color: #ffffff; }
QPushButton#success { background: #059669; border: 1px solid #059669; color: #ffffff; padding: 10px 26px; font-size: 14px; }
QPushButton#success:hover { background: #047857; }
QPushButton#success:disabled { background: #a7f3d0; border-color: #a7f3d0; color: #ffffff; }
QPushButton#secondary { padding: 10px 22px; font-size: 14px; border: 1px solid #6366f1; color: #4f46e5; }
QPushButton#secondary:hover { background: #eef2ff; }
QPushButton#secondary:disabled { border-color: #e5e7eb; color: #9ca3af; background: #f3f4f6; }
QPushButton#ghost { background: transparent; border: none; color: #6b7280; padding: 8px 12px; }
QPushButton#ghost:hover { color: #111827; background: #f3f4f6; }

QProgressBar { background: #e5e7eb; border: none; border-radius: 5px; min-height: 10px; max-height: 10px; text-align: center; color: transparent; }
QProgressBar::chunk { background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #6366f1, stop:1 #8b5cf6); border-radius: 5px; }

QTabWidget::pane { border: none; border-top: 1px solid #e5e7eb; top: -1px; }
QTabBar::tab { background: transparent; color: #6b7280; padding: 10px 18px; margin-right: 4px; font-weight: 600; border: none; border-bottom: 2px solid transparent; }
QTabBar::tab:selected { color: #4f46e5; border-bottom: 2px solid #4f46e5; }
QTabBar::tab:hover:!selected { color: #111827; }

QTreeWidget, QTableWidget {
    background: #ffffff; alternate-background-color: #f9fafb; border: 1px solid #e5e7eb;
    border-radius: 10px; gridline-color: #f0f1f4;
    selection-background-color: #e0e7ff; selection-color: #111827;
}
QTreeWidget::item { padding: 4px 2px; }
QTreeWidget::item:selected { background: #e0e7ff; }
QHeaderView::section { background: #f3f4f6; border: none; border-bottom: 1px solid #e5e7eb; padding: 8px; font-weight: 600; color: #374151; }

QScrollBar:vertical { background: transparent; width: 10px; margin: 2px; }
QScrollBar::handle:vertical { background: #cbd5e1; border-radius: 4px; min-height: 30px; }
QScrollBar::handle:vertical:hover { background: #94a3b8; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal { background: transparent; height: 10px; margin: 2px; }
QScrollBar::handle:horizontal { background: #cbd5e1; border-radius: 4px; min-width: 30px; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }

QStatusBar { background: #f4f6fb; }
QMessageBox QPushButton { min-width: 80px; }
"""


# ======================================================================
# Small helpers
# ======================================================================
def make_card():
    card = QFrame()
    card.setObjectName("card")
    layout = QVBoxLayout(card)
    layout.setContentsMargins(24, 20, 24, 22)
    layout.setSpacing(12)
    return card, layout


def card_header(number, title, hint=""):
    row = QHBoxLayout()
    row.setSpacing(10)
    badge = QLabel(str(number))
    badge.setObjectName("badge")
    badge.setAlignment(Qt.AlignmentFlag.AlignCenter)
    text = QVBoxLayout()
    text.setSpacing(1)
    t = QLabel(title)
    t.setObjectName("cardTitle")
    text.addWidget(t)
    if hint:
        h = QLabel(hint)
        h.setObjectName("cardHint")
        text.addWidget(h)
    row.addWidget(badge, 0, Qt.AlignmentFlag.AlignTop)
    row.addLayout(text, 1)
    return row


def append_colored(edit, text, color=None, bold=False):
    """Append text to a QTextEdit with an optional colour / bold weight."""
    cursor = edit.textCursor()
    cursor.movePosition(QTextCursor.MoveOperation.End)
    fmt = QTextCharFormat()
    if color:
        fmt.setForeground(QColor(color))
    if bold:
        fmt.setFontWeight(QFont.Weight.Bold)
    cursor.insertText(text, fmt)
    edit.setTextCursor(cursor)
    edit.ensureCursorVisible()


def pointing(btn):
    btn.setCursor(Qt.CursorShape.PointingHandCursor)
    return btn


# ======================================================================
# Worker bridge: signals the background test thread uses to talk to the GUI
# ======================================================================
class RunSignals(QObject):
    log = Signal(str)
    result = Signal(object)
    manual_help = Signal(str, object)
    done = Signal(object)
    failed = Signal(str)
    finished = Signal()


# ======================================================================
# Option editor dialog
# ======================================================================
class OptionEditDialog(QDialog):
    def __init__(self, qid, opt, order, parent=None):
        super().__init__(parent)
        self.setWindowTitle(f"Edit option \u2014 [{qid}] option {opt['option_no']}")
        self.setModal(True)
        self.setMinimumWidth(480)
        self._known = list(order)

        root = QVBoxLayout(self)
        root.setContentsMargins(24, 20, 24, 20)
        root.setSpacing(10)

        title = QLabel(f"Question [{qid}]  \u2022  Option {opt['option_no']}")
        title.setObjectName("cardTitle")
        hint = QLabel("Changes are written straight to the routing Excel (a backup is saved first).")
        hint.setObjectName("cardHint")
        root.addWidget(title)
        root.addWidget(hint)
        root.addSpacing(6)

        lbl = QLabel("Option text")
        lbl.setObjectName("fieldLabel")
        self.text_edit = QLineEdit(str(opt["option_text"]))
        root.addWidget(lbl)
        root.addWidget(self.text_edit)

        self.term_chk = QCheckBox("Terminates the survey")
        self.term_chk.setChecked(bool(opt["termination"]))
        root.addSpacing(4)
        root.addWidget(self.term_chk)

        lbl2 = QLabel("Routes to (Q_No)")
        lbl2.setObjectName("fieldLabel")
        self.route_edit = QLineEdit(opt["routing"] or "")
        self.route_edit.setPlaceholderText("Type a Q_No\u2026")
        choices = [q for q in order if q != qid]
        completer = QCompleter(choices, self)
        completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
        completer.setFilterMode(Qt.MatchFlag.MatchContains)
        self.route_edit.setCompleter(completer)
        root.addWidget(lbl2)
        root.addWidget(self.route_edit)
        route_hint = QLabel("Suggestions come from the questions defined in the sheet. "
                            "You can still type a Q_No that doesn't exist yet.")
        route_hint.setObjectName("muted")
        route_hint.setWordWrap(True)
        root.addWidget(route_hint)

        self.term_chk.toggled.connect(lambda on: self.route_edit.setEnabled(not on))
        self.route_edit.setEnabled(not self.term_chk.isChecked())

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        cancel = pointing(QPushButton("Cancel"))
        cancel.clicked.connect(self.reject)
        save = pointing(QPushButton("Save to Excel"))
        save.setObjectName("primary")
        save.setDefault(True)
        save.clicked.connect(self.accept)
        buttons.addWidget(cancel)
        buttons.addWidget(save)
        root.addSpacing(8)
        root.addLayout(buttons)

    def accept(self):
        routing = self.route_edit.text().strip()
        if not self.term_chk.isChecked() and routing and routing not in self._known:
            answer = QMessageBox.question(
                self, "Unknown Q_No",
                f"'{routing}' isn't one of the questions currently in this sheet.\n"
                "Save anyway? (useful if that question is being added later)",
            )
            if answer != QMessageBox.StandardButton.Yes:
                return
        super().accept()

    def values(self):
        terminate = self.term_chk.isChecked()
        routing = "" if terminate else self.route_edit.text().strip()
        return self.text_edit.text().strip(), terminate, routing


# ======================================================================
# Trend analysis (donut chart)
# ======================================================================
class DonutChart(QWidget):
    def __init__(self, passed, failed, parent=None):
        super().__init__(parent)
        self.passed = passed
        self.failed = failed
        self.setFixedSize(240, 240)

    def paintEvent(self, _event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        total = self.passed + self.failed
        side = min(self.width(), self.height()) - 20
        rect = QRectF((self.width() - side) / 2, (self.height() - side) / 2, side, side)

        p.setPen(Qt.PenStyle.NoPen)
        if total == 0:
            p.setBrush(QColor("#e5e7eb"))
            p.drawEllipse(rect)
        elif self.failed == 0:
            p.setBrush(QColor(SUCCESS))
            p.drawEllipse(rect)
        elif self.passed == 0:
            p.setBrush(QColor(DANGER))
            p.drawEllipse(rect)
        else:
            pass_span = 360 * 16 * self.passed / total
            p.setPen(QPen(QColor("#ffffff"), 2))
            # Start at 12 o'clock and sweep clockwise (negative span).
            p.setBrush(QColor(SUCCESS))
            p.drawPie(rect, 90 * 16, int(-pass_span))
            p.setBrush(QColor(DANGER))
            p.drawPie(rect, int(90 * 16 - pass_span), int(-(360 * 16 - pass_span)))

        # Donut hole + centre label
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor("#ffffff"))
        radius = side * 0.30
        p.drawEllipse(rect.center(), radius, radius)

        pct = (self.passed / total * 100) if total else 0
        p.setPen(QColor("#111827"))
        big = QFont(self.font())
        big.setPointSize(20)
        big.setBold(True)
        p.setFont(big)
        p.drawText(QRectF(rect.left(), rect.center().y() - 26, rect.width(), 32),
                   Qt.AlignmentFlag.AlignCenter, f"{pct:.0f}%")
        small = QFont(self.font())
        small.setPointSize(9)
        p.setFont(small)
        p.setPen(QColor(MUTED))
        p.drawText(QRectF(rect.left(), rect.center().y() + 6, rect.width(), 20),
                   Qt.AlignmentFlag.AlignCenter, "passed")
        p.end()


# ======================================================================
# Report preview (full-screen window opened by the "Report preview" button)
# ======================================================================
class ReportPreviewWindow(QDialog):
    COLS = ["Q_No", "Option", "Test type", "Expected", "Actual", "Result", "Notes", "Screenshot"]

    def __init__(self, results, open_screenshot, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Report preview")
        self.setModal(True)
        self.resize(1200, 780)
        self._results = list(results)
        self._open_screenshot = open_screenshot

        total = len(self._results)
        passed = sum(1 for r in self._results if r.passed)
        failed = total - passed

        root = QVBoxLayout(self)
        root.setContentsMargins(36, 28, 36, 24)
        root.setSpacing(14)

        title = QLabel("Report preview")
        title.setObjectName("title")
        sub = QLabel("Full results of the last run. Double-click a row for details.")
        sub.setObjectName("subtitle")
        root.addWidget(title)
        root.addWidget(sub)

        bar = QHBoxLayout()
        bar.setSpacing(8)
        for text, name in ((f"Total: {total}", "chip"), (f"Passed: {passed}", "chipPass"),
                           (f"Failed: {failed}", "chipFail")):
            lbl = QLabel(text)
            lbl.setObjectName(name)
            bar.addWidget(lbl)
        bar.addStretch(1)
        self.failed_only = QCheckBox("Show failed only")
        self.failed_only.toggled.connect(self._apply_filter)
        bar.addWidget(self.failed_only)
        root.addLayout(bar)

        self.table = QTableWidget(0, len(self.COLS))
        self.table.setHorizontalHeaderLabels(self.COLS)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.setWordWrap(True)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        h = self.table.horizontalHeader()
        h.setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        h.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        for i, w in enumerate((80, 220, 170, 0, 0, 90, 0, 110)):
            if w:
                self.table.setColumnWidth(i, w)
        for i in (3, 4, 6):
            h.setSectionResizeMode(i, QHeaderView.ResizeMode.Stretch)
        self.table.cellDoubleClicked.connect(self._on_double_click)
        root.addWidget(self.table, 1)
        self._populate()

        buttons = QHBoxLayout()
        buttons.addStretch(1)
        close = pointing(QPushButton("Close"))
        close.setObjectName("primary")
        close.clicked.connect(self.accept)
        buttons.addWidget(close)
        root.addLayout(buttons)

    def _populate(self):
        for r in self._results:
            shot = getattr(r, "screenshot_path", "") or ""
            values = (
                getattr(r, "qid", ""), getattr(r, "option_text", ""), getattr(r, "test_type", ""),
                getattr(r, "expected", ""), getattr(r, "actual", ""),
                "PASS" if r.passed else "FAIL", getattr(r, "notes", "") or "",
                "View" if shot else "",
            )
            row = self.table.rowCount()
            self.table.insertRow(row)
            for col, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                if col in (5, 7):
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                if col == 5:
                    item.setForeground(QColor(SUCCESS if r.passed else DANGER))
                    f = QFont(item.font())
                    f.setBold(True)
                    item.setFont(f)
                if col == 7 and shot:
                    item.setForeground(QColor(PRIMARY))
                self.table.setItem(row, col, item)

    def showEvent(self, event):
        super().showEvent(event)
        # Row heights depend on the final column widths, so measure after layout.
        QTimer.singleShot(0, self.table.resizeRowsToContents)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        QTimer.singleShot(0, self.table.resizeRowsToContents)

    def _apply_filter(self, only_failed):
        for i, r in enumerate(self._results):
            self.table.setRowHidden(i, bool(only_failed and r.passed))

    def _on_double_click(self, row, column):
        if not 0 <= row < len(self._results):
            return
        r = self._results[row]
        shot = getattr(r, "screenshot_path", "") or ""
        if column == 7 and shot:
            self._open_screenshot(shot)
            return
        notes = getattr(r, "notes", "")
        QMessageBox.information(
            self, "Test detail",
            f"Expected: {r.expected}\n\nActual: {r.actual}"
            + (f"\n\nNotes: {notes}" if notes else "")
            + (f"\n\nScreenshot: {shot}" if shot else ""),
        )


# ======================================================================
# Main window
# ======================================================================
class SurveyTesterApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Survey Link Flow Tester")
        self.resize(1120, 900)
        self.setMinimumSize(920, 680)
        self.setStyleSheet(STYLE)

        self.summary = None
        self._expected_test_count = 1
        self._run_start_time = None
        self._run_thread = None
        self._signals = None

        # Populated by preview_structure() -- the edit dialog needs these.
        self._questions = {}
        self._order = []
        self._start_qid = None
        self._sheet_name = None

        self._wt_total = 0
        self._wt_passed = 0
        self._wt_failed = 0
        self._results = []   # result objects of the current run (feeds the full-screen report preview)

        self._timer = QTimer(self)
        self._timer.setInterval(1000)
        self._timer.timeout.connect(self._tick_timer)

        self._build_menu()
        self._build_ui()

    # ------------------------------------------------------------------
    # Menu bar
    # ------------------------------------------------------------------
    def _build_menu(self):
        bar = self.menuBar()

        file_menu = bar.addMenu("File")
        a_link = QAction("Open Survey Link (.txt)\u2026", self)
        a_link.triggered.connect(self.pick_url_file)
        a_xlsx = QAction("Open Routing Excel (.xlsx)\u2026", self)
        a_xlsx.triggered.connect(self.pick_excel_file)
        a_exit = QAction("Exit", self)
        a_exit.triggered.connect(self.close)
        file_menu.addAction(a_link)
        file_menu.addAction(a_xlsx)
        file_menu.addSeparator()
        file_menu.addAction(a_exit)

        help_menu = bar.addMenu("Help")
        a_about = QAction("About", self)
        a_about.triggered.connect(self._show_about)
        help_menu.addAction(a_about)

    def _show_about(self):
        QMessageBox.information(
            self, "About",
            "Survey Link Flow Tester\n\n"
            "Validates survey routing logic against an Excel-defined flow map, "
            "then drives an automated Playwright test session and produces a "
            "colour-coded report.",
        )

    # ------------------------------------------------------------------
    # UI construction
    # ------------------------------------------------------------------
    def _build_ui(self):
        self.scroll = scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        self.setCentralWidget(scroll)
        page = QWidget()
        page.setObjectName("page")
        scroll.setWidget(page)
        outer = QVBoxLayout(page)
        outer.setContentsMargins(40, 28, 40, 24)
        outer.setSpacing(18)

        # ---- Header
        title = QLabel("Survey Link Flow Tester")
        title.setObjectName("title")
        subtitle = QLabel("Validate routing  \u2022  Automated pass-throughs  \u2022  Colour-coded report export")
        subtitle.setObjectName("subtitle")
        outer.addWidget(title)
        outer.addWidget(subtitle)

        # ---- Card 1: survey setup
        setup_card, setup = make_card()
        setup.addLayout(card_header(1, "Survey setup", "Point the tester at the survey link and its routing Excel."))

        grid = QGridLayout()
        grid.setHorizontalSpacing(10)
        grid.setVerticalSpacing(10)
        grid.setColumnStretch(1, 1)

        l1 = QLabel("Survey link")
        l1.setObjectName("fieldLabel")
        self.url_edit = QLineEdit()
        self.url_edit.setPlaceholderText("https://\u2026  (or load it from a .txt file)")
        load_btn = pointing(QPushButton("Load from .txt\u2026"))
        load_btn.setToolTip("Load the survey URL from a plain text file")
        load_btn.clicked.connect(self.pick_url_file)
        grid.addWidget(l1, 0, 0)
        grid.addWidget(self.url_edit, 0, 1)
        grid.addWidget(load_btn, 0, 2)

        l2 = QLabel("Routing Excel")
        l2.setObjectName("fieldLabel")
        self.excel_edit = QLineEdit()
        self.excel_edit.setReadOnly(True)
        self.excel_edit.setPlaceholderText("Select the .xlsx defining questions, options and routing\u2026")
        browse_btn = pointing(QPushButton("Browse\u2026"))
        browse_btn.setToolTip("Choose the .xlsx file defining questions, options, and routing")
        browse_btn.clicked.connect(self.pick_excel_file)
        grid.addWidget(l2, 1, 0)
        grid.addWidget(self.excel_edit, 1, 1)
        grid.addWidget(browse_btn, 1, 2)
        setup.addLayout(grid)

        opts = QHBoxLayout()
        opts.setSpacing(10)
        self.headless_chk = QCheckBox("Run headless")
        self.headless_chk.setChecked(True)
        self.headless_chk.setToolTip("Uncheck to watch the browser while tests run")
        self.slowmo_spin = QSpinBox()
        self.slowmo_spin.setRange(0, 2000)
        self.slowmo_spin.setSingleStep(50)
        self.slowmo_spin.setToolTip("Delay between browser actions in ms (type a value or use the mouse wheel)")
        self.workers_spin = QSpinBox()
        self.workers_spin.setRange(1, 8)
        self.workers_spin.setValue(1)
        self.workers_spin.setToolTip("Number of browser windows to run in parallel (type a value or use the mouse wheel)")
        sm = QLabel("Slow-mo (ms)")
        sm.setObjectName("fieldLabel")
        pw = QLabel("Parallel windows")
        pw.setObjectName("fieldLabel")
        opts.addWidget(self.headless_chk)
        opts.addSpacing(18)
        opts.addWidget(sm)
        opts.addWidget(self.slowmo_spin)
        opts.addSpacing(18)
        opts.addWidget(pw)
        opts.addWidget(self.workers_spin)
        opts.addStretch(1)
        setup.addLayout(opts)
        outer.addWidget(setup_card)

        # ---- Card 2: survey structure + Run test (appears automatically once an Excel is loaded)
        self.structure_card, run = make_card()
        head = card_header(2, "Survey structure",
                           "Review the questions and routing. Double-click an option to fix it, then run the test.")
        self.reload_btn = pointing(QPushButton("\u21BB  Reload"))
        self.reload_btn.setObjectName("ghost")
        self.reload_btn.setToolTip("Re-read the routing Excel (e.g. after editing it outside the app)")
        self.reload_btn.clicked.connect(self.preview_structure)
        head.addWidget(self.reload_btn, 0, Qt.AlignmentFlag.AlignTop)
        run.addLayout(head)

        # Structure tree + routing warnings.
        self.structure_box = self._build_structure_box()
        run.addWidget(self.structure_box)

        # "Run test" sits right below the structure box.
        self.run_row = QWidget()
        rr = QHBoxLayout(self.run_row)
        rr.setContentsMargins(0, 4, 0, 0)
        self.run_btn = pointing(QPushButton("Run test"))
        self.run_btn.setObjectName("primary")
        self.run_btn.clicked.connect(self.start_run)
        rr.addWidget(self.run_btn)
        rr.addStretch(1)
        run.addWidget(self.run_row)

        # Progress + timer -- shown while a run is active / finished.
        self.progress_box = QWidget()
        prog = QHBoxLayout(self.progress_box)
        prog.setContentsMargins(0, 0, 0, 0)
        prog.setSpacing(12)
        self.progress = QProgressBar()
        self.progress.setRange(0, 1)
        self.progress.setValue(0)
        self.progress.setTextVisible(False)
        self.pct_label = QLabel("")
        self.pct_label.setObjectName("pct")
        self.pct_label.setMinimumWidth(40)
        self.pct_label.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
        self.timer_label = QLabel("")
        self.timer_label.setObjectName("elapsed")
        prog.addWidget(self.progress, 1)
        prog.addWidget(self.pct_label)
        prog.addWidget(self.timer_label)
        self.progress_box.setVisible(False)
        run.addWidget(self.progress_box)
        self.structure_card.setVisible(False)
        outer.addWidget(self.structure_card)

        # ---- Card 3: results (appears once "Run test" is clicked)
        self.res_card, res = make_card()
        res.addLayout(card_header(3, "Results", "Live log and the pass/fail table for this run."))
        self.tabs = QTabWidget()
        self.tabs.setMinimumHeight(340)
        self.clear_btn = pointing(QPushButton("Clear log"))
        self.clear_btn.setObjectName("ghost")
        self.clear_btn.clicked.connect(self._clear_log)
        self.tabs.setCornerWidget(self.clear_btn, Qt.Corner.TopRightCorner)
        res.addWidget(self.tabs, 1)

        self._build_log_tab()       # tab 0
        self._build_results_tab()   # tab 1

        # Buttons that appear at the bottom of the results box when the run finishes.
        self.done_row = QWidget()
        dr = QHBoxLayout(self.done_row)
        dr.setContentsMargins(0, 6, 0, 0)
        dr.setSpacing(10)
        self.report_btn = pointing(QPushButton("Report preview"))
        self.report_btn.setObjectName("secondary")
        self.report_btn.setToolTip("Open the full report in a full-screen window")
        self.report_btn.clicked.connect(self._show_report_preview)
        self.export_btn = pointing(QPushButton("Save report (.xlsx)"))
        self.export_btn.setObjectName("success")
        self.export_btn.clicked.connect(self.save_report)
        self.trend_btn = pointing(QPushButton("\U0001F4CA  Chart analysis"))
        self.trend_btn.setObjectName("secondary")
        self.trend_btn.setToolTip("Pass/Fail percentage for the run that just finished")
        self.trend_btn.clicked.connect(self.show_trend_analysis)
        dr.addWidget(self.report_btn)
        dr.addWidget(self.export_btn)
        dr.addWidget(self.trend_btn)
        dr.addStretch(1)
        self.done_row.setVisible(False)
        res.addWidget(self.done_row)

        self.res_card.setVisible(False)
        outer.addWidget(self.res_card)
        outer.addStretch(1)  # keep the cards packed at the top (no gaps under the title)

        # ---- Status bar
        self.status_dot = QLabel()
        self.status_dot.setFixedSize(10, 10)
        self.status_text = QLabel("Ready.")
        self.statusBar().addWidget(self.status_dot)
        self.statusBar().addWidget(self.status_text)
        self.set_status("Ready.", MUTED)

        # ---- Floating "Ask AI" bubble
        # NOTE: ai_assistant.attach_chat_bubble was written for Tkinter. If it
        # is still Tk-based it cannot attach to this Qt window and will be
        # skipped here until it is ported to PySide6.
        if attach_chat_bubble is not None:
            try:
                attach_chat_bubble(self, self.get_ai_context)
            except Exception as e:
                print(f"[GUI_app] Chat bubble not attached ({type(e).__name__}: {e}). "
                      "ai_assistant.py needs a PySide6 version.")

    def _build_structure_box(self):
        box = QWidget()
        lay = QVBoxLayout(box)
        lay.setContentsMargins(0, 4, 0, 0)
        lay.setSpacing(10)

        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Question / Option", "Type", "Routing"])
        self.tree.setAlternatingRowColors(True)
        self.tree.setUniformRowHeights(True)
        self.tree.setIndentation(18)
        self.tree.setMinimumHeight(260)
        hdr = self.tree.header()
        hdr.setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        hdr.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        hdr.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        self.tree.itemDoubleClicked.connect(self._on_tree_double_click)
        lay.addWidget(self.tree, 1)

        self.warnings_box = QTextEdit()
        self.warnings_box.setReadOnly(True)
        self.warnings_box.setFixedHeight(130)
        lay.addWidget(self.warnings_box)
        return box

    def _scroll_to(self, widget):
        QTimer.singleShot(60, lambda: self.scroll.ensureWidgetVisible(widget, 0, 40))

    def _show_report_preview(self):
        if not self._results:
            QMessageBox.information(self, "Nothing to preview", "Run the test first.")
            return
        dlg = ReportPreviewWindow(self._results, self._open_screenshot, self)
        dlg.setWindowState(Qt.WindowState.WindowMaximized)  # full screen
        dlg.exec()

    def _build_log_tab(self):
        tab = QWidget()
        lay = QVBoxLayout(tab)
        lay.setContentsMargins(0, 12, 0, 0)
        self.log_box = QTextEdit()
        self.log_box.setObjectName("log")
        self.log_box.setReadOnly(True)
        lay.addWidget(self.log_box, 1)
        self.tabs.addTab(tab, "Live log")

    def _build_results_tab(self):
        tab = QWidget()
        lay = QVBoxLayout(tab)
        lay.setContentsMargins(0, 12, 0, 0)
        lay.setSpacing(10)

        chips = QHBoxLayout()
        chips.setSpacing(8)
        self.wt_total_chip = QLabel("Total: 0")
        self.wt_total_chip.setObjectName("chip")
        self.wt_passed_chip = QLabel("Passed: 0")
        self.wt_passed_chip.setObjectName("chipPass")
        self.wt_failed_chip = QLabel("Failed: 0")
        self.wt_failed_chip.setObjectName("chipFail")
        hint = QLabel("Double-click a row for full details")
        hint.setObjectName("muted")
        chips.addWidget(self.wt_total_chip)
        chips.addWidget(self.wt_passed_chip)
        chips.addWidget(self.wt_failed_chip)
        chips.addStretch(1)
        chips.addWidget(hint)
        lay.addLayout(chips)

        cols = ["Q_No", "Option", "Test type", "Expected", "Actual", "Result", "Screenshot"]
        self.results_table = QTableWidget(0, len(cols))
        self.results_table.setHorizontalHeaderLabels(cols)
        self.results_table.verticalHeader().setVisible(False)
        self.results_table.setAlternatingRowColors(True)
        self.results_table.setShowGrid(False)
        self.results_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.results_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.results_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        h = self.results_table.horizontalHeader()
        h.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        h.setStretchLastSection(False)
        h.setDefaultAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        for i, w in enumerate((70, 150, 150, 220, 220, 80, 100)):
            self.results_table.setColumnWidth(i, w)
        h.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        h.setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        self.results_table.cellDoubleClicked.connect(self._on_results_double_click)
        lay.addWidget(self.results_table, 1)
        self.tabs.addTab(tab, "Live results")

    # ------------------------------------------------------------------
    # Accessors / state helpers
    # ------------------------------------------------------------------
    def _url(self):
        return self.url_edit.text().strip()

    def _excel(self):
        return self.excel_edit.text().strip()

    def set_status(self, msg, color=MUTED):
        self.status_text.setText(msg)
        self.status_dot.setStyleSheet(f"background: {color}; border-radius: 5px;")

    def _clear_log(self):
        self.log_box.clear()

    def log(self, msg):
        color = None
        if "RESULT: PASS" in msg:
            color = SUCCESS
        elif "RESULT: FAIL" in msg or "!!" in msg:
            color = DANGER
        else:
            color = MUTED if msg.startswith("  ") else None
        append_colored(self.log_box, msg + "\n", color)

    # ------------------------------------------------------------------
    # AI assistant context
    # ------------------------------------------------------------------
    def get_ai_context(self):
        """Snapshot of current session state, handed to the AI assistant fresh
        on every question so its answers stay in sync with the app."""
        last_run_summary = None
        if self.summary:
            failed_rows = [
                {
                    "qid": r.qid, "option_no": r.option_no, "test_type": r.test_type,
                    "expected": r.expected, "actual": r.actual, "notes": r.notes,
                }
                for r in self.summary.results if not r.passed
            ]
            last_run_summary = {
                "total": self.summary.total,
                "passed": self.summary.passed,
                "failed": self.summary.failed,
                "skipped": getattr(self.summary, "skipped_count", 0),
                "failed_rows": failed_rows,
            }

        warnings = validate_routing(self._questions) if self._questions else []
        unreachable = (unreachable_questions(self._questions, self._start_qid)
                       if self._questions and self._start_qid else [])

        return {
            "survey_url": self._url(),
            "excel_path": self._excel(),
            "sheet_name": self._sheet_name,
            "question_count": len(self._questions) if self._questions else None,
            "start_qid": self._start_qid,
            "routing_warnings": warnings,
            "unreachable_questions": unreachable,
            "last_run_summary": last_run_summary,
            "log_tail": self.log_box.toPlainText(),
        }

    # ------------------------------------------------------------------
    # File pickers
    # ------------------------------------------------------------------
    def pick_url_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select a .txt file containing the survey link", "",
            "Text files (*.txt);;All files (*.*)",
        )
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                url = f.read().strip().splitlines()[0].strip()
            self.url_edit.setText(url)
            self.set_status("Survey link loaded.", SUCCESS)
        except Exception as e:
            QMessageBox.critical(self, "Error reading link file", str(e))

    def pick_excel_file(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select the survey routing Excel file", "",
            "Excel files (*.xlsx *.xlsm);;All files (*.*)",
        )
        if path:
            self.excel_edit.setText(path)
            self.set_status("Routing file selected.", SUCCESS)
            self.preview_structure()  # auto-load the questions below

    # ------------------------------------------------------------------
    # Timer
    # ------------------------------------------------------------------
    def _start_timer(self):
        self._run_start_time = time.time()
        self._tick_timer()
        self._timer.start()

    def _tick_timer(self):
        if self._run_start_time is None:
            return
        elapsed = int(time.time() - self._run_start_time)
        mins, secs = divmod(elapsed, 60)
        self.timer_label.setText(f"Elapsed {mins:02d}:{secs:02d}")

    def _stop_timer(self):
        self._timer.stop()
        self._run_start_time = None

    # ------------------------------------------------------------------
    # Load / preview
    # ------------------------------------------------------------------
    def _load_and_validate(self):
        excel_path = self._excel()
        if not excel_path or not os.path.isfile(excel_path):
            QMessageBox.warning(self, "Missing file", "Please choose the routing Excel file first.")
            return None
        try:
            questions, start_qid, order, sheet_name = load_survey(excel_path)
        except SurveyParseError as e:
            QMessageBox.critical(self, "Excel parsing error", str(e))
            return None
        except Exception as e:
            QMessageBox.critical(self, "Excel parsing error", f"Unexpected error: {e}")
            return None
        self._sheet_name = sheet_name
        return questions, start_qid, order

    def preview_structure(self):
        loaded = self._load_and_validate()
        if not loaded:
            self.structure_card.setVisible(False)
            return
        questions, start_qid, order = loaded
        warnings = validate_routing(questions)
        unreachable = unreachable_questions(questions, start_qid)

        self._questions = questions
        self._order = order
        self._start_qid = start_qid

        bold = QFont(self.tree.font())
        bold.setBold(True)

        self.tree.clear()
        for qid in order:
            q = questions[qid]
            marker = "\u2605 " if qid == start_qid else ""
            q_item = QTreeWidgetItem([
                f"{marker}[{qid}] {str(q['text'])[:90]}",
                str(q["type"] or q["row_type"] or ""),
                "",
            ])
            for col in range(3):
                q_item.setFont(col, bold)
            for opt in q["options"]:
                if opt["termination"]:
                    o_item = QTreeWidgetItem([f"{opt['option_no']}. {opt['option_text']}", "", "TERMINATE"])
                    o_item.setForeground(2, QColor(DANGER))
                else:
                    o_item = QTreeWidgetItem([f"{opt['option_no']}. {opt['option_text']}", "", f"\u2192 {opt['routing']}"])
                    o_item.setForeground(2, QColor(SUCCESS))
                o_item.setData(0, Qt.ItemDataRole.UserRole, (qid, opt))
                q_item.addChild(o_item)
            self.tree.addTopLevelItem(q_item)
            q_item.setExpanded(False)

        wb = self.warnings_box
        wb.clear()
        append_colored(wb, "Tip: double-click any option above to fix its routing, termination, "
                           "or text directly in the Excel file.\n\n", MUTED)
        if warnings:
            append_colored(wb, "Routing warnings:\n", WARN, bold=True)
            for w in warnings:
                append_colored(wb, f"  \u2022 {w}\n", WARN)
        else:
            append_colored(wb, "\u2713 No routing warnings.\n", SUCCESS)
        if unreachable:
            append_colored(wb, f"\nUnreachable questions (no path from {start_qid}): {unreachable}\n", WARN)
        else:
            append_colored(wb, "\u2713 All questions are reachable from the start question.\n", SUCCESS)

        self.structure_card.setVisible(True)
        self._scroll_to(self.structure_card)
        self.set_status(f"Preview complete \u2014 {len(questions)} questions parsed.", SUCCESS)

    # ------------------------------------------------------------------
    # Routing sheet editing
    # ------------------------------------------------------------------
    def _on_tree_double_click(self, item, _column):
        data = item.data(0, Qt.ItemDataRole.UserRole)
        if not data:
            return  # question row -- nothing to edit
        qid, opt = data
        self._open_option_editor(qid, opt)

    def _open_option_editor(self, qid, opt):
        excel_path = self._excel()
        if not excel_path or not os.path.isfile(excel_path):
            QMessageBox.warning(self, "Missing file", "The routing Excel file is no longer available.")
            return

        dialog = OptionEditDialog(qid, opt, self._order, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        new_text, new_terminate, new_routing = dialog.values()

        edits = []
        if new_text != opt["option_text"]:
            edits.append({"row_idx": opt["row_idx"], "field": "Option_Text", "value": new_text})
        if new_terminate != opt["termination"]:
            edits.append({"row_idx": opt["row_idx"], "field": "TERMINATION",
                          "value": "TRUE" if new_terminate else ""})
        if new_routing != (opt["routing"] or ""):
            edits.append({"row_idx": opt["row_idx"], "field": "ROUTING", "value": new_routing})
        if not edits:
            return

        try:
            backup_path, applied = save_edits(excel_path, edits, sheet_name=self._sheet_name)
        except Exception as e:
            QMessageBox.critical(self, "Could not save to Excel", str(e))
            return

        for change in applied:
            self.log(
                f"Excel updated [{qid}] opt {opt['option_no']} \u2014 {change['field']}: "
                f"{change['old_value']!r} -> {change['new_value']!r}"
            )
        self.log(f"Backup of original sheet saved to: {backup_path}")
        self.set_status("Routing sheet updated \u2014 refreshing preview\u2026", SUCCESS)
        self.preview_structure()  # reload from disk so the tree/warnings reflect the fix

    # ------------------------------------------------------------------
    # Running tests
    # ------------------------------------------------------------------
    def start_run(self):
        url = self._url()
        if not url:
            QMessageBox.warning(self, "Missing link", "Please enter or load the survey link first.")
            return
        loaded = self._load_and_validate()
        if not loaded:
            return
        questions, start_qid, _order = loaded
        paths = build_baseline_paths(questions, start_qid)

        # Same flattening run_tests() does internally, so this count matches
        # what will execute. A few jobs can still self-skip at run time, so
        # completion always snaps the bar to 100%.
        jobs, _skipped = _build_jobs(questions, paths)
        self._expected_test_count = max(len(jobs), 1)

        self.log_box.clear()
        self.results_table.setRowCount(0)
        self._wt_total = self._wt_passed = self._wt_failed = 0
        self._results = []
        self._update_counters()
        self.done_row.setVisible(False)
        self.res_card.setVisible(True)
        self.progress_box.setVisible(True)
        self.run_btn.setEnabled(False)
        self.progress.setRange(0, self._expected_test_count)
        self.progress.setValue(0)
        self.pct_label.setText("0%")
        self._start_timer()
        self.tabs.setCurrentIndex(0)  # Live log
        self._scroll_to(self.res_card)
        self.set_status("Running tests\u2026 this can take a while depending on survey length.", PRIMARY)

        # Signals let the worker thread talk to the GUI safely.
        sig = RunSignals()
        sig.log.connect(self.log)
        sig.result.connect(self._add_test_result)
        sig.manual_help.connect(self._on_manual_help)
        sig.done.connect(self._on_run_done)
        sig.failed.connect(self._on_run_failed)
        sig.finished.connect(self._on_run_finished)
        self._signals = sig

        headless = self.headless_chk.isChecked()
        slow_mo = self.slowmo_spin.value()
        workers = self.workers_spin.value()
        help_lock = threading.Lock()

        def ask_user_to_manually_select(option_text):
            """Called from a worker thread when no text strategy found the option.
            Blocks that thread until the person answers the popup (shown on the
            GUI thread). Concurrent requests are serialised by help_lock."""
            with help_lock:
                holder = {"event": threading.Event(), "value": False}
                sig.manual_help.emit(option_text, holder)
                holder["event"].wait()
                return holder["value"]

        def worker():
            try:
                summary = run_tests(
                    url, questions, start_qid, paths,
                    log=lambda m: sig.log.emit(str(m)),
                    headless=headless,
                    slow_mo=slow_mo,
                    max_workers=workers,
                    on_result=lambda r: sig.result.emit(r),
                    on_manual_help_needed=ask_user_to_manually_select,
                )
                sig.done.emit(summary)
            except Exception as e:
                sig.failed.emit(str(e))
            finally:
                sig.finished.emit()

        self._run_thread = threading.Thread(target=worker, daemon=True)
        self._run_thread.start()

    def _on_manual_help(self, option_text, holder):
        try:
            answer = QMessageBox.question(
                self, "Option not found automatically",
                "I couldn't automatically find this option on the page:\n\n"
                f"    {option_text}\n\n"
                "Please look at the browser window and click/select it yourself "
                "if you can see it.\n\n"
                "Click YES once you've selected it \u2014 I'll click Next and check "
                "whether the routing is correct.\n"
                "Click NO if you also can't find this option on the page.",
            )
            holder["value"] = (answer == QMessageBox.StandardButton.Yes)
        finally:
            holder["event"].set()

    def _on_run_done(self, summary):
        self.summary = summary
        self.log("\n================ DONE ================")
        self.log(f"Total: {summary.total}  Passed: {summary.passed}  Failed: {summary.failed}")
        if getattr(summary, "skipped_count", 0):
            self.log(f"Skipped (Option_Choosing != 'yes'): {summary.skipped_count}")
        if getattr(summary, "screenshots_dir", "") and summary.failed:
            self.log(f"Failure screenshots saved to: {summary.screenshots_dir}")
        self.set_status(f"Finished: {summary.passed}/{summary.total} passed.",
                        SUCCESS if summary.failed == 0 else DANGER)
        self.progress.setValue(self.progress.maximum())
        self.pct_label.setText("100%")
        self.trend_btn.setVisible(bool(summary.total))
        self.done_row.setVisible(True)
        self._scroll_to(self.done_row)

    def _on_run_failed(self, message):
        self.log(f"\nFATAL ERROR: {message}")
        self.set_status("Run failed - see log.", DANGER)
        QMessageBox.critical(self, "Run failed", message)

    def _on_run_finished(self):
        # On the error path the bar is left wherever it got to -- an honest
        # signal that the run didn't fully complete.
        self.run_btn.setEnabled(True)
        self._stop_timer()

    # ------------------------------------------------------------------
    # Report preview table
    # ------------------------------------------------------------------
    def _update_counters(self):
        self.wt_total_chip.setText(f"Total: {self._wt_total}")
        self.wt_passed_chip.setText(f"Passed: {self._wt_passed}")
        self.wt_failed_chip.setText(f"Failed: {self._wt_failed}")

    def _add_test_result(self, result):
        self._results.append(result)
        self._wt_total += 1
        if result.passed:
            self._wt_passed += 1
        else:
            self._wt_failed += 1
        self._update_counters()

        # Clamp so parallel workers can never push the bar past 100%.
        expected = self._expected_test_count or max(self._wt_total, 1)
        shown = min(self._wt_total, expected)
        self.progress.setValue(shown)
        self.pct_label.setText(f"{int(round(shown / expected * 100))}%")

        screenshot_path = getattr(result, "screenshot_path", "") or ""
        values = (
            result.qid, result.option_text, result.test_type,
            str(result.expected)[:60], str(result.actual)[:60],
            "PASS" if result.passed else "FAIL",
            "View" if screenshot_path else "",
        )
        row = self.results_table.rowCount()
        self.results_table.insertRow(row)
        for col, value in enumerate(values):
            item = QTableWidgetItem(str(value))
            if col in (5, 6):
                item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            if col == 5:
                item.setForeground(QColor(SUCCESS if result.passed else DANGER))
                f = QFont(item.font())
                f.setBold(True)
                item.setFont(f)
            if col == 6 and screenshot_path:
                item.setForeground(QColor(PRIMARY))
            self.results_table.setItem(row, col, item)

        notes_text = (
            f"Expected: {result.expected}\n\nActual: {result.actual}"
            + (f"\n\nNotes: {result.notes}" if result.notes else "")
            + (f"\n\nScreenshot: {screenshot_path}" if screenshot_path else "")
        )
        first = self.results_table.item(row, 0)
        first.setData(Qt.ItemDataRole.UserRole, notes_text)
        first.setData(Qt.ItemDataRole.UserRole + 1, screenshot_path)
        # Keep the newest result visible during a long run.
        self.results_table.scrollToItem(first)

    def _on_results_double_click(self, row, column):
        first = self.results_table.item(row, 0)
        if not first:
            return
        notes = first.data(Qt.ItemDataRole.UserRole)
        shot = first.data(Qt.ItemDataRole.UserRole + 1)
        # Screenshot column opens the image; anywhere else shows full detail.
        if column == 6 and shot:
            self._open_screenshot(shot)
            return
        if notes:
            QMessageBox.information(self, "Test detail", notes)

    def _open_screenshot(self, path):
        if not path or not os.path.isfile(path):
            QMessageBox.warning(self, "Screenshot not found", f"Could not find:\n{path}")
            return
        if not QDesktopServices.openUrl(QUrl.fromLocalFile(path)):
            QMessageBox.critical(self, "Could not open screenshot", path)

    # ------------------------------------------------------------------
    # Save report
    # ------------------------------------------------------------------
    def save_report(self):
        if not self.summary:
            QMessageBox.information(self, "Nothing to save", "Run the test first.")
            return
        default_name = f"survey_test_report_{datetime.datetime.now():%Y%m%d_%H%M%S}.xlsx"
        out_path, _ = QFileDialog.getSaveFileName(
            self, "Save test report", default_name, "Excel files (*.xlsx)"
        )
        if not out_path:
            return
        if not out_path.lower().endswith(".xlsx"):
            out_path += ".xlsx"
        try:
            write_report(self.summary, out_path, self._url())
            QMessageBox.information(self, "Saved", f"Report saved to:\n{out_path}")
            self.set_status(f"Report saved to {os.path.basename(out_path)}", SUCCESS)
        except Exception as e:
            QMessageBox.critical(self, "Error saving report", str(e))

    # ------------------------------------------------------------------
    # Trend analysis
    # ------------------------------------------------------------------
    def show_trend_analysis(self):
        if not self.summary or not self.summary.total:
            QMessageBox.information(self, "Nothing to analyze", "Run the test first.")
            return

        total = self.summary.total
        passed = self.summary.passed
        failed = self.summary.failed
        pass_pct = passed / total * 100 if total else 0
        fail_pct = failed / total * 100 if total else 0

        dialog = QDialog(self)
        dialog.setWindowTitle("Trend analysis \u2014 Pass / Fail")
        dialog.setModal(True)
        root = QVBoxLayout(dialog)
        root.setContentsMargins(28, 24, 28, 22)
        root.setSpacing(14)

        title = QLabel(f"Current run \u2014 {total} test{'s' if total != 1 else ''}")
        title.setObjectName("cardTitle")
        root.addWidget(title)

        row = QHBoxLayout()
        row.setSpacing(24)
        row.addWidget(DonutChart(passed, failed))

        legend = QVBoxLayout()
        legend.setSpacing(10)
        legend.addStretch(1)

        def legend_row(color, label, count, pct):
            r = QHBoxLayout()
            r.setSpacing(8)
            sw = QLabel()
            sw.setFixedSize(12, 12)
            sw.setStyleSheet(f"background: {color}; border-radius: 3px;")
            r.addWidget(sw)
            r.addWidget(QLabel(f"{label}: {count}  ({pct:.1f}%)"))
            r.addStretch(1)
            legend.addLayout(r)

        legend_row(SUCCESS, "Passed", passed, pass_pct)
        legend_row(DANGER, "Failed", failed, fail_pct)
        skipped = getattr(self.summary, "skipped_count", 0)
        if skipped:
            note = QLabel(f"Skipped: {skipped} (not counted in %)")
            note.setObjectName("muted")
            legend.addWidget(note)
        legend.addStretch(1)
        row.addLayout(legend, 1)
        root.addLayout(row)

        btns = QHBoxLayout()
        btns.addStretch(1)
        close = pointing(QPushButton("Close"))
        close.clicked.connect(dialog.accept)
        btns.addWidget(close)
        root.addLayout(btns)
        dialog.exec()

    # ------------------------------------------------------------------
    # Window close
    # ------------------------------------------------------------------
    def closeEvent(self, event):
        if self._run_thread is not None and self._run_thread.is_alive():
            answer = QMessageBox.question(
                self, "Test still running",
                "A test run is still in progress. Quit anyway?",
            )
            if answer != QMessageBox.StandardButton.Yes:
                event.ignore()
                return
        event.accept()


def main():
    app = QApplication.instance() or QApplication(sys.argv)
    window = SurveyTesterApp()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()